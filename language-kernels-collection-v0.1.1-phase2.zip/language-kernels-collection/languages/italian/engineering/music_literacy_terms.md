
# Terminology Inventory: Music Literacy (65 Concept Records)

## Category 1: Physical Acoustics (10 Concepts)

### `MUS-ACOUST-001`
* **Term (IT):** suono
* **Definition (IT):** Perturbazione acustica meccanica che si propaga attraverso un mezzo elastico sotto forma di onda di pressione longitudinale percependosi attraverso l'apparato uditivo.
* **Plain Explanation (IT):** La vibrazione fisica trasmessa nell'aria che il nostro orecchio percepisce come fenomeno acustico.
* **English Equivalent:** sound
* **German Equivalent:** Schall (physikalisch) / Ton (musikalisch)
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-ACOUST-002`, `MUS-ACOUST-004`, `MUS-ACOUST-008`
* **Source:** Open Music Theory v2 — Introduction to Sound; Understanding Basic Music Theory Sec. 3.1.
* **Usage Example:** "Il suono si propaga nell'aria a una velocità approssimativa di 343 m/s."

### `MUS-ACOUST-002`
* **Term (IT):** frequenza
* **Definition (IT):** Numero di cicli completi di oscillazione compiuti da un'onda sonora nell'unità di tempo, misurata in Hertz (Hz).
* **Plain Explanation (IT):** La velocità delle vibrazioni acustiche: una frequenza più alta corrisponde a un suono più acuto.
* **English Equivalent:** frequency
* **German Equivalent:** Frequenz
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-ACOUST-003`, `MUS-PITCH-001`
* **Source:** Understanding Basic Music Theory Sec. 3.1.4.
* **Usage Example:** "La frequenza fondamentale del La4 è fissata convenzionalmente a 440 Hz."

### `MUS-ACOUST-003`
* **Term (IT):** altezza
* **Definition (IT):** Attributo percettivo-psicoacustico del suono che permette di ordinarlo su una scala da grave ad acuto, direttamente correlato alla frequenza fondamentale dell'onda.
* **Plain Explanation (IT):** La proprietà che ci fa distinguere una nota acuta da una nota grave.
* **English Equivalent:** pitch
* **German Equivalent:** Tonhöhe
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-ACOUST-002`, `MUS-NOT-005`
* **Source:** Open Music Theory v2 — Reading Clefs.
* **Usage Example:** "L'altezza della nota varia con il variare della frequenza della sorgente."

### `MUS-ACOUST-004`
* **Term (IT):** ampiezza
* **Definition (IT):** Valore massimo dello spostamento o della variazione di pressione dell'onda acustica rispetto al suo stato di equilibrio.
* **Plain Explanation (IT):** La grandezza fisica della vibrazione d'onda, da cui dipende l'energia del suono.
* **English Equivalent:** amplitude
* **German Equivalent:** Amplitude
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-ACOUST-005`
* **Source:** Understanding Basic Music Theory Sec. 3.1.3.
* **Usage Example:** "Un'ampiezza d'onda maggiore trasporta una quantità di energia superiore."

### `MUS-ACOUST-005`
* **Term (IT):** intensità acustica
* **Definition (IT):** Flusso di energia acustica che attraversa un'unità di superficie perpendicolare alla direzione di propagazione, misurato in Watt al metro quadro ($\text{W/m}^2$) o espresso in livello di pressione sonora ($\text{dB SPL}$).
* **Plain Explanation (IT):** La potenza fisica reale del suono, distinta dalla sensazione soggettiva di volume.
* **English Equivalent:** acoustic intensity / sound intensity
* **German Equivalent:** Schallintensität
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `requires_expert_review`
* **Parent Concept:** `MUS-ACOUST-004`
* **Related Concepts:** `MUS-EXPR-001`
* **Source:** Understanding Basic Music Theory Sec. 3.1.3.
* **Usage Example:** "L'intensità acustica decresce con il quadrato della distanza dalla sorgente."

### `MUS-ACOUST-006`
* **Term (IT):** durata
* **Definition (IT):** Dimensione temporale che intercorre tra l'inizio (attacco) e la fine (estinzione) di un evento acustico o di un silenzio notato.
* **Plain Explanation (IT):** Il lasso di tempo durante il quale un suono o una pausa continua a essere prolungata.
* **English Equivalent:** duration
* **German Equivalent:** Tondauer
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-NOT-005`, `MUS-RHY-001`
* **Source:** Open Music Theory v2 — Rhythmic Values.
* **Usage Example:** "La durata relativa dei suoni è indicata dalla forma della figura musicale."

### `MUS-ACOUST-007`
* **Term (IT):** timbro
* **Definition (IT):** Qualità spettrale specifica di un suono che consente di distinguere due sorgenti acustiche aventi la stessa altezza e intensità, determinata dallo spettro degli armonici e dall'inviluppo dinamico.
* **Plain Explanation (IT):** Il 'colore' caratteristico che differenzia il suono di uno strumento da quello di un altro.
* **English Equivalent:** timbre / tone color
* **German Equivalent:** Klangfarbe
* **Domain Layer:** Physical Acoustics / Expressive
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-ACOUST-009`, `MUS-INST-002`
* **Source:** Open Music Theory v2 — Timbre and Orchestration.
* **Usage Example:** "Il timbro caldo del violoncello differisce da quello brillante della tromba."

### `MUS-ACOUST-008`
* **Term (IT):** onda sonora
* **Definition (IT):** Onda meccanica di pressione che si propaga mediante progressive compressioni e rarefazioni della densità del mezzo materiale.
* **Plain Explanation (IT):** La struttura ondulatoria che trasporta la vibrazione acustica nell'aria.
* **English Equivalent:** sound wave
* **German Equivalent:** Schallwelle
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-ACOUST-002`, `MUS-ACOUST-004`
* **Source:** Understanding Basic Music Theory Sec. 3.1.2.
* **Usage Example:** "Le onde sonore non possono propagarsi nel vuoto."

### `MUS-ACOUST-009`
* **Term (IT):** armonici
* **Definition (IT):** Frequenze parziali sinusoidali che compongono un suono complesso, le cui frequenze sono multipli interi della frequenza fondamentale ($f_n = n \cdot f_1$).
* **Plain Explanation (IT):** Note secondarie e più acute prodotte simultaneamente alla nota principale, che definiscono la ricchezza del suono.
* **English Equivalent:** harmonics / overtones
* **German Equivalent:** Obertöne / Harmonische
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-001`
* **Related Concepts:** `MUS-ACOUST-007`, `MUS-ACOUST-010`
* **Source:** Understanding Basic Music Theory Sec. 3.3.3.
* **Usage Example:** "La serie degli armonici determina la consonanza naturale degli intervalli."

### `MUS-ACOUST-010`
* **Term (IT):** frequenza fondamentale
* **Definition (IT):** La componente sinusoidale a frequenza più bassa ($f_1$) all'interno dello spettro di un suono complesso periodico, che determina l'altezza percepita della nota.
* **Plain Explanation (IT):** La frequenza base su cui si costituisce l'intero suono della nota.
* **English Equivalent:** fundamental frequency
* **German Equivalent:** Grundfrequenz / Grundton
* **Domain Layer:** Physical Acoustics
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-ACOUST-009`
* **Related Concepts:** `MUS-ACOUST-002`, `MUS-ACOUST-003`
* **Source:** Open Music Theory v2 — Timbre & Harmonic Series.
* **Usage Example:** "La frequenza fondamentale determina la nota intonata dall'esecutore."

## Category 2: Musical Notation (11 Concepts)

### `MUS-NOT-001`
* **Term (IT):** pentagramma
* **Definition (IT):** Struttura di notazione costituita da cinque linee orizzontali parallele ed equidistanti e quattro spazi interni.
* **Plain Explanation (IT):** Lo schema a 5 linee su cui si scrivono i simboli musicali.
* **English Equivalent:** staff / stave
* **German Equivalent:** Notensystem
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-NOT-002`, `MUS-NOT-005`
* **Source:** Open Music Theory v2 — Pitch Notation.
* **Usage Example:** "Le note scritte nei tagli superiori del pentagramma indicano suoni acuti."

### `MUS-NOT-002`
* **Term (IT):** rigo musicale
* **Definition (IT):** Denominazione generica o specifica per la linea o l'insieme di linee ordinate usate per notare la musica.
* **Plain Explanation (IT):** Termine comune per indicare il pentagramma o una singola riga di spartito.
* **English Equivalent:** musical staff line / stave
* **German Equivalent:** Notenzeile
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-001`
* **Related Concepts:** `MUS-NOT-007`
* **Source:** Understanding Basic Music Theory Sec. 1.1.1.
* **Usage Example:** "Il primo rigo musicale contiene la melodia del soprano."

### `MUS-NOT-003`
* **Term (IT):** chiave di violino
* **Definition (IT):** Chiave di notazione del gruppo di Sol, posizionata sulla seconda linea dal basso del pentagramma, utilizzata per registri medio-acuti.
* **Plain Explanation (IT):** Il simbolo (𝄞) che fissa la nota Sol sulla seconda linea del pentagramma.
* **English Equivalent:** treble clef / G-clef
* **German Equivalent:** Violinschlüssel / G-Schlüssel
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-001`
* **Related Concepts:** `MUS-NOT-004`
* **Source:** Open Music Theory v2 — Reading Clefs.
* **Usage Example:** "La musica per violino e flauto si legge prevalentemente in chiave di violino."

### `MUS-NOT-004`
* **Term (IT):** chiave di basso
* **Definition (IT):** Chiave di notazione del gruppo di Fa, posizionata sulla quarta linea dal basso del pentagramma, utilizzata per registri gravi.
* **Plain Explanation (IT):** Il simbolo (𝄢) che stabilisce che la quarta linea del pentagramma è la nota Fa.
* **English Equivalent:** bass clef / F-clef
* **German Equivalent:** Bassschlüssel / F-Schlüssel
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-001`
* **Related Concepts:** `MUS-NOT-003`
* **Source:** Open Music Theory v2 — Reading Clefs.
* **Usage Example:** "La mano sinistra del pianoforte legge spesso in chiave di basso."

### `MUS-NOT-005`
* **Term (IT):** nota
* **Definition (IT):** Simbolo grafico convenzionale la cui posizione sul pentagramma indica l'altezza e la cui forma determina la durata relativa del suono.
* **Plain Explanation (IT):** Il segno grafico che rappresenta un suono musicale scritto.
* **English Equivalent:** note
* **German Equivalent:** Note
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-001`
* **Related Concepts:** `MUS-NOT-006`, `MUS-ACOUST-003`, `MUS-ACOUST-006`
* **Source:** Open Music Theory v2 — Pitch Notation.
* **Usage Example:** "Una semibreve è una nota che vale quattro quarti."

### `MUS-NOT-006`
* **Term (IT):** pausa
* **Definition (IT):** Simbolo grafico che prescrive un intervallo misurato di silenzio d'interruzione all'interno del flusso ritmico.
* **Plain Explanation (IT):** Il segno che indica di non suonare per una durata stabilita.
* **English Equivalent:** rest
* **German Equivalent:** Pause
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-001`
* **Related Concepts:** `MUS-NOT-005`
* **Source:** Open Music Theory v2 — Rest Values.
* **Usage Example:** "La pausa di semiminima corrisponde a un battito di silenzio."

### `MUS-NOT-007`
* **Term (IT):** tagli addizionali
* **Definition (IT):** Brevi tratti orizzontali tracciati sopra o sotto il pentagramma per notare altezze che superano il rigo standard.
* **Plain Explanation (IT):** Lineette provvisorie aggiunte per scrivere note molto alte o molto basse.
* **English Equivalent:** ledger lines
* **German Equivalent:** Hilfslinien
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-001`
* **Related Concepts:** `MUS-NOT-002`
* **Source:** Open Music Theory v2 — Ledger Lines.
* **Usage Example:** "Il Do centrale richiede un taglio addizionale sotto il pentagramma in chiave di violino."

### `MUS-NOT-008`
* **Term (IT):** alterazione
* **Definition (IT):** Simbolo grafico applicato prima di una nota o nell'armatura di chiave per modificarne l'altezza di uno o due semitoni.
* **Plain Explanation (IT):** Segno (diesis, bemolle, bequadro) che alza, abbassa o ripristina la nota.
* **English Equivalent:** accidental
* **German Equivalent:** Versetzungszeichen / Akzidenz
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-005`
* **Related Concepts:** `MUS-NOT-009`, `MUS-NOT-010`, `MUS-NOT-011`
* **Source:** Open Music Theory v2 — Accidentals.
* **Usage Example:** "L'alterazione momentanea vale solo per la battuta in cui è scritta."

### `MUS-NOT-009`
* **Term (IT):** diesis
* **Definition (IT):** Simbolo di alterazione (♯) che alza l'altezza della nota a cui si riferisce di un semitono cromatico.
* **Plain Explanation (IT):** Il segno ♯ che aumenta la nota di mezzo tono.
* **English Equivalent:** sharp
* **German Equivalent:** Kreuz
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-008`
* **Related Concepts:** `MUS-NOT-010`
* **Source:** Open Music Theory v2 — Accidentals.
* **Usage Example:** "Il Fa diesis si trova mezzo tono sopra il Fa naturale."

### `MUS-NOT-010`
* **Term (IT):** bemolle
* **Definition (IT):** Simbolo di alterazione (♭) che abbassa l'altezza della nota a cui si riferisce di un semitono cromatico.
* **Plain Explanation (IT):** Il segno ♭ che cala la nota di mezzo tono.
* **English Equivalent:** flat
* **German Equivalent:** Be / B-Zeichen
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-008`
* **Related Concepts:** `MUS-NOT-009`
* **Source:** Open Music Theory v2 — Accidentals.
* **Usage Example:** "Il Si bemolle si trova mezzo tono sotto la nota Si."

### `MUS-NOT-011`
* **Term (IT):** bequadro
* **Definition (IT):** Simbolo di alterazione (♮) che annulla l'effetto di un diesis o di un bemolle precedente.
* **Plain Explanation (IT):** Il segno ♮ che riporta la nota al suo stato naturale.
* **English Equivalent:** natural
* **German Equivalent:** Auflösungszeichen
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-NOT-008`
* **Related Concepts:** `MUS-NOT-009`, `MUS-NOT-010`
* **Source:** Open Music Theory v2 — Accidentals.
* **Usage Example:** "Il bequadro annulla il diesis applicato nella battuta."

## Category 3: Rhythm & Meter (7 Concepts)

### `MUS-RHY-001`
* **Term (IT):** pulsazione
* **Definition (IT):** Successione regolare ed equidistante di battiti isometrici impliciti o espliciti che costituisce l'unità di tempo base.
* **Plain Explanation (IT):** Il battito costante e regolare che si percepisce sotto la musica.
* **English Equivalent:** pulse / beat
* **German Equivalent:** Puls / Grundschlag
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-RHY-002`, `MUS-RHY-003`
* **Source:** Open Music Theory v2 — Meter & Pulse.
* **Usage Example:** "La pulsazione di questo brano è di 120 battiti al minuto."

### `MUS-RHY-002`
* **Term (IT):** ritmo
* **Definition (IT):** Organizzazione nel tempo delle durate dei suoni e dei silenzi articolati rispetto alla pulsazione metrica.
* **Plain Explanation (IT):** Il disegno temporale formato dalle note lunghe, brevi e dalle pause.
* **English Equivalent:** rhythm
* **German Equivalent:** Rhythmus
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-RHY-001`
* **Related Concepts:** `MUS-RHY-004`, `MUS-RHY-007`
* **Source:** Understanding Basic Music Theory Sec. 2.1.
* **Usage Example:** "Il ritmo sincopato caratterizza questo brano."

### `MUS-RHY-003`
* **Term (IT):** tempo
* **Definition (IT):** Indicazione della velocità assoluta di scansione della pulsazione (frequenza dei battiti espresso in BPM o termini tradizionali).
* **Plain Explanation (IT):** La velocità d'esecuzione del brano (es. Allegro, Andante).
* **English Equivalent:** tempo / tempo marking
* **German Equivalent:** Tempo / Tempobezeichnung
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `requires_expert_review`
* **Parent Concept:** `MUS-RHY-001`
* **Related Concepts:** `MUS-RHY-005`, `MUS-EXPR-002`
* **Source:** Open Music Theory v2 — Tempo Markings.
* **Usage Example:** "Il tempo indicato all'inizio dello spartito è 'Andante moderato'."

### `MUS-RHY-004`
* **Term (IT):** misura
* **Definition (IT):** Unità di strutturazione metrica del tempo delimitata sul pentagramma da due stanghette verticali (battuta).
* **Plain Explanation (IT):** Lo spazio compreso tra due linee verticali che contiene un numero fisso di battiti.
* **English Equivalent:** measure / bar
* **German Equivalent:** Takt
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-RHY-001`
* **Related Concepts:** `MUS-RHY-005`
* **Source:** Open Music Theory v2 — Simple Meter.
* **Usage Example:** "La prima frase musicale si conclude alla quarta misura."

### `MUS-RHY-005`
* **Term (IT):** indicazione di metro
* **Definition (IT):** Simbolo numerale a forma di frazione posizionato all'inizio del rigo che esprime la struttura della misura (numero di pulsazioni e valore di ciascuna).
* **Plain Explanation (IT):** I numeri sovrapposti (es. 4/4, 3/4) che indicano come contare all'interno della misura.
* **English Equivalent:** time signature / meter signature
* **German Equivalent:** Taktangabe / Taktzeichen
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-RHY-004`
* **Related Concepts:** `MUS-RHY-003`
* **Source:** Open Music Theory v2 — Simple and Compound Meter.
* **Usage Example:** "L'indicazione di metro 3/4 definisce un tempo ternario."

### `MUS-RHY-006`
* **Term (IT):** suddivisione
* **Definition (IT):** Frazionamento della pulsazione principale in parti ritmiche uguali di valore inferiore (binaria o ternaria).
* **Plain Explanation (IT):** La divisione del battito principale in due o tre note più brevi.
* **English Equivalent:** subdivision
* **German Equivalent:** Unterteilung
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-RHY-001`
* **Related Concepts:** `MUS-RHY-002`
* **Source:** Open Music Theory v2 — Subdivision of the Beat.
* **Usage Example:** "La suddivisione in ottavi deve essere eseguita con precisione."

### `MUS-RHY-007`
* **Term (IT):** sincope
* **Definition (IT):** Effetto ritmico ottenuto prolungando un suono iniziato su un tempo debole o una suddivisione debole su un tempo forte successivo, spostando l'accento atteso.
* **Plain Explanation (IT):** Lo spostamento dell'accento musicale dal tempo forte a quello debole per creare contrasto.
* **English Equivalent:** syncopation
* **German Equivalent:** Synkope
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-RHY-002`
* **Related Concepts:** `MUS-RHY-001`
* **Source:** Open Music Theory v2 — Syncopation.
* **Usage Example:** "La sincope crea un senso di spinta nel ritmo."

## Category 4: Pitch, Intervals & Scales (9 Concepts)

### `MUS-PITCH-001`
* **Term (IT):** semitono
* **Definition (IT):** L'intervallo minimo convenzionale tra due altezze nel sistema temperato equabile occidentale.
* **Plain Explanation (IT):** La distanza più piccola tra due note adiacenti sul pianoforte.
* **English Equivalent:** semitone / half step
* **German Equivalent:** Halbton
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-PITCH-002`, `MUS-PITCH-003`
* **Source:** Open Music Theory v2 — Half Steps & Whole Steps.
* **Usage Example:** "Tra la nota Mi e la nota Fa c'è la distanza di un semitono naturale."

### `MUS-PITCH-002`
* **Term (IT):** tono
* **Definition (IT):** Intervallo musicale formato dalla somma di due semitoni contigui.
* **Plain Explanation (IT):** Intervallo pari a due semitoni (es. la distanza tra Do e Re).
* **English Equivalent:** tone / whole step
* **German Equivalent:** Ganzton
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-001`
* **Related Concepts:** `MUS-PITCH-003`
* **Source:** Open Music Theory v2 — Half Steps & Whole Steps.
* **Usage Example:** "La distanza tra Do e Re è un tono intero."

### `MUS-PITCH-003`
* **Term (IT):** intervallo
* **Definition (IT):** Relazione o differenza di altezza tra due toni eseguiti in successione (melodico) o simultaneamente (armonico).
* **Plain Explanation (IT):** La distanza espressa in gradi tra due note musicali.
* **English Equivalent:** interval
* **German Equivalent:** Intervall
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-PITCH-001`, `MUS-PITCH-004`
* **Source:** Open Music Theory v2 — Interval Types.
* **Usage Example:** "L'intervallo tra Do e Sol è una quinta giusta."

### `MUS-PITCH-004`
* **Term (IT):** ottava
* **Definition (IT):** Intervallo tra due altezze in cui la frequenza della nota superiore è esattamente il doppio della frequenza della nota inferiore ($f_2 = 2 \cdot f_1$).
* **Plain Explanation (IT):** La distanza tra due note con lo stesso nome ma a diversa altezza.
* **English Equivalent:** octave
* **German Equivalent:** Oktave
* **Domain Layer:** Physical Acoustics / Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-003`
* **Related Concepts:** `MUS-ACOUST-002`
* **Source:** Understanding Basic Music Theory Sec. 1.2.
* **Usage Example:** "Il Do4 si trova un'ottava sopra il Do3."

### `MUS-PITCH-005`
* **Term (IT):** scala musicale
* **Definition (IT):** Successione ordinata di altezze ascendenti o discendenti racchiuse nell'ambito di un'ottava secondo una definita struttura intervallare.
* **Plain Explanation (IT):** La sequenza coordinata di note usata per costruire una composizione.
* **English Equivalent:** musical scale
* **German Equivalent:** Tonleiter
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-003`
* **Related Concepts:** `MUS-PITCH-006`, `MUS-PITCH-007`
* **Source:** Open Music Theory v2 — Scales and Key Signatures.
* **Usage Example:** "La scala di Do contiene sette note distinte."

### `MUS-PITCH-006`
* **Term (IT):** scala maggiore
* **Definition (IT):** Scala eptatonica diatonica con successione intervallare ordinata: Tono - Tono - Semitono - Tono - Tono - Tono - Semitono.
* **Plain Explanation (IT):** La scala diatonica base dal carattere luminoso e stabile.
* **English Equivalent:** major scale
* **German Equivalent:** Dur-Tonleiter
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-005`
* **Related Concepts:** `MUS-PITCH-007`
* **Source:** Open Music Theory v2 — Major Scales.
* **Usage Example:** "La scala di Do maggiore è priva di alterazioni in chiave."

### `MUS-PITCH-007`
* **Term (IT):** scala minore
* **Definition (IT):** Scala eptatonica diatonica avente il terzo grado a distanza di un semitono e un tono dalla tonica (struttura naturale: T-S-T-T-S-T-T).
* **Plain Explanation (IT):** La scala caratterizzata da una sonorità più scura o malinconica.
* **English Equivalent:** minor scale
* **German Equivalent:** Moll-Tonleiter
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-005`
* **Related Concepts:** `MUS-PITCH-006`
* **Source:** Open Music Theory v2 — Minor Scales.
* **Usage Example:** "La scala di La minore naturale è la relativa minore di Do maggiore."

### `MUS-PITCH-008`
* **Term (IT):** tonalità
* **Definition (IT):** Sistema gerarchico di relazioni armoniche e melodiche organizzato attorno a una nota centro (tonica).
* **Plain Explanation (IT):** Il sistema che definisce la nota centrale e l'insieme di regole dell'intero brano.
* **English Equivalent:** tonality / key
* **German Equivalent:** Tonalität / Tonart
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-005`
* **Related Concepts:** `MUS-PITCH-009`
* **Source:** Open Music Theory v2 — Key Signatures.
* **Usage Example:** "Questo concerto è scritto nella tonalità di Sol maggiore."

### `MUS-PITCH-009`
* **Term (IT):** gradi della scala
* **Definition (IT):** Denominazione e posizione funzionale ordinali di ciascuna nota all'interno di una scala diatonica (es. Tonica, Dominante, Sensibile).
* **Plain Explanation (IT):** Il ruolo e la posizione specifica di ogni nota della scala.
* **English Equivalent:** scale degrees
* **German Equivalent:** Tonstufen / Skalenstufen
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-PITCH-005`
* **Related Concepts:** `MUS-HARM-001`
* **Source:** Open Music Theory v2 — Scale Degrees.
* **Usage Example:** "Il quinto grado della scala è chiamato dominante."

## Category 5: Melody & Harmony (9 Concepts)

### `MUS-MEL-001`
* **Term (IT):** melodia
* **Definition (IT):** Successione lineare orizzontale di altezze organizzata nel tempo dotata di senso compiuto, forma e ritmo.
* **Plain Explanation (IT):** La linea di note cantabile o principale che guida un brano.
* **English Equivalent:** melody
* **German Equivalent:** Melodie
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-MEL-002`, `MUS-MEL-003`, `MUS-HARM-001`
* **Source:** Open Music Theory v2 — Melody Construction.
* **Usage Example:** "La melodia del flauto è dolce e lineare."

### `MUS-MEL-002`
* **Term (IT):** motivo
* **Definition (IT):** La più piccola unità melodica o ritmica dotata di identità tematica definita e riconoscibile.
* **Plain Explanation (IT):** La brevissima cellula musicale ritmica o melodica che viene ripetuta o sviluppata.
* **English Equivalent:** motive / motif
* **German Equivalent:** Motiv
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-MEL-001`
* **Related Concepts:** `MUS-MEL-003`, `MUS-FORM-002`
* **Source:** Open Music Theory v2 — Motivic Analysis.
* **Usage Example:** "Il celebre motivo di quattro note apre la Quinta Sinfonia di Beethoven."

### `MUS-MEL-003`
* **Term (IT):** frase
* **Definition (IT):** Unità melodica di respiro compiuto, paragonabile alla proposizione nella sintassi linguistica, che termina con una cadenza.
* **Plain Explanation (IT):** Un'idea musicale completa composta da più motivi.
* **English Equivalent:** phrase
* **German Equivalent:** Phrasierung / Phrase
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-MEL-001`
* **Related Concepts:** `MUS-FORM-003`
* **Source:** Open Music Theory v2 — Phrase Structure.
* **Usage Example:** "La prima frase melodica si estende per quattro battute."

### `MUS-HARM-001`
* **Term (IT):** armonia
* **Definition (IT):** Dimensione verticale della musica che disciplina la sovrapposizione simultanea di più suoni e le regole della loro progressione.
* **Plain Explanation (IT):** La combinazione simultanea di note diverse a supporto della melodia.
* **English Equivalent:** harmony
* **German Equivalent:** Harmonie / Harmonielehre
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-HARM-002`, `MUS-HARM-003`
* **Source:** Open Music Theory v2 — Introduction to Harmony.
* **Usage Example:** "L'armonia del brano si basa sugli accordi principali di tonica e dominante."

### `MUS-HARM-002`
* **Term (IT):** accordo
* **Definition (IT):** Emissione simultanea di tre o più suoni di altezza diversa combinati secondo determinate regole armoniche.
* **Plain Explanation (IT):** Tre o più note suonate insieme nello stesso momento.
* **English Equivalent:** chord
* **German Equivalent:** Akkord
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-HARM-001`
* **Related Concepts:** `MUS-HARM-003`, `MUS-HARM-004`
* **Source:** Open Music Theory v2 — Triads and Seventh Chords.
* **Usage Example:** "L'accordo di Do maggiore è composto dalle note Do, Mi e Sol."

### `MUS-HARM-003`
* **Term (IT):** triade
* **Definition (IT):** Accordo base formato da tre note sovrapposte per intervalli di terza (fondamentale, terza, quinta).
* **Plain Explanation (IT):** L'accordo a tre note più semplice e comune in musica.
* **English Equivalent:** triad
* **German Equivalent:** Dreiklang
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-HARM-002`
* **Related Concepts:** `MUS-HARM-005`
* **Source:** Open Music Theory v2 — Triads.
* **Usage Example:** "Una triade maggiore contiene una terza maggiore e una quinta giusta."

### `MUS-HARM-004`
* **Term (IT):** arpeggio
* **Definition (IT):** Esecuzione delle note di un accordo in successione melodica anziché simultaneamente.
* **Plain Explanation (IT):** Le note di un accordo suonate una dopo l'altra.
* **English Equivalent:** arpeggio / broken chord
* **German Equivalent:** Arpeggio / gebrochener Akkord
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03` / `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-HARM-002`
* **Related Concepts:** `MUS-MEL-001`
* **Source:** Open Music Theory v2 — Accompaniment Patterns.
* **Usage Example:** "L'arpeggio di violoncello accompagna la melodia del pianoforte."

### `MUS-HARM-005`
* **Term (IT):** rivolto
* **Definition (IT):** Disposizione di un accordo in cui la nota fondamentale non si trova al basso ma è sostituita dalla terza, quinta o settima.
* **Plain Explanation (IT):** Il cambiamento dell'ordine delle note di un accordo lasciando una nota diversa alla base.
* **English Equivalent:** inversion
* **German Equivalent:** Umkehrung
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-HARM-002`
* **Related Concepts:** `MUS-HARM-003`
* **Source:** Open Music Theory v2 — Chord Inversions.
* **Usage Example:** "Il primo rivolto colloca la terza dell'accordo al basso."

### `MUS-HARM-006`
* **Term (IT):** cadenza
* **Definition (IT):** Formula di progressione armonica o melodica che conclude una frase, una sezione o un intero brano, creando senso di riposo o sospensione.
* **Plain Explanation (IT):** La punteggiatura musicale che chiude o sospende un discorso sonoro.
* **English Equivalent:** cadence
* **German Equivalent:** Kadenz
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03` / `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-HARM-001`
* **Related Concepts:** `MUS-MEL-003`
* **Source:** Open Music Theory v2 — Cadences.
* **Usage Example:** "La cadenza perfetta V-I conclude il movimento in modo risolutivo."

## Category 6: Expression & Articulation (7 Concepts)

### `MUS-EXPR-001`
* **Term (IT):** dinamica
* **Definition (IT):** Insieme delle indicazioni e graduazioni d'intensità sonora e di volume applicate durante l'esecuzione musicale.
* **Plain Explanation (IT):** I simboli e i termini che regolano il volume e le sue variazioni (es. forte, piano).
* **English Equivalent:** dynamics
* **German Equivalent:** Dynamik
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-ACOUST-005`, `MUS-EXPR-003`, `MUS-EXPR-004`
* **Source:** Open Music Theory v2 — Dynamics.
* **Usage Example:** "La dinamica passa da 'piano' a 'forte' nell'arco di due battute."

### `MUS-EXPR-002`
* **Term (IT):** indicazione di tempo
* **Definition (IT):** Termine convenzionale posto all'inizio del brano per stabilire il carattere e la velocità della pulsazione (es. Allegro, Adagio).
* **Plain Explanation (IT):** Le parole tradizionali italiane che guidano la velocità d'esecuzione.
* **English Equivalent:** tempo marking
* **German Equivalent:** Tempobezeichnung
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** `MUS-RHY-003`
* **Related Concepts:** `MUS-RHY-001`
* **Source:** Open Music Theory v2 — Tempo Markings.
* **Usage Example:** "L'indicazione 'Presto' richiede un'esecuzione rapida e vivace."

### `MUS-EXPR-003`
* **Term (IT):** crescendo
* **Definition (IT):** Indicazione dinamica d'espressione che prescrive un aumento graduale dell'intensità sonora.
* **Plain Explanation (IT):** Il passaggio graduale da un volume più basso a uno più alto.
* **English Equivalent:** crescendo
* **German Equivalent:** Crescendo / Lauter werden
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** `MUS-EXPR-001`
* **Related Concepts:** `MUS-EXPR-004`
* **Source:** Open Music Theory v2 — Dynamics & Expression.
* **Usage Example:** "Il crescendo dell'orchestra crea una forte tensione drammatica."

### `MUS-EXPR-004`
* **Term (IT):** diminuendo
* **Definition (IT):** Indicazione dinamica d'espressione che prescrive una riduzione graduale dell'intensità sonora (sinonimo: decrescendo).
* **Plain Explanation (IT):** La riduzione graduale del volume sonoro.
* **English Equivalent:** diminuendo / decrescendo
* **German Equivalent:** Diminuendo / Leiser werden
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** `MUS-EXPR-001`
* **Related Concepts:** `MUS-EXPR-003`
* **Source:** Open Music Theory v2 — Dynamics & Expression.
* **Usage Example:** "La frase sfuma in un diminuendo fino al silenzio."

### `MUS-EXPR-005`
* **Term (IT):** legato
* **Definition (IT):** Articolazione esecutiva che richiede di legare i suoni in un flusso continuo senza interruzioni udibili tra le note.
* **Plain Explanation (IT):** Suonare le note sfiorandole l'una all'altra senza stacchi.
* **English Equivalent:** legato
* **German Equivalent:** Legato / gebunden
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-EXPR-006`
* **Source:** Open Music Theory v2 — Articulations.
* **Usage Example:** "La linea cantabile del flauto deve essere eseguita perfettamente legata."

### `MUS-EXPR-006`
* **Term (IT):** staccato
* **Definition (IT):** Articolazione esecutiva che prescrive di separare nettamente le note accorciandone la durata effettiva rispetto al valore scritto.
* **Plain Explanation (IT):** Suonare le note staccate e brevi l'una dall'altra.
* **English Equivalent:** staccato
* **German Equivalent:** Staccato / getrennt
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-EXPR-005`
* **Source:** Open Music Theory v2 — Articulations.
* **Usage Example:** "Gli archi eseguono uno staccato leggero e brillante."

### `MUS-EXPR-007`
* **Term (IT):** corona
* **Definition (IT):** Simbolo grafico (𝄐) posto sopra una nota o una pausa che autorizza l'esecutore a prolungarne a discrezione la durata oltre il valore nominale (anche detto fermata).
* **Plain Explanation (IT):** Il segno che indica di sostenere la nota o la pausa a piacere.
* **English Equivalent:** fermata
* **German Equivalent:** Fermate
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05` / `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-NOT-005`, `MUS-RHY-003`
* **Source:** Open Music Theory v2 — Other Notation Symbols.
* **Usage Example:** "Il brano termina con una corona sull'accordo finale."

## Category 7: Musical Structure & Form (6 Concepts)

### `MUS-FORM-001`
* **Term (IT):** introduzione
* **Definition (IT):** Sezione preparatoria iniziale di un brano musicale che precede l'esposizione del tema principale.
* **Plain Explanation (IT):** La parte iniziale che prepara l'ingresso della melodia principale.
* **English Equivalent:** introduction
* **German Equivalent:** Einleitung / Intro
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-FORM-002`
* **Source:** Open Music Theory v2 — Formal Functions.
* **Usage Example:** "L'introduzione strumentale stabilisce il tempo e l'atmosfera del brano."

### `MUS-FORM-002`
* **Term (IT):** tema
* **Definition (IT):** Melodia o struttura armonica di primaria importanza su cui si basa l'intera costruzione o lo sviluppo di una composizione.
* **Plain Explanation (IT):** L'idea musicale principale di un'opera.
* **English Equivalent:** theme
* **German Equivalent:** Thema
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-MEL-001`, `MUS-FORM-004`
* **Source:** Open Music Theory v2 — Form and Theme.
* **Usage Example:** "Il tema viene variato tre volte nel secondo movimento."

### `MUS-FORM-003`
* **Term (IT):** periodo
* **Definition (IT):** Struttura formale composta dall'unione di due frasi musicali correlate, denominate antecedente e conseguente.
* **Plain Explanation (IT):** La combinazione di una frase di 'domanda' e una frase di 'risposta'.
* **English Equivalent:** period
* **German Equivalent:** Periode
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-MEL-003`
* **Related Concepts:** `MUS-HARM-006`
* **Source:** Open Music Theory v2 — The Period.
* **Usage Example:** "Un periodo diatonico regolare comprende otto battute."

### `MUS-FORM-004`
* **Term (IT):** sezione
* **Definition (IT):** Porzione autonoma e distinta della struttura macro-formale di un brano definita da un proprio tema o tonalità.
* **Plain Explanation (IT):** Un blocco formale completo all'interno della struttura della composizione.
* **English Equivalent:** section
* **German Equivalent:** Formteil / Abschnitt
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-FORM-005`
* **Source:** Open Music Theory v2 — Formal Archetypes.
* **Usage Example:** "La sezione centrale presenta un cambio di tonalità."

### `MUS-FORM-005`
* **Term (IT):** ritornello
* **Definition (IT):** Sezione di un brano musicale che si ripete periodicamente ad intervalli regolari alternandosi a sezioni variabili (strofe o episodi).
* **Plain Explanation (IT):** La parte di testo e musica che si ripete identica più volte nel brano.
* **English Equivalent:** refrain / chorus
* **German Equivalent:** Refrain
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** `MUS-FORM-004`
* **Related Concepts:** `MUS-FORM-002`
* **Source:** Open Music Theory v2 — Rondo and Pop Forms.
* **Usage Example:** "Il ritornello ritorna tre volte durante la canzone."

### `MUS-FORM-006`
* **Term (IT):** coda
* **Definition (IT):** Sezione conclusiva aggiunta al termine di una composizione per rafforzare la cadenza finale e dare senso di chiusura definitiva.
* **Plain Explanation (IT):** La parte finale aggiunta per concludere in modo deciso il brano.
* **English Equivalent:** coda
* **German Equivalent:** Coda
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-03`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-HARM-006`
* **Source:** Open Music Theory v2 — Coda and Codetta.
* **Usage Example:** "La brillante coda finale accelera progressivamente il tempo."

## Category 8: Instruments & Execution (6 Concepts)

### `MUS-INST-001`
* **Term (IT):** famiglie degli strumenti
* **Definition (IT):** Classificazione degli strumenti musicali basata sul meccanismo di produzione del suono (archi, legni, ottoni, percussioni, tastiere).
* **Plain Explanation (IT):** I gruppi principali in cui vengono divisi gli strumenti musicali.
* **English Equivalent:** instrument families
* **German Equivalent:** Instrumentenfamilien
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-INST-002`
* **Source:** Open Music Theory v2 — Orchestration.
* **Usage Example:** "I legni e gli ottoni costituiscono la sezione fiati dell'orchestra."

### `MUS-INST-002`
* **Term (IT):** registro
* **Definition (IT):** Porzione dell'estensione complessiva di uno strumento o di una voce dotata di una specifica e omogenea qualità timbrica (es. acuto, medio, grave).
* **Plain Explanation (IT):** La fascia di note (grave, media, acuta) in cui uno strumento suona.
* **English Equivalent:** register
* **German Equivalent:** Register
* **Domain Layer:** Physical Acoustics / Expressive
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-INST-001`
* **Related Concepts:** `MUS-INST-003`, `MUS-ACOUST-007`
* **Source:** Open Music Theory v2 — Vocal & Instrumental Ranges.
* **Usage Example:** "Il clarinetto esegue la linea principale nel suo registro acuto."

### `MUS-INST-003`
* **Term (IT):** tessitura
* **Definition (IT):** Ambito di altezze all'interno del quale una parte vocale o strumentale si sviluppa con maggiore naturalezza e frequenza.
* **Plain Explanation (IT):** L'estensione di note più comoda e usata da una voce o strumento in un determinato brano.
* **English Equivalent:** tessitura
* **German Equivalent:** Stimmliche Lage / Tessitur
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-04`
* **Status:** `declared`
* **Parent Concept:** `MUS-INST-002`
* **Related Concepts:** `MUS-ACOUST-003`
* **Source:** Open Music Theory v2 — Vocal Ranges.
* **Usage Example:** "La tessitura della parte del tenore è particolarmente elevata."

### `MUS-INST-004`
* **Term (IT):** partitura
* **Definition (IT):** Layout grafico a vista complessiva contenente la sovrapposizione di tutti i righi musicali dei singoli strumenti o voci dell'organico.
* **Plain Explanation (IT):** Il libro musicale completo usato dal direttore d'orchestra che mostra le parti di tutti i musicisti.
* **English Equivalent:** full score
* **German Equivalent:** Partitur
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** None
* **Related Concepts:** `MUS-INST-005`
* **Source:** Open Music Theory v2 — Reading Scores.
* **Usage Example:** "Il direttore d'orchestra segue l'esecuzione sulla partitura generale."

### `MUS-INST-005`
* **Term (IT):** parte staccata
* **Definition (IT):** Documento notato contenente esclusivamente le note destinate al singolo esecutore o sezione strumentale.
* **Plain Explanation (IT):** Il foglio di musica destinato al singolo instrumentalista.
* **English Equivalent:** part / individual part
* **German Equivalent:** Einzelstimme / Stimme
* **Domain Layer:** Musical Notation & Theory
* **Provisional AXIS10 Mapping:** `AXIS-08`
* **Status:** `declared`
* **Parent Concept:** `MUS-INST-004`
* **Related Concepts:** `MUS-INST-006`
* **Source:** Open Music Theory v2 — Score Layouts.
* **Usage Example:** "Ogni leggio del primo violino riceve la propria parte staccata."

### `MUS-INST-006`
* **Term (IT):** organico
* **Definition (IT):** L'insieme coordinato degli strumenti o delle voci prescritto dal compositore per l'esecuzione di un'opera (es. quartetto, orchestra).
* **Plain Explanation (IT):** La formazione di musicisti necessaria per suonare un brano.
* **English Equivalent:** ensemble / instrumentation
* **German Equivalent:** Besetzung / Ensemble
* **Domain Layer:** Expressive / Performance Interpretation
* **Provisional AXIS10 Mapping:** `AXIS-05`
* **Status:** `declared`
* **Parent Concept:** `MUS-INST-001`
* **Related Concepts:** `MUS-INST-004`
* **Source:** Open Music Theory v2 — Orchestration.
* **Usage Example:** "L'organico richiesto prevede archi, legni e pianoforte."