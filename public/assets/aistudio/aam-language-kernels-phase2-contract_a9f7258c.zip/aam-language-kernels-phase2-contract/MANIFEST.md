# AAM Language Kernels — Phase 2 Contract Package

Purpose: introduce explicit, language-neutral contracts for lexical stress lookup and metrical templates, without implementing a metric-verification engine.

## Files
- `shared/interfaces/lexical_stress.ts` — lexical stress lookup contract; distinguishes dictionary evidence from heuristic inference.
- `shared/interfaces/metrical_templates.ts` — declarative template schema for metrical patterns and positions.
- `docs/PHASE2_CONTRACTS.md` — definitions, constraints, and acceptance criteria.
- `examples/metrical-template.example.json` — illustrative data only; not an authoritative cultural or scholarly claim.
- `README-INTEGRATION-PROMPT.md` — instructions for integrating into the existing repository.

## Integration rule
These files are additive. Do not replace existing files wholesale. If the current repository has equivalent types, reconcile names and imports minimally and document the mapping.

## Non-goals
No MetricVerifier implementation, no rhyme engine, no automatic stress prediction, no claim that Ukrainian or Italian metrical patterns are fully validated.
