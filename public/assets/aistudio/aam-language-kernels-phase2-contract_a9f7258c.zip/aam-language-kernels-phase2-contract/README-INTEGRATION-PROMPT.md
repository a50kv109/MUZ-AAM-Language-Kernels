# Google AI Studio — Integration Prompt

Integrate the attached `aam-language-kernels-phase2-contract.zip` into the existing `language-kernels-collection` repository.

This is a prepared additive contract package. It is not a request to invent a new architecture.

## Instructions
1. Read `MANIFEST.md` and `docs/PHASE2_CONTRACTS.md`.
2. Add the two TypeScript interface files under `shared/interfaces/`.
3. If equivalent interfaces already exist in the current repository, reconcile them minimally rather than duplicating competing contracts. Explain any deviations.
4. Keep the JSON example clearly marked as illustrative and unvalidated.
5. Do not implement runtime engines or alter current syllable analysis behavior.
6. Do not implement `MetricVerifier`, `RhymeEngine`, stress prediction, or language-specific metrical rules.
7. Run the repository's actual typecheck and tests. Report exact commands and outcomes.
8. Update the roadmap only to reflect that Phase 2 contracts have been drafted/integrated; do not mark empirical validation or engine implementation complete.
9. Report changed files, compatibility issues, checks performed, and remaining limitations.

Do not claim that a contract is an implementation or that a template is validated merely because the types compile.
