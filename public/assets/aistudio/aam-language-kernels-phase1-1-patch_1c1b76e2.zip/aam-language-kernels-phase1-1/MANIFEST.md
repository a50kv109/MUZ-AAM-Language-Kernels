# AAM Language Kernels — Phase 1.1 Patch Package

This package contains concrete replacement files and an integration directive for Google AI Studio.

The package manifest declares the direct dev dependencies (`typescript`, `tsx`, `@types/node`) locally. `tsconfig.json` no longer points at the parent workspace's `node_modules`. The documentation replacements narrow claims to what is actually evidenced and define the Phase 1.1 exit criteria.

Important: this patch has not been executed in the target Google AI Studio environment. A `package-lock.json` is intentionally not fabricated; generate it with npm after dependency resolution in the target environment.
