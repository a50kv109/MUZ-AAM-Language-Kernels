# Google AI Studio Integration Prompt — Phase 1.1 Patch

Apply the supplied patch files to the existing `language-kernels-collection` directory. These are concrete proposed replacements, not a request to redesign the repository.

## Files supplied

- `language-kernels-collection/package.json`
- `language-kernels-collection/tsconfig.json`
- `language-kernels-collection/docs/TESTING_AND_EVIDENCE.md`
- `language-kernels-collection/docs/REPOSITORY_STATUS.md`

## Integration instructions

1. Compare each supplied file with the current workspace version and apply these replacements in the existing project.
2. Preserve unrelated files and existing architecture. Do not regenerate or rewrite the repository.
3. From `language-kernels-collection`, run `npm install`, then `npm run typecheck` and `npm test`. If the environment cannot reach the package registry, report the exact error; do not claim the commands passed.
4. Generate and commit `package-lock.json` using npm in the target environment after successful dependency resolution. Do not fabricate a lockfile by hand.
5. Inspect the Italian inventories' per-record `Status` fields. The supplied policy means `verified` must not imply source review unless that review is evidenced. Make the smallest safe correction consistent with the existing schema; do not rewrite concepts or invent sources.
6. Check `registry.yaml` paths and the capability status vocabulary. Do not introduce new engines.
7. Report changed files, exact command outputs, and unresolved blockers. Distinguish changes supplied by this patch from any additional edits you make.

The purpose is to close reproducibility and evidence-policy gaps. Do not implement `MetricVerifier` or `RhymeEngine` in this phase.
