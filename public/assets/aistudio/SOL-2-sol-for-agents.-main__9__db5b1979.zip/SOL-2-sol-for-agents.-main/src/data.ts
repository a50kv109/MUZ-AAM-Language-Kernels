import { SolPrimitive, QuestionNode, CaseStudy, OpenQuestionItem } from './types';

export const SOL_PRIMITIVES: SolPrimitive[] = [
  {
    id: 'source',
    name: 'SOURCE',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'GENESIS ANCHOR',
    summary: 'Якорь происхождения. Фиксация генезиса объекта, данных или энергии.',
    formalDefinition: 'Исходная точка и неразрывный каузальный якорь, который сохраняется неизменным при любых последующих трансформациях формы.',
    antiDefinition: 'НЕ означает просто «информацию», «файл» или «текст». Это именно фиксатор первоисточника.',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'state',
    name: 'STATE',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'IMMUTABLE SNAPSHOT',
    summary: 'Неизменяемый снимок. Фиксация статуса, структуры или метрики среды в конкретный момент.',
    formalDefinition: 'Дискретная остановка потока для образования наблюдаемого узла с фиксированными параметрами.',
    antiDefinition: 'НЕ означает «содержимое» (content) само по себе, а временную или топологическую фиксацию среды.',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'flow',
    name: 'FLOW',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'VECTOR OF TRANSFER',
    summary: 'Вектор переноса. Направленная передача каузальной нагрузки, данных или энергии.',
    formalDefinition: 'Направленный перенос от одного узла к другому без изменения исходного генезиса (SOURCE).',
    antiDefinition: 'НЕ означает качественную трансформацию внутренней структуры или мутацию объекта.',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'constraint',
    name: 'CONSTRAINT',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'ABSOLUTE BOUNDARY',
    summary: 'Абсолютная граница. Правило, барьер, лимит, допуск или фильтр степеней свободы.',
    formalDefinition: 'Структурный инвариант системы, определяющий допустимое фазовое пространство состояний.',
    antiDefinition: 'НЕ является условным оператором «если/то» (Condition) — это ненарушимый барьер.',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'compare',
    name: 'COMPARE',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'DELTA PROCESSOR',
    summary: 'Дельта-процессор. Вычисление разницы (дельты), сверка двух состояний или состояния и границы.',
    formalDefinition: 'Вычислительный оператор дифференциации между состояниями STATE_A и STATE_B либо STATE и CONSTRAINT.',
    antiDefinition: 'НЕ является действием «выбор» (действие выбора — это следствие вычисленной дельты).',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'capability',
    name: 'CAPABILITY',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'EXECUTIVE RIGHT',
    summary: 'Право на действие. Операционный контракт, исполнительная власть, полномочие агента.',
    formalDefinition: 'Легитимный контракт, наделяющий агента полномочием инициировать фазовый переход.',
    antiDefinition: 'НЕ является самим физическим действием или фактом его выполнения.',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'dissipate',
    name: 'DISSIPATE',
    level: 0,
    levelLabel: 'Universal Canon (O7)',
    tag: 'ENTROPY SINK',
    summary: 'Сток энтропии. Поглощение шума, сброс отработанных состояний, демпфирование.',
    formalDefinition: 'Механизм термодинамического или логического сброса тупиковых ветвей и избыточных состояний.',
    antiDefinition: 'НЕ означает физическое уничтожение источника генезиса (SOURCE).',
    status: 'CANONICAL',
    domainContext: 'Универсальное детерминированное ядро (O7)'
  },
  {
    id: 'index',
    name: 'INDEX',
    level: 0,
    levelLabel: 'System Extension',
    tag: 'TOPOLOGICAL MAP',
    summary: 'Топологическая карта / указатель связей (структура графа или таблицы).',
    formalDefinition: 'Системное расширение среды исполнения для адресации и взаимного расположения узлов.',
    antiDefinition: 'Не примитив первого порядка, а системная топология координации.',
    status: 'CANONICAL',
    domainContext: 'Среда исполнения графов и таблиц'
  },
  {
    id: 'coordinate_space',
    name: 'COORDINATE_SPACE',
    level: 0,
    levelLabel: 'System Extension',
    tag: 'RUNTIME METRIC',
    summary: 'Рантайм-метрика / система отсчета для непрерывных и дискретных пространств.',
    formalDefinition: 'Метрический базис для определения расстояний, направлений и пространственных векторов.',
    antiDefinition: 'Не объект, а система отсчета анализируемого континуума.',
    status: 'CANONICAL',
    domainContext: 'Среда непрерывных и векторных измерений'
  },
  {
    id: 'transform',
    name: 'TRANSFORM',
    level: 1,
    levelLabel: 'Domain Canon',
    tag: 'MUTATION OF FORM',
    summary: 'Мутация формы. Качественное изменение структуры объекта при сохранении его генезиса.',
    formalDefinition: 'Перевод STATE(A) в STATE(B) через вектор FLOW при едином инвариантном SOURCE.',
    antiDefinition: 'Не создание новой сущности «с нуля» — сохраняется ссылка на SOURCE.',
    reductionEquation: 'STATE(A) → FLOW → STATE(B) [при едином SOURCE]',
    status: 'DOMAIN_CANDIDATE',
    domainContext: 'Инженерия, компиляция кода, трансформация данных'
  },
  {
    id: 'evidence',
    name: 'EVIDENCE',
    level: 1,
    levelLabel: 'Domain Canon',
    tag: 'PROOF OF LEGITIMACY',
    summary: 'След легитимности. Доказуемое основание (подпись, сертификат, математическое доказательство).',
    formalDefinition: 'Фиксированное состояние валидации перехода, подтвержденное сверкой с критерием.',
    antiDefinition: 'Не просто текст документа, а верифицированный инвариант легитимности.',
    reductionEquation: 'STATE (факт) + COMPARE (с критерием CONSTRAINT)',
    status: 'DOMAIN_CANDIDATE',
    domainContext: 'Документооборот, формальная логика, смарт-контракты'
  },
  {
    id: 'sutra_rule',
    name: 'SŪTRA / RULE',
    level: 1,
    levelLabel: 'Domain Canon',
    tag: 'TRIGGER LOGIC',
    summary: 'Триггерная логика. Алгоритмическое правило перехода «Если С, примени Т, соблюдая границы».',
    formalDefinition: 'Устойчивая композиция логического условия, трансформации и границы.',
    antiDefinition: 'Не базовый кирпич, а частотная идиома доменного слоя.',
    reductionEquation: 'CONSTRAINT + CONDITION + TRANSFORM/FLOW',
    status: 'DOMAIN_CANDIDATE',
    domainContext: 'Бизнес-логика, компиляторы, нормативные правила'
  },
  {
    id: 'align_sync',
    name: 'ALIGN / SYNC',
    level: 1,
    levelLabel: 'Domain Canon',
    tag: 'HARMONIZATION',
    summary: 'Гармонизация. Синхронизация нескольких независимых потоков к единому стандарту.',
    formalDefinition: 'Выравнивание множественных векторов переноса по единой метрике инварианта.',
    antiDefinition: 'Не просто параллелизм, а сопряжение фаз.',
    reductionEquation: 'FLOW_1..N + COMPARE + CONSTRAINT',
    status: 'DOMAIN_CANDIDATE',
    domainContext: 'Сетевые и распределенные протоколы консенсуса'
  },
  {
    id: 'merge_resolution',
    name: 'MERGE_RESOLUTION',
    level: 2,
    levelLabel: 'Project Canon',
    tag: 'HUMAN-IN-THE-LOOP RESOLUTION',
    summary: 'Ручное разрешение конфликта. Вмешательство агента при неразрешимом столкновении потоков.',
    formalDefinition: 'Агентный акт устранения нарушения границы при слиянии конкурирующих векторов FLOW.',
    antiDefinition: 'Не автоматический мердж, а именно ручной арбитраж при нарушении CONSTRAINT.',
    reductionEquation: 'FLOW + COMPARE + CONSTRAINT violation + CAPABILITY (Agent)',
    status: 'PROJECT_CANDIDATE',
    domainContext: 'Системы контроля версий (Git), юридический арбитраж'
  },
  {
    id: 'recurse',
    name: 'RECURSE',
    level: 2,
    levelLabel: 'Project Canon',
    tag: 'SELF-INCLUSION',
    summary: 'Самовложенность. Применение структуры внутрь самой себя.',
    formalDefinition: 'Топологический обход дерева с циклическим замыканием вектора переноса.',
    antiDefinition: 'Отклонён как универсальный примитив — полностью редуцируется.',
    reductionEquation: 'INDEX (топология) + FLOW (зацикленный вектор)',
    status: 'PROJECT_CANDIDATE',
    domainContext: 'Фрактальные графы, рекурсивные алгоритмы'
  }
];

export const QUESTION_SPACE: QuestionNode[] = [
  {
    id: 'what',
    question: 'WHAT?',
    questionRu: 'ЧТО ЭТО?',
    category: 'root',
    uncertaintyCleared: 'Онтологическая неопределенность (есть ли объект / сущность / система вообще?)',
    exampleObservation: 'В системе зафиксированы дискретные узлы с данными (STATE) или источник (SOURCE).',
    typicalNextSteps: ['what_changes', 'how', 'who']
  },
  {
    id: 'how',
    question: 'HOW?',
    questionRu: 'КАК ЭТО РАБОТАЕТ?',
    category: 'root',
    uncertaintyCleared: 'Алгоритмическая / механистическая неопределенность (каковы связи и переходы?)',
    exampleObservation: 'Обнаружен механизм передачи данных между узлами (FLOW) или трансформация.',
    typicalNextSteps: ['from_where', 'under_what_conditions', 'what_can_fail']
  },
  {
    id: 'from_where',
    question: 'FROM WHERE?',
    questionRu: 'ОТКУДА / ИЗ КАКОГО ИСТОЧНИКА?',
    category: 'domain',
    uncertaintyCleared: 'Казуальная неопределенность генезиса (откуда поступает энергия или данные?)',
    exampleObservation: 'Каузальный якорь уходит к физическому сенсору или неизменяемому логу (SOURCE).',
    typicalNextSteps: ['how', 'on_what_basis']
  },
  {
    id: 'who',
    question: 'WHO / WHOM?',
    questionRu: 'КТО / КТО ИНИЦИИРУЕТ?',
    category: 'domain',
    uncertaintyCleared: 'Агентная неопределенность (кто обладает полномочиями или субъектностью?)',
    exampleObservation: 'Акт подписания документа требует роли аудитора (CAPABILITY). В физических системах = NULL.',
    typicalNextSteps: ['why', 'on_what_basis'],
    inapplicableCases: 'Неприменимо к неживым и чисто физическим системам (Таблица Менделеева, гидродинамика).'
  },
  {
    id: 'why',
    question: 'WHY / FOR WHAT PURPOSE?',
    questionRu: 'ЗАЧЕМ / С КАКОЙ ЦЕЛЬЮ?',
    category: 'domain',
    uncertaintyCleared: 'Телеологическая неопределенность (какова функция, намерение или оптимизационная цель?)',
    exampleObservation: 'Система минимизирует задержку сети или выполняет бизнес-контракт.',
    typicalNextSteps: ['under_what_conditions'],
    inapplicableCases: 'Опасно в естественных науках (эволюция не имеет «цели выжить» — риск телеологической ошибки).'
  },
  {
    id: 'what_changes',
    question: 'WHAT CHANGES?',
    questionRu: 'ЧТО ИЗМЕНЯЕТСЯ?',
    category: 'diagnostic',
    uncertaintyCleared: 'Динамическая дельта (какие атрибуты мутируют при переходе?)',
    exampleObservation: 'Периодическое изменение атомного радиуса или обновление версии файла.',
    typicalNextSteps: ['what_remains_invariant', 'how']
  },
  {
    id: 'what_remains_invariant',
    question: 'WHAT REMAINS INVARIANT?',
    questionRu: 'ЧТО ОСТАЕТСЯ НЕИЗМЕННЫМ?',
    category: 'diagnostic',
    uncertaintyCleared: 'Инвариантное ядро (какой закон или якорь сохраняется при любых переходах?)',
    exampleObservation: 'Сумма квадратов катетов равна квадрату гипотенузы; хэш коммита в дереве.',
    typicalNextSteps: ['on_what_basis']
  },
  {
    id: 'on_what_basis',
    question: 'ON WHAT BASIS?',
    questionRu: 'НА КАКОМ ОСНОВАНИИ?',
    category: 'diagnostic',
    uncertaintyCleared: 'Легитимность и достаточность доказательной базы (EVIDENCE).',
    exampleObservation: 'Наличие цифровой подписи или формального аксиоматического вывода.',
    typicalNextSteps: ['under_what_conditions']
  },
  {
    id: 'under_what_conditions',
    question: 'UNDER WHAT CONDITIONS?',
    questionRu: 'ПРИ КАКИХ УСЛОВИЯХ?',
    category: 'diagnostic',
    uncertaintyCleared: 'Границы применимости и правила перехода (CONSTRAINT / RULE).',
    exampleObservation: 'Температура ниже 85°C, права администратора подтверждены.',
    typicalNextSteps: ['what_can_fail']
  },
  {
    id: 'what_can_fail',
    question: 'WHAT CAN FAIL?',
    questionRu: 'ЧТО МОЖЕТ СЛОМАТЬСЯ?',
    category: 'counterfactual',
    uncertaintyCleared: 'Граничные пределы и точки отказа (Semantic Loss / Merge Conflicts / Overflow).',
    exampleObservation: 'Одновременный коммит в одну строку файла порождает неразрешимый Merge Conflict.',
    typicalNextSteps: ['how', 'on_what_basis']
  }
];

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'case_mendeleev',
    code: 'CASE-01',
    title: 'Периодическая таблица Менделеева',
    domain: 'Физическая химия / Естественные науки',
    systemDescription: 'Классификация 118 химических элементов по заряду ядра и периодичности свойств.',
    qSpaceTrajectory: ['WHAT? (Атомы)', 'HOW? (Возрастание заряда Z)', 'WHAT CHANGES? (Свойства)', 'WHO? (НЕПРИМЕНИМО)'],
    findings: 'Линейная траектория, завершение на STATE + INDEX + COMPARE. Ветка WHO/WHY полностью отсечена.',
    discoveredPrimitiveOrResidue: 'Доказана адаптивность Q-Space (не все вопросы обязательны для каждой системы).',
    epistemicLesson: 'Вопросы агентности (WHO) и телеологии (WHY) к физическим системам порождают галлюцинации.',
    methodologyImpact: 'Введено правило: Ограничительные вопросы детерминированно блокируют ложные ветви.'
  },
  {
    id: 'case_pythagoras',
    code: 'CASE-02',
    title: 'Теорема Пифагора и дедуктивная логика',
    domain: 'Евклидова геометрия / Формальные системы',
    systemDescription: 'Аксиоматический геометрический вывод соотношения сторон прямоугольного треугольника.',
    qSpaceTrajectory: ['WHAT? (Треугольник/Квадраты)', 'HOW? (Логический вывод)', 'ON WHAT BASIS? (Аксиомы)', 'WHEN? (НЕПРИМЕНИМО)'],
    findings: 'Выявила потребность в EVIDENCE (легитимация шага) и перенесла агентность на мета-уровень рассуждающего математика.',
    discoveredPrimitiveOrResidue: 'EVIDENCE (Кандидат Domain Canon: STATE факта + COMPARE с аксиомой).',
    epistemicLesson: 'Вневременная истина не требует оси WHEN, но требует непрерывной цепочки EVIDENCE.',
    methodologyImpact: 'Утверждено различие между онтологией системы и мета-наблюдателем.'
  },
  {
    id: 'case_git',
    code: 'CASE-03',
    title: 'Система контроля версий Git',
    domain: 'Software Engineering / Distributed Systems',
    systemDescription: 'Направленный ациклический граф (DAG) коммитов, слияние веток и разрешение коллизий.',
    qSpaceTrajectory: ['WHAT? (Blob/Tree/Commit)', 'HOW? (Merge branches)', 'WHAT CAN FAIL? (Merge conflict)', 'WHO? (Developer resolution)'],
    findings: 'Обнаружен нередуцируемый остаток при возникновении конфликта слияния.',
    discoveredPrimitiveOrResidue: 'MERGE_RESOLUTION (Project Canon: ручной арбитраж при нарушении границы).',
    epistemicLesson: 'Попытка сжать merge conflict только в FLOW+COMPARE теряет семантику человеческой агентности.',
    methodologyImpact: 'Подтвержден закон: Composable ≠ Unnecessary. Доменный концепт сохраняет критический контекст.'
  },
  {
    id: 'case_dle',
    code: 'CASE-04',
    title: 'Document Lifecycle Engine (DLE)',
    domain: 'Enterprise Information Systems / Legal Tech',
    systemDescription: 'Жизненный цикл юридических документов, валидация подписей и защита от несанкционированных действий.',
    qSpaceTrajectory: ['WHAT? (Document Snapshot)', 'ON WHAT BASIS? (Signature log)', 'WHO? (Authority Role)', 'WHAT CAN FAIL? (Authority Drift)'],
    findings: 'Принцип библиотекаря (Librarian Principle): чтение текста документа не передает агенту права на действие.',
    discoveredPrimitiveOrResidue: 'Защита от Authority Drift (разделение STATE чтения и CAPABILITY исполнения).',
    epistemicLesson: 'Семантическое свойство документа не должно смешиваться с рантайм-полномочиями агента.',
    methodologyImpact: 'Введена изоляция внешних проектов: DLE является CASE STUDY, а не частью SOL.'
  },
  {
    id: 'case_vygotsky',
    code: 'CASE-05',
    title: 'Психологические орудия Выготского',
    domain: 'Когнитивная эпистемология / Теория деятельности',
    systemDescription: 'Использование внешних знаковых систем и инструментов для трансформации структуры мышления.',
    qSpaceTrajectory: ['WHAT? (Q-Space Navigator)', 'HOW? (Externalized heuristic)', 'WHY? (Restructure agent reasoning)'],
    findings: 'SOL-2 выступает внешним когнитивным орудием для AI-агента, перенося выбор пути во внешнюю среду.',
    discoveredPrimitiveOrResidue: 'Концептуальный фундамент SOL-2 как инструментальной среды навигации.',
    epistemicLesson: 'Инструмент не просто ускоряет вычисления, он меняет саму топологию мышления агента.',
    methodologyImpact: 'Утвержден статус SOL-2: Cognitive Tooling Environment, а не просто библиотека классов.'
  }
];

export const OPEN_QUESTIONS: OpenQuestionItem[] = [
  {
    id: 'oq_01',
    code: 'OQ-01',
    title: 'Вопросы-Ограничители (Constraint Questions)',
    status: 'RESEARCH_HYPOTHESIS',
    description: 'Существуют ли мета-вопросы, которые не порождают аспекты, а детерминированно блокируют целые нерелевантные ветви Q-Space?',
    implication: 'Если система физическая, вопрос «Обладает ли система агентностью?» возвращает FALSE и блокирует подграфы WHO и WHY, предотвращая телеологические галлюцинации.',
    counterexample: 'В биологических системах (эволюция) агентности нет, но телеологический вопрос интуитивно напрашивается.'
  },
  {
    id: 'oq_02',
    code: 'OQ-02',
    title: 'Операционализация Semantic Loss Test',
    status: 'OPEN',
    description: 'Как формализовать количественный или дискретный порог потери смысла при редукции нового явления к универсальному O7?',
    implication: 'Когда мы говорим, что при сжатии MERGE_RESOLUTION до FLOW+COMPARE «теряется человеческий фактор», как агенту алгоритмически зафиксировать этот порог?',
    counterexample: 'Чрезмерно мягкий тест приведет к раздуванию словаря примитивов; чрезмерно жесткий — к потере доменных смыслов.'
  },
  {
    id: 'oq_03',
    code: 'OQ-03',
    title: 'Защита от Aspect Leakage (Утечки аспектов)',
    status: 'PROVISIONAL',
    description: 'Как предотвратить подмену нейтрального наблюдения (Raw Observation) терминами SOL до завершения анализа?',
    implication: 'Если агент пишет «Наблюдение: здесь есть FLOW», он нарушает 4-шаговый шлюз и подгоняет систему под заранее выбранный ответ.',
    counterexample: 'Требуется строгая изоляция естественного языка описания от семантического сопоставления.'
  },
  {
    id: 'oq_04',
    code: 'OQ-04',
    title: 'Дискретность SOL vs Непрерывные континуумы',
    status: 'OPEN',
    description: 'Способно ли ядро O7 адекватно описывать непрерывные градиенты (температурные поля, квантовые суперпозиции) без искусственного квантования?',
    implication: 'Примитив STATE фиксирует снимок. В непрерывном поле нарезание на STATE_1, STATE_2 создает артефакты дискретизации.',
    counterexample: 'Расширение COORDINATE_SPACE частично закрывает эту брешь, но требует отдельного исследования.'
  }
];
