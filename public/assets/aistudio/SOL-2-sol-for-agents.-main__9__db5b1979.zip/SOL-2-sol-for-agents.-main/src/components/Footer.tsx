import React from 'react';
import { ShieldCheck, Activity, Terminal } from 'lucide-react';

interface FooterProps {
  statusMessage?: string;
  bufferCount?: number;
}

export const Footer: React.FC<FooterProps> = ({
  statusMessage = 'Observation Gateway Active',
  bufferCount = 42
}) => {
  return (
    <footer className="border-t-2 border-[#1C1C1C] bg-[#1C1C1C] text-[#F9F8F3] px-4 md:px-8 py-2.5 flex flex-col sm:flex-row justify-between items-center text-[10px] uppercase tracking-widest font-mono font-bold shrink-0 gap-2">
      <div className="flex flex-wrap items-center gap-4 sm:gap-6">
        <div className="flex items-center gap-1.5 text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
          <span>System Status: {statusMessage}</span>
        </div>
        <div className="text-[#F9F8F3]/60 flex items-center gap-1.5">
          <Activity className="w-3 h-3 text-[#D9D1C1]" />
          <span>Buffer: {bufferCount} Knowledge Artifacts</span>
        </div>
        <div className="hidden md:flex items-center gap-1.5 text-[#F9F8F3]/70">
          <Terminal className="w-3 h-3" />
          <span>Mode: Accumulate → Classify → Synthesize</span>
        </div>
      </div>
      <div className="text-[#D9D1C1]/70 italic font-serif text-[11px] lowercase tracking-normal">
        «Maximum useful navigation with minimum unnecessary complexity»
      </div>
    </footer>
  );
};
