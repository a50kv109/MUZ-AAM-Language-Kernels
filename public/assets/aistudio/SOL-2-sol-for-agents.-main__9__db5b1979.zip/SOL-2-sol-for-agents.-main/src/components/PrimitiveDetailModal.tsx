import React from 'react';
import { SolPrimitive } from '../types';
import { X, Layers, AlertTriangle, CheckCircle2, BookmarkCheck, ArrowDownRight } from 'lucide-react';

interface PrimitiveDetailModalProps {
  primitive: SolPrimitive | null;
  onClose: () => void;
}

export const PrimitiveDetailModal: React.FC<PrimitiveDetailModalProps> = ({ primitive, onClose }) => {
  if (!primitive) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#F9F8F3] border-4 border-[#1C1C1C] max-w-2xl w-full p-6 md:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 border border-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 mb-2 font-mono">
          <span className="bg-[#1C1C1C] text-white text-[10px] px-2 py-0.5 font-bold uppercase tracking-widest">
            {primitive.levelLabel}
          </span>
          <span className="text-[10px] border border-[#1C1C1C] px-2 py-0.5 uppercase tracking-wider font-bold">
            Level {primitive.level}
          </span>
          <span className="text-[10px] text-emerald-800 font-bold ml-auto">
            [{primitive.status}]
          </span>
        </div>

        <h2 className="text-3xl font-serif font-bold italic text-[#1C1C1C] tracking-tight mb-1">
          {primitive.name}
        </h2>
        <div className="text-xs uppercase tracking-[0.25em] font-mono text-[#1C1C1C]/60 mb-6 font-bold">
          Tag: {primitive.tag}
        </div>

        <div className="space-y-5 font-serif text-sm">
          <div className="p-4 bg-white border border-[#1C1C1C]">
            <h4 className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#1C1C1C]/60 mb-1 flex items-center gap-1.5">
              <BookmarkCheck className="w-3.5 h-3.5 text-[#1C1C1C]" />
              Концептуальная суть
            </h4>
            <p className="text-base italic text-[#1C1C1C] leading-relaxed">
              «{primitive.summary}»
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-[#F2EFE9] border border-[#D9D1C1]">
              <h4 className="text-[10px] uppercase font-mono font-bold tracking-widest text-emerald-900 mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Формальная функция
              </h4>
              <p className="text-xs leading-relaxed text-[#1C1C1C]/90">
                {primitive.formalDefinition}
              </p>
            </div>

            <div className="p-4 bg-[#EBE8E0] border border-[#D9D1C1]">
              <h4 className="text-[10px] uppercase font-mono font-bold tracking-widest text-red-900 mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Что он НЕ означает (Anti-Fitting)
              </h4>
              <p className="text-xs leading-relaxed text-[#1C1C1C]/90">
                {primitive.antiDefinition}
              </p>
            </div>
          </div>

          {primitive.reductionEquation && (
            <div className="p-4 bg-[#1C1C1C] text-[#F9F8F3] font-mono">
              <div className="text-[10px] uppercase tracking-widest opacity-60 mb-1 flex items-center gap-1.5">
                <ArrowDownRight className="w-3.5 h-3.5 text-amber-400" />
                Семантическая формула редукции к O7
              </div>
              <div className="text-sm font-bold text-amber-300 py-1">
                {primitive.reductionEquation}
              </div>
              <div className="text-[10px] opacity-70 mt-1 font-serif italic">
                *Композиционная разложимость не отменяет необходимости доменного концепта.
              </div>
            </div>
          )}

          <div className="pt-2 border-t border-[#D9D1C1] flex justify-between items-center text-xs font-mono">
            <span className="text-[#1C1C1C]/60">Домен применения:</span>
            <span className="font-bold text-[#1C1C1C]">{primitive.domainContext || 'Общесистемный канон'}</span>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={onClose}
            className="border-2 border-[#1C1C1C] px-6 py-2 bg-[#1C1C1C] text-white hover:bg-transparent hover:text-[#1C1C1C] text-xs font-mono font-bold uppercase tracking-widest transition-colors"
          >
            Закрыть формулярий
          </button>
        </div>
      </div>
    </div>
  );
};
