import React from 'react';
import { SolPrimitive } from '../types';
import { SOL_PRIMITIVES } from '../data';
import { AlertOctagon, ChevronRight, Layers, ShieldCheck, HelpCircle } from 'lucide-react';

interface SidebarProps {
  selectedPrimitiveId?: string;
  onSelectPrimitive: (primitive: SolPrimitive) => void;
  onOpenGateway?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  selectedPrimitiveId,
  onSelectPrimitive,
  onOpenGateway,
}) => {
  const o7Primitives = SOL_PRIMITIVES.filter((p) => p.level === 0 && p.levelLabel === 'Universal Canon (O7)');
  const domainPrimitives = SOL_PRIMITIVES.filter((p) => p.level === 1);

  return (
    <aside className="w-full md:w-72 lg:w-80 border-r-2 border-[#1C1C1C] p-5 flex flex-col justify-between bg-[#F9F8F3] shrink-0 overflow-y-auto max-h-full">
      <div className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] uppercase tracking-[0.2em] font-black bg-[#1C1C1C] text-white px-2 py-1 inline-block font-mono">
              SOL-1: The Canon
            </span>
            <span className="text-[9px] font-mono font-bold text-[#1C1C1C]/60">
              [O7 Core]
            </span>
          </div>
          <p className="text-xs italic mb-3 opacity-70 font-serif leading-tight">
            Universal Semantic Primitives (Read-Only Deterministic Core)
          </p>

          <ul className="space-y-1.5 font-serif text-sm">
            {o7Primitives.map((primitive) => {
              const isSelected = selectedPrimitiveId === primitive.id;
              return (
                <li key={primitive.id}>
                  <button
                    onClick={() => onSelectPrimitive(primitive)}
                    className={`w-full text-left border-b border-[#D9D1C1] pb-1 pt-1 flex justify-between items-center group transition-colors px-1.5 ${
                      isSelected
                        ? 'bg-[#1C1C1C] text-[#F9F8F3]'
                        : 'hover:bg-[#EBE8E0] text-[#1C1C1C]'
                    }`}
                  >
                    <span className="font-semibold tracking-wide flex items-center gap-1.5">
                      {primitive.name}
                    </span>
                    <span
                      className={`text-[9px] font-sans uppercase font-bold tracking-wider ${
                        isSelected ? 'text-[#D9D1C1]' : 'opacity-60 group-hover:opacity-100'
                      }`}
                    >
                      {primitive.tag.split(' ')[0]}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#1C1C1C]/70 font-mono">
              Domain Candidates
            </span>
            <span className="text-[9px] font-mono text-[#1C1C1C]/50">[Level 1]</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {domainPrimitives.map((p) => (
              <button
                key={p.id}
                onClick={() => onSelectPrimitive(p)}
                className="text-[10px] font-mono font-semibold px-2 py-0.5 border border-[#1C1C1C]/30 bg-white hover:bg-[#1C1C1C] hover:text-white transition-colors"
              >
                [{p.name}]
              </button>
            ))}
          </div>
        </div>

        <div className="border border-[#1C1C1C]/20 p-3 bg-white space-y-1.5 text-xs font-serif">
          <div className="text-[9px] uppercase tracking-widest font-mono font-bold text-[#1C1C1C]/60 flex items-center gap-1">
            <Layers className="w-3 h-3 text-[#1C1C1C]" />
            <span>Descent Invariant</span>
          </div>
          <p className="text-[11px] leading-snug text-[#1C1C1C]/80 italic">
            «Composable ≠ Unnecessary». Domain concepts preserve critical operational semantics without polluting the O7 kernel.
          </p>
        </div>
      </div>

      <div className="mt-6 pt-4 space-y-3">
        <div className="p-3.5 bg-[#EBE8E0] border border-[#D9D1C1] relative">
          <div className="flex items-center gap-1.5 mb-1.5 text-amber-900">
            <AlertOctagon className="w-3.5 h-3.5" />
            <span className="text-[10px] uppercase font-bold tracking-widest font-mono">
              Anti-Fitting Rule
            </span>
          </div>
          <p className="text-[11px] leading-relaxed text-[#1C1C1C]/85 font-serif italic">
            Forced mapping is an epistemic failure state. If existing primitives cannot express the phenomenon without loss, preserve <strong>SEMANTIC RESIDUE</strong>.
          </p>
        </div>

        {onOpenGateway && (
          <button
            onClick={onOpenGateway}
            className="w-full border-2 border-[#1C1C1C] bg-[#1C1C1C] text-[#F9F8F3] hover:bg-white hover:text-[#1C1C1C] py-2 text-[10px] font-bold uppercase tracking-widest font-mono transition-all flex items-center justify-center gap-2 shadow-sm"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Audit Gateway</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        )}
      </div>
    </aside>
  );
};
