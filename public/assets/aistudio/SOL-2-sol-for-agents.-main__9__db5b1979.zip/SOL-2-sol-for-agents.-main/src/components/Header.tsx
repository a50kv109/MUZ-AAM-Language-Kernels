import React from 'react';
import { ViewMode } from '../types';
import { BookOpen, Compass, FlaskConical, Scale, ShieldAlert, ScrollText, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  corpusCount: number;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onSelectView, corpusCount }) => {
  const navItems: { id: ViewMode; label: string; icon: React.ReactNode }[] = [
    { id: 'index', label: 'Index & Canon', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'navigator', label: 'Q-Space Navigator', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'laboratory', label: 'Laboratory', icon: <FlaskConical className="w-3.5 h-3.5" /> },
    { id: 'evidence', label: 'Case Evidence', icon: <Scale className="w-3.5 h-3.5" /> },
    { id: 'gateway', label: 'Observation Gateway', icon: <ShieldAlert className="w-3.5 h-3.5" /> },
    { id: 'constitution', label: 'Constitution', icon: <ScrollText className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="border-b-2 border-[#1C1C1C] flex flex-col md:flex-row justify-between items-stretch md:items-center px-4 md:px-8 py-3.5 bg-white shrink-0 gap-3">
      <div className="flex items-center gap-4">
        <div className="w-8 h-8 bg-[#1C1C1C] text-[#F9F8F3] flex items-center justify-center font-display font-black text-lg select-none">
          S
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-[9px] uppercase tracking-[0.25em] font-bold text-[#1C1C1C]/60 font-mono">
              Cognitive Tooling Environment
            </span>
            <span className="text-[9px] bg-[#1C1C1C] text-white px-1.5 py-0.2 font-mono font-bold tracking-widest">
              SOL-1 ↔ SOL-2
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-serif italic font-medium tracking-tight text-[#1C1C1C] leading-tight">
            SOL Research Repository
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-1 md:gap-4 overflow-x-auto pb-1 md:pb-0 text-[11px] uppercase tracking-widest font-bold">
        {navItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectView(item.id)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 transition-all whitespace-nowrap border-b-2 ${
                isActive
                  ? 'border-[#1C1C1C] text-[#1C1C1C] bg-[#F9F8F3]'
                  : 'border-transparent text-[#1C1C1C]/50 hover:text-[#1C1C1C] hover:border-[#1C1C1C]/30'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          );
        })}
        <div className="hidden lg:flex items-center gap-1 pl-2 border-l border-[#D9D1C1] text-red-700 font-mono text-[10px]">
          <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span>
          [v0.1-Alpha]
        </div>
      </div>
    </header>
  );
};
