import React, { useState } from 'react';
import { CaseStudy } from '../../types';
import { CASE_STUDIES } from '../../data';
import { Scale, ArrowRight, BookOpen, CheckCircle2, FileText, ChevronRight } from 'lucide-react';

export const EvidenceView: React.FC = () => {
  const [selectedCase, setSelectedCase] = useState<CaseStudy>(CASE_STUDIES[0]);

  return (
    <div className="space-y-8 p-6 md:p-8 max-w-6xl mx-auto overflow-y-auto">
      {/* Masthead */}
      <div className="border-b-2 border-[#1C1C1C] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase tracking-[0.25em] font-mono font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
              EMPIRICAL CASE EVIDENCE
            </span>
            <span className="text-xs font-mono font-semibold text-[#1C1C1C]/60">
              Basket D &bull; Provenance & Ground Truth Precedents
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold italic tracking-tight text-[#1C1C1C]">
            Case Evidence & Benchmarks
          </h2>
          <p className="text-sm font-serif italic text-[#1C1C1C]/75 mt-1 max-w-2xl">
            Historical systems analyzed to validate Q-Space adaptivity, epistemic isolation, and semantic residue isolation.
          </p>
        </div>

        <div className="text-xs font-mono text-[#1C1C1C]/70">
          Total Validated Cases: <strong className="text-[#1C1C1C] font-bold">5 Precedents</strong>
        </div>
      </div>

      {/* Case Broadside Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Case Selection Column */}
        <div className="lg:col-span-5 space-y-3">
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#1C1C1C]/60 block mb-1">
            Select Empirical Case:
          </span>
          {CASE_STUDIES.map((c) => {
            const isSelected = selectedCase.id === c.id;
            return (
              <div
                key={c.id}
                onClick={() => setSelectedCase(c)}
                className={`p-4 border-2 cursor-pointer transition-all ${
                  isSelected
                    ? 'border-[#1C1C1C] bg-[#1C1C1C] text-[#F9F8F3] shadow-md'
                    : 'border-[#D9D1C1] bg-white text-[#1C1C1C] hover:border-[#1C1C1C]'
                }`}
              >
                <div className="flex justify-between items-center mb-1 text-[10px] font-mono font-bold">
                  <span className={isSelected ? 'text-[#D9D1C1]' : 'text-[#1C1C1C]/60'}>
                    {c.code}
                  </span>
                  <span className={`px-1.5 py-0.2 uppercase ${isSelected ? 'bg-white text-black' : 'bg-[#EBE8E0] text-black'}`}>
                    {c.domain.split('/')[0]}
                  </span>
                </div>
                <h4 className="text-base font-serif font-bold italic mb-1">
                  {c.title}
                </h4>
                <p className={`text-xs font-serif italic line-clamp-2 ${isSelected ? 'text-[#F9F8F3]/80' : 'text-[#1C1C1C]/70'}`}>
                  {c.systemDescription}
                </p>
              </div>
            );
          })}
        </div>

        {/* Right: Case Deep-Dive Broadsheet */}
        <div className="lg:col-span-7 space-y-6">
          <div className="border-2 border-[#1C1C1C] bg-white p-6 md:p-8 shadow-xs space-y-6">
            <div className="border-b border-[#D9D1C1] pb-4">
              <div className="flex justify-between items-center font-mono text-[10px] mb-2">
                <span className="bg-[#1C1C1C] text-white px-2 py-0.5 font-bold uppercase">
                  {selectedCase.code}
                </span>
                <span className="font-bold text-[#1C1C1C]/70">
                  {selectedCase.domain}
                </span>
              </div>
              <h3 className="text-2xl md:text-3xl font-serif font-bold italic text-[#1C1C1C]">
                {selectedCase.title}
              </h3>
              <p className="text-sm font-serif italic text-[#1C1C1C]/80 mt-1">
                {selectedCase.systemDescription}
              </p>
            </div>

            {/* Q-Space Traversal Steps */}
            <div>
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#1C1C1C]/60 block mb-2">
                Observed Q-Space Trajectory:
              </span>
              <div className="flex flex-wrap gap-2 font-mono text-xs">
                {selectedCase.qSpaceTrajectory.map((step, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-1 bg-[#F2EFE9] border border-[#1C1C1C] px-2.5 py-1 text-[#1C1C1C] font-semibold"
                  >
                    <span>{step}</span>
                    {idx < selectedCase.qSpaceTrajectory.length - 1 && (
                      <ChevronRight className="w-3 h-3 text-[#1C1C1C]/50" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Key Findings */}
            <div className="p-4 bg-[#F9F8F3] border-l-4 border-[#1C1C1C] space-y-1">
              <span className="text-[10px] uppercase font-mono font-bold text-[#1C1C1C]/60 block">
                Empirical Findings & Observations
              </span>
              <p className="text-sm font-serif italic text-[#1C1C1C] leading-relaxed">
                «{selectedCase.findings}»
              </p>
            </div>

            {/* Discovered Residue / Primitive */}
            <div className="p-4 bg-[#1C1C1C] text-[#F9F8F3] font-mono space-y-1">
              <span className="text-[10px] uppercase tracking-widest text-amber-300 font-bold block">
                Discovered Primitive / Structural Fact:
              </span>
              <div className="text-sm font-bold text-white">
                {selectedCase.discoveredPrimitiveOrResidue}
              </div>
            </div>

            {/* Epistemic Lesson & Methodology Impact */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-serif text-xs">
              <div className="p-3.5 bg-[#F2EFE9] border border-[#D9D1C1]">
                <span className="text-[9px] uppercase font-mono font-bold tracking-wider text-[#1C1C1C]/60 block mb-1">
                  Epistemic Lesson
                </span>
                <p className="italic text-[#1C1C1C] leading-relaxed">
                  {selectedCase.epistemicLesson}
                </p>
              </div>

              <div className="p-3.5 bg-[#EBE8E0] border border-[#D9D1C1]">
                <span className="text-[9px] uppercase font-mono font-bold tracking-wider text-amber-900 block mb-1">
                  Impact on SOL Methodology
                </span>
                <p className="italic text-[#1C1C1C] leading-relaxed">
                  {selectedCase.methodologyImpact}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
