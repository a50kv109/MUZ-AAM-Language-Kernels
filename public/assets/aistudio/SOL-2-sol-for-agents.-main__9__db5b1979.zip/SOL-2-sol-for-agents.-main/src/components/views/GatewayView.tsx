import React, { useState } from 'react';
import { ObservationReport } from '../../types';
import { ShieldAlert, Copy, Check, Sparkles, FileText, Send, RotateCcw, AlertOctagon } from 'lucide-react';

const PRESET_REPORTS: ObservationReport[] = [
  {
    id: 'rep_01',
    sourceProject: 'Document Lifecycle Engine (DLE)',
    observation: 'Reading the text of a signed contract allowed the LLM to assume it possessed execution rights for payments.',
    solRelation: 'Direct confusion between STATE (passive text content) and CAPABILITY (runtime authority to act).',
    methodologyImpact: 'Revealed necessity of strict Librarian Principle: document parsing does NOT grant operational authority.',
    hypothesisConfirmation: 'CONFIRMED',
    hypothesisRefutationNotes: 'Refutes assumption that LLM can autonomously infer capability boundaries from text semantics alone.',
    semanticResidue: 'AUTHORITY_DRIFT_PROTECTION — isolation of observational state from executive permission contracts.',
    requiredChange: 'Introduce strict boundary constraint in SOL-2: observational data must never inflate agent capability without explicit contract validation.',
    timestamp: '2026-08-24'
  },
  {
    id: 'rep_02',
    sourceProject: 'Git DAG Version Control',
    observation: 'Automatic 3-way merge fails when parallel edits touch the same lines; workflow halts awaiting human intervention.',
    solRelation: 'Attempt to reduce conflict resolution to purely FLOW + COMPARE + CONSTRAINT fails to capture human intent arbitration.',
    methodologyImpact: 'Validates that project-specific candidates are essential and should not be forcibly compressed into O7 atoms.',
    hypothesisConfirmation: 'CONFIRMED',
    hypothesisRefutationNotes: 'Proves that Composable ≠ Unnecessary in practical software engineering.',
    semanticResidue: 'MERGE_RESOLUTION — human-in-the-loop agent arbitration upon irreconcilable flow collision.',
    requiredChange: 'Assign MERGE_RESOLUTION to Level 2 (Project Canon). Do NOT pollute Level 0 (Universal Canon).',
    timestamp: '2026-08-24'
  }
];

export const GatewayView: React.FC = () => {
  const [formData, setFormData] = useState<ObservationReport>(PRESET_REPORTS[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleLoadPreset = (preset: ObservationReport) => {
    setFormData(preset);
  };

  const handleResetForm = () => {
    setFormData({
      id: `rep_${Date.now()}`,
      sourceProject: '',
      observation: '',
      solRelation: '',
      methodologyImpact: '',
      hypothesisConfirmation: 'CONFIRMED',
      hypothesisRefutationNotes: '',
      semanticResidue: '',
      requiredChange: '',
      timestamp: new Date().toISOString().split('T')[0]
    });
  };

  const formattedMarkdown = `> **[EXTERNAL OBSERVATION REPORT]**
> **Source Project:** ${formData.sourceProject || '[Project Name]'}
> **1. Observation (Что наблюдалось):** ${formData.observation || '...'}
> **2. SOL Relation (Отношение к SOL):** ${formData.solRelation || '...'}
> **3. Methodology Impact (Что это говорит о методологии):** ${formData.methodologyImpact || '...'}
> **4. Hypothesis Confirmation (Подтверждает ли гипотезу):** ${formData.hypothesisConfirmation}
> **5. Hypothesis Refutation (Опровергает ли гипотезу):** ${formData.hypothesisRefutationNotes || 'Нет/Частично'}
> **6. Semantic Residue (Обнаружен ли остаток):** ${formData.semanticResidue || 'None / Not detected'}
> **7. Required Change (Требует ли изменения методологии):** ${formData.requiredChange || '...'}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(formattedMarkdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 p-6 md:p-8 max-w-6xl mx-auto overflow-y-auto">
      {/* Masthead */}
      <div className="border-b-2 border-[#1C1C1C] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase tracking-[0.25em] font-mono font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
              DOMAIN ISOLATION GATEWAY
            </span>
            <span className="text-xs font-mono font-semibold text-[#1C1C1C]/60">
              7-Step Observation Gateway
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold italic tracking-tight text-[#1C1C1C]">
            Observation Audit Gateway
          </h2>
          <p className="text-sm font-serif italic text-[#1C1C1C]/75 mt-1 max-w-2xl">
            Strict filtration checkpoint for external project insights. External code and ad-hoc logic are strictly forbidden from directly polluting SOL core.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-[#1C1C1C]/60 uppercase text-[10px] font-bold">Presets:</span>
          {PRESET_REPORTS.map((p, idx) => (
            <button
              key={p.id}
              onClick={() => handleLoadPreset(p)}
              className="px-2 py-1 text-[10px] uppercase font-bold border border-[#1C1C1C] bg-white hover:bg-[#1C1C1C] hover:text-white transition-colors"
            >
              Preset 0{idx + 1}
            </button>
          ))}
          <button
            onClick={handleResetForm}
            className="p-1 border border-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white transition-colors"
            title="Blank Form"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Gateway Form and Output Broadsheet */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: 7-Step Interactive Form */}
        <div className="lg:col-span-7 space-y-4 font-mono text-xs">
          <div className="border-2 border-[#1C1C1C] bg-white p-6 shadow-xs space-y-4">
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                Source External Project (e.g., DLE, VCS, Compiler)
              </label>
              <input
                type="text"
                value={formData.sourceProject}
                onChange={(e) => setFormData({ ...formData, sourceProject: e.target.value })}
                placeholder="Enter project name..."
                className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-serif text-sm focus:outline-hidden focus:ring-1 focus:ring-black"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                1. Observation (Что наблюдалось в естественной среде)
              </label>
              <textarea
                rows={2}
                value={formData.observation}
                onChange={(e) => setFormData({ ...formData, observation: e.target.value })}
                placeholder="Specific empirical behavior without premature SOL jargon..."
                className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-serif text-sm focus:outline-hidden focus:ring-1 focus:ring-black"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                2. SOL Relation (Отношение к примитивам SOL-1 и навигации SOL-2)
              </label>
              <textarea
                rows={2}
                value={formData.solRelation}
                onChange={(e) => setFormData({ ...formData, solRelation: e.target.value })}
                placeholder="Which primitives are involved? Where does standard mapping break down?..."
                className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-serif text-sm focus:outline-hidden focus:ring-1 focus:ring-black"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                3. Methodology Impact (Адекватность текущего Q-Space и Конструктора)
              </label>
              <textarea
                rows={2}
                value={formData.methodologyImpact}
                onChange={(e) => setFormData({ ...formData, methodologyImpact: e.target.value })}
                placeholder="Did Q-Space have the right question? Was the descent level correct?..."
                className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-serif text-sm focus:outline-hidden focus:ring-1 focus:ring-black"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                  4. Hypothesis Confirmation
                </label>
                <select
                  value={formData.hypothesisConfirmation}
                  onChange={(e) => setFormData({ ...formData, hypothesisConfirmation: e.target.value as any })}
                  className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-mono text-xs font-bold focus:outline-hidden"
                >
                  <option value="CONFIRMED">CONFIRMED (Подтверждает)</option>
                  <option value="PARTIALLY_CONFIRMED">PARTIALLY CONFIRMED</option>
                  <option value="REFUTED">REFUTED (Опровергает)</option>
                  <option value="INCONCLUSIVE">INCONCLUSIVE (Недостаточно)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                  5. Hypothesis Refutation Notes
                </label>
                <input
                  type="text"
                  value={formData.hypothesisRefutationNotes}
                  onChange={(e) => setFormData({ ...formData, hypothesisRefutationNotes: e.target.value })}
                  placeholder="What assumption was refuted?..."
                  className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-serif text-xs focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1 text-amber-900">
                6. Semantic Residue (Формулировка нередуцируемого остатка)
              </label>
              <input
                type="text"
                value={formData.semanticResidue}
                onChange={(e) => setFormData({ ...formData, semanticResidue: e.target.value })}
                placeholder="E.g., MERGE_RESOLUTION, AUTHORITY_DRIFT..."
                className="w-full border border-amber-900/50 p-2 bg-amber-50/50 font-mono text-xs font-bold text-amber-950 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-[#1C1C1C]/70 mb-1">
                7. Required Change (Предложение по обновлению SOL-2, а не втягивание кода)
              </label>
              <textarea
                rows={2}
                value={formData.requiredChange}
                onChange={(e) => setFormData({ ...formData, requiredChange: e.target.value })}
                placeholder="E.g., Update Q-Space with new constraint node; assign Project Level 2..."
                className="w-full border border-[#1C1C1C] p-2 bg-[#F9F8F3] font-serif text-sm focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Right: Real-time Markdown Report & Epistemic Vector */}
        <div className="lg:col-span-5 space-y-4">
          <div className="border-2 border-[#1C1C1C] bg-[#1C1C1C] text-[#F9F8F3] p-6 shadow-xs">
            <div className="flex justify-between items-center mb-4 border-b border-white/20 pb-3">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#D9D1C1]">
                [EXTERNAL OBSERVATION REPORT]
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-[10px] font-mono uppercase font-bold px-2.5 py-1 bg-white text-black hover:bg-[#D9D1C1] transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-700" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Copied' : 'Copy Report'}</span>
              </button>
            </div>

            <pre className="font-mono text-xs text-white/90 whitespace-pre-wrap leading-relaxed overflow-x-auto bg-black/40 p-4 border border-white/10 select-all max-h-[480px]">
              {formattedMarkdown}
            </pre>
          </div>

          <div className="p-4 bg-[#EBE8E0] border border-[#D9D1C1] font-serif italic text-xs leading-relaxed text-[#1C1C1C]/80">
            <div className="font-mono text-[9px] uppercase font-bold text-[#1C1C1C] not-italic mb-1 flex items-center gap-1">
              <AlertOctagon className="w-3 h-3 text-amber-900" />
              Principle of Domain Isolation
            </div>
            «SOL illuminates the project &rarr; The project casts a shadow &rarr; We study that shadow to calibrate our lantern (SOL-2), but we NEVER put the project itself inside the lantern.»
          </div>
        </div>
      </div>
    </div>
  );
};
