import React, { useState } from 'react';
import { QuestionNode } from '../../types';
import { QUESTION_SPACE, SOL_PRIMITIVES } from '../../data';
import { Compass, ArrowRight, CornerDownRight, RotateCcw, AlertTriangle, CheckCircle, ShieldAlert, Sparkles, Layers } from 'lucide-react';

interface ScenarioPreset {
  id: string;
  name: string;
  domain: string;
  initialQuestion: string;
  steps: {
    questionId: string;
    rawObservation: string;
    semanticAspect: string;
    mappingResult: 'REDUCTION_TO_O7' | 'SEMANTIC_RESIDUE' | 'INAPPLICABLE';
    matchedPrimitives: string[];
    residueName?: string;
    descentLevel?: 'Level 0 (Universal)' | 'Level 1 (Domain)' | 'Level 2 (Project)';
    notes: string;
  }[];
}

const PRESET_SCENARIOS: ScenarioPreset[] = [
  {
    id: 'git_merge',
    name: 'Git Version Control (Merge Conflict)',
    domain: 'Software Engineering / VCS',
    initialQuestion: 'what',
    steps: [
      {
        questionId: 'what',
        rawObservation: 'The repository stores commit snapshots and branches containing file deltas.',
        semanticAspect: 'Discrete immutable nodes organized in a directed acyclic graph (DAG).',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['SOURCE', 'STATE'],
        notes: 'Mapped cleanly to O7 snapshot primitives.'
      },
      {
        questionId: 'how',
        rawObservation: 'Branch heads advance through directed transfer of commit parent pointers.',
        semanticAspect: 'Directional transfer of state history between coordinate references.',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['FLOW', 'INDEX'],
        notes: 'Flow of states through topological index.'
      },
      {
        questionId: 'what_can_fail',
        rawObservation: 'Two branches modify the same line; automated merge halts with conflict markers.',
        semanticAspect: 'Collision of competing flow vectors violating boundary constraint.',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['CONSTRAINT', 'COMPARE'],
        notes: 'Constraint boundary violation detected via delta comparison.'
      },
      {
        questionId: 'who',
        rawObservation: 'A human software engineer manually chooses one delta or authors a combined synthesis.',
        semanticAspect: 'Irreducible agentic arbitration upon conflicting flow collision.',
        mappingResult: 'SEMANTIC_RESIDUE',
        matchedPrimitives: ['CAPABILITY'],
        residueName: 'MERGE_RESOLUTION',
        descentLevel: 'Level 2 (Project)',
        notes: 'Compressing this solely to FLOW+COMPARE loses the essence of human agentic arbitration. Generated Candidate!'
      }
    ]
  },
  {
    id: 'mendeleev',
    name: 'Mendeleev Periodic Table',
    domain: 'Physical Chemistry',
    initialQuestion: 'what',
    steps: [
      {
        questionId: 'what',
        rawObservation: '118 distinct chemical elements with atomic numbers and proton masses.',
        semanticAspect: 'Discrete physical entities with fixed structural charges.',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['STATE', 'SOURCE'],
        notes: 'Elementary states with invariant genesis anchors.'
      },
      {
        questionId: 'how',
        rawObservation: 'Atomic charge increases incrementally (+1 proton per step across the table).',
        semanticAspect: 'Monotonic ordinal progression of coordinate index.',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['INDEX', 'COMPARE'],
        notes: 'Ordinal topological indexing.'
      },
      {
        questionId: 'what_changes',
        rawObservation: 'Valence electron configurations and reactivity repeat at discrete harmonic periods.',
        semanticAspect: 'Periodic delta comparison across coordinate space intervals.',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['COMPARE', 'COORDINATE_SPACE'],
        notes: 'Delta comparison of state properties.'
      },
      {
        questionId: 'who',
        rawObservation: 'Physical atomic structures have no agency or teleological actor.',
        semanticAspect: 'Agentic Agency = NULL. Inapplicable question.',
        mappingResult: 'INAPPLICABLE',
        matchedPrimitives: [],
        notes: 'Question WHO/WHY детерминированно блокируются для физических систем. Никакого телеологического дрейфа.'
      }
    ]
  },
  {
    id: 'pythagoras',
    name: 'Pythagorean Geometric Theorem',
    domain: 'Euclidean Formal Mathematics',
    initialQuestion: 'what',
    steps: [
      {
        questionId: 'what',
        rawObservation: 'A right-angled triangle with side lengths a, b and hypotenuse c.',
        semanticAspect: 'Geometric state in continuous Euclidean coordinate space.',
        mappingResult: 'REDUCTION_TO_O7',
        matchedPrimitives: ['STATE', 'COORDINATE_SPACE'],
        notes: 'Static spatial configuration.'
      },
      {
        questionId: 'how',
        rawObservation: 'Algebraic squaring and rearrangement of bounding squares on each side.',
        semanticAspect: 'Qualitative transformation of geometric form preserving invariant surface area.',
        mappingResult: 'SEMANTIC_RESIDUE',
        matchedPrimitives: ['STATE', 'FLOW'],
        residueName: 'TRANSFORM',
        descentLevel: 'Level 1 (Domain)',
        notes: 'STATE(A) → FLOW → STATE(B) with invariant area.'
      },
      {
        questionId: 'on_what_basis',
        rawObservation: 'Each step is legitimized strictly by Euclidean axioms and deductive logic rules.',
        semanticAspect: 'Verifiable trace of proof authorizing the truth transition.',
        mappingResult: 'SEMANTIC_RESIDUE',
        matchedPrimitives: ['STATE', 'COMPARE'],
        residueName: 'EVIDENCE',
        descentLevel: 'Level 1 (Domain)',
        notes: 'Mathematical proof acts as formal EVIDENCE authorizing semantic transition.'
      }
    ]
  }
];

export const NavigatorView: React.FC = () => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('git_merge');
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [selectedQuestionId, setSelectedQuestionId] = useState<string>('what');

  const scenario = PRESET_SCENARIOS.find((s) => s.id === selectedScenarioId) || PRESET_SCENARIOS[0];
  const activeStep = scenario.steps[currentStepIndex] || scenario.steps[0];
  const activeQuestion = QUESTION_SPACE.find((q) => q.id === (activeStep ? activeStep.questionId : selectedQuestionId)) || QUESTION_SPACE[0];

  const handleSelectScenario = (id: string) => {
    setSelectedScenarioId(id);
    setCurrentStepIndex(0);
  };

  const handleNextStep = () => {
    if (currentStepIndex < scenario.steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
  };

  return (
    <div className="space-y-8 p-6 md:p-8 max-w-6xl mx-auto overflow-y-auto">
      {/* Masthead */}
      <div className="border-b-2 border-[#1C1C1C] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase tracking-[0.25em] font-mono font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
              SOL-2 ENGINE
            </span>
            <span className="text-xs font-mono font-semibold text-[#1C1C1C]/60">
              Epistemic Navigation & Traversal
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold italic tracking-tight text-[#1C1C1C]">
            Q-Space Research Navigator
          </h2>
          <p className="text-sm font-serif italic text-[#1C1C1C]/75 mt-1 max-w-2xl">
            Externalized cognitive tooling for autonomous AI agents: dynamic traversal through question space to eliminate bias and isolate semantic residue.
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex flex-col items-start md:items-end gap-1.5 font-mono text-xs">
          <span className="text-[#1C1C1C]/60 uppercase text-[10px] font-bold">Select Experimental Case:</span>
          <div className="flex gap-1.5 flex-wrap">
            {PRESET_SCENARIOS.map((s) => (
              <button
                key={s.id}
                onClick={() => handleSelectScenario(s.id)}
                className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                  selectedScenarioId === s.id
                    ? 'bg-[#1C1C1C] text-white border-[#1C1C1C]'
                    : 'bg-white text-[#1C1C1C] border-[#1C1C1C]/30 hover:border-[#1C1C1C]'
                }`}
              >
                {s.name.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Navigator Layout (2 Columns) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Interactive Trajectory Stepper & Graph */}
        <div className="lg:col-span-5 space-y-6">
          <div className="border-2 border-[#1C1C1C] bg-white p-5 shadow-xs">
            <div className="flex justify-between items-center mb-4 border-b border-[#D9D1C1] pb-3">
              <div>
                <span className="text-[9px] uppercase font-mono font-bold text-[#1C1C1C]/60 block">Active Target System</span>
                <h3 className="text-base font-serif font-bold italic text-[#1C1C1C]">{scenario.name}</h3>
                <span className="text-[10px] font-mono text-[#1C1C1C]/60 font-semibold">{scenario.domain}</span>
              </div>
              <button
                onClick={handleReset}
                title="Reset Trajectory"
                className="p-1.5 border border-[#1C1C1C]/40 hover:bg-[#1C1C1C] hover:text-white transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Stepper Trail */}
            <div className="space-y-2 font-mono text-xs">
              <div className="text-[10px] uppercase font-bold text-[#1C1C1C]/50 tracking-wider">
                Question Traversal History:
              </div>
              {scenario.steps.map((step, idx) => {
                const q = QUESTION_SPACE.find((item) => item.id === step.questionId);
                const isCurrent = idx === currentStepIndex;
                const isPast = idx < currentStepIndex;

                return (
                  <button
                    key={idx}
                    onClick={() => setCurrentStepIndex(idx)}
                    className={`w-full text-left p-2.5 border transition-all flex items-center justify-between ${
                      isCurrent
                        ? 'border-2 border-[#1C1C1C] bg-[#F2EFE9] font-bold shadow-xs'
                        : isPast
                        ? 'border-[#D9D1C1] bg-white text-[#1C1C1C]/80 hover:bg-[#F9F8F3]'
                        : 'border-[#EBE8E0] bg-[#F9F8F3] text-[#1C1C1C]/40'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] w-5 h-5 rounded-full border border-current flex items-center justify-center font-bold">
                        {idx + 1}
                      </span>
                      <span className="font-serif italic text-sm">{q?.question}</span>
                      <span className="text-[10px] uppercase opacity-60">({q?.questionRu})</span>
                    </div>

                    <div className="text-[9px] uppercase font-bold font-mono">
                      {step.mappingResult === 'SEMANTIC_RESIDUE' ? (
                        <span className="text-amber-900 bg-amber-100 px-1 border border-amber-300">
                          Residue!
                        </span>
                      ) : step.mappingResult === 'INAPPLICABLE' ? (
                        <span className="text-gray-500 bg-gray-100 px-1">
                          Inapplicable
                        </span>
                      ) : (
                        <span className="text-emerald-800 bg-emerald-50 px-1">
                          O7 Core
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Stepper Navigation Buttons */}
            <div className="mt-5 pt-4 border-t border-[#D9D1C1] flex justify-between gap-3">
              <button
                disabled={currentStepIndex === 0}
                onClick={handlePrevStep}
                className="px-3 py-1.5 border border-[#1C1C1C] text-xs font-mono font-bold uppercase disabled:opacity-30 hover:bg-[#1C1C1C] hover:text-white transition-colors"
              >
                &larr; Prev Step
              </button>
              <button
                disabled={currentStepIndex === scenario.steps.length - 1}
                onClick={handleNextStep}
                className="px-4 py-1.5 border-2 border-[#1C1C1C] bg-[#1C1C1C] text-white text-xs font-mono font-bold uppercase disabled:opacity-30 hover:bg-white hover:text-[#1C1C1C] transition-colors flex items-center gap-1.5"
              >
                <span>Next Hop &rarr;</span>
              </button>
            </div>
          </div>

          {/* Q-Space Question Taxa */}
          <div className="border-2 border-[#1C1C1C] p-5 bg-[#F9F8F3]">
            <h4 className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#1C1C1C]/60 mb-3 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-[#1C1C1C]" />
              Available Q-Space Direction Nodes
            </h4>
            <div className="grid grid-cols-2 gap-2 font-mono text-[10px]">
              {QUESTION_SPACE.map((q) => {
                const isSelected = activeQuestion.id === q.id;
                return (
                  <div
                    key={q.id}
                    className={`p-2 border transition-colors ${
                      isSelected
                        ? 'border-[#1C1C1C] bg-[#1C1C1C] text-white font-bold'
                        : 'border-[#D9D1C1] bg-white text-[#1C1C1C]'
                    }`}
                  >
                    <div className="font-serif italic text-xs">{q.question}</div>
                    <div className={`text-[8px] uppercase tracking-tighter ${isSelected ? 'text-white/70' : 'text-[#1C1C1C]/60'}`}>
                      {q.category} node
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Active Epistemic Isolation Stage */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Question Box */}
          <div className="border-2 border-[#1C1C1C] bg-white p-6 relative shadow-xs">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[9px] uppercase font-mono font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
                  STEP {currentStepIndex + 1} OF {scenario.steps.length} &bull; {activeQuestion.category.toUpperCase()} NODE
                </span>
                <h3 className="text-2xl md:text-3xl font-serif italic font-bold text-[#1C1C1C] mt-2">
                  {activeQuestion.question} <span className="text-base font-normal opacity-60">({activeQuestion.questionRu})</span>
                </h3>
              </div>
              <div className="text-right font-mono text-[10px]">
                <span className="opacity-50 block uppercase">Uncertainty Cleared:</span>
                <span className="font-bold text-[#1C1C1C] max-w-[200px] block text-[11px] leading-tight mt-0.5">
                  {activeQuestion.uncertaintyCleared}
                </span>
              </div>
            </div>

            {/* 4-Layer Epistemic Extraction Box */}
            <div className="space-y-4 font-serif text-sm border-t border-[#D9D1C1] pt-4">
              {/* Layer 1: Raw Observation */}
              <div className="p-3.5 bg-[#F9F8F3] border-l-4 border-[#1C1C1C]">
                <div className="text-[10px] font-mono uppercase font-bold text-[#1C1C1C]/60 tracking-wider mb-1 flex items-center gap-1">
                  <span>1. Raw Observation</span>
                  <span className="text-[9px] text-[#1C1C1C]/40 font-serif italic">(Neutral natural language)</span>
                </div>
                <p className="text-sm font-serif italic text-[#1C1C1C]">
                  «{activeStep.rawObservation}»
                </p>
              </div>

              {/* Layer 2: Semantic Aspect */}
              <div className="p-3.5 bg-[#F2EFE9] border-l-4 border-[#8C827A]">
                <div className="text-[10px] font-mono uppercase font-bold text-[#1C1C1C]/70 tracking-wider mb-1 flex items-center gap-1">
                  <span>2. Semantic Aspect Extracted</span>
                  <span className="text-[9px] text-[#1C1C1C]/50 font-serif italic">(Structural fact prior to SOL)</span>
                </div>
                <p className="text-sm font-serif font-medium text-[#1C1C1C]">
                  {activeStep.semanticAspect}
                </p>
              </div>

              {/* Layer 3: Semantic Loss Test & Mapping */}
              <div className={`p-4 border-2 ${
                activeStep.mappingResult === 'SEMANTIC_RESIDUE'
                  ? 'border-amber-700 bg-amber-50/70 text-amber-950'
                  : activeStep.mappingResult === 'INAPPLICABLE'
                  ? 'border-gray-500 bg-gray-50 text-gray-800'
                  : 'border-emerald-700 bg-emerald-50/60 text-emerald-950'
              }`}>
                <div className="flex justify-between items-center mb-2 font-mono text-[10px] font-bold uppercase tracking-widest">
                  <span className="flex items-center gap-1.5">
                    {activeStep.mappingResult === 'SEMANTIC_RESIDUE' ? (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
                    ) : (
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-700" />
                    )}
                    3. Semantic Loss Test Result
                  </span>
                  <span className="px-2 py-0.5 bg-black text-white">
                    {activeStep.mappingResult}
                  </span>
                </div>

                {activeStep.mappingResult === 'SEMANTIC_RESIDUE' ? (
                  <div className="space-y-2">
                    <p className="text-xs font-serif leading-relaxed italic">
                      {activeStep.notes}
                    </p>
                    <div className="pt-2 border-t border-amber-200 flex flex-wrap items-center justify-between gap-2 font-mono text-xs">
                      <div>
                        <span className="opacity-60 text-[10px] block">Generated Candidate:</span>
                        <span className="font-bold text-amber-900 text-sm">[{activeStep.residueName}]</span>
                      </div>
                      <div className="text-right">
                        <span className="opacity-60 text-[10px] block">Descent Assignment:</span>
                        <span className="font-bold text-amber-900">{activeStep.descentLevel}</span>
                      </div>
                    </div>
                  </div>
                ) : activeStep.mappingResult === 'INAPPLICABLE' ? (
                  <p className="text-xs font-serif leading-relaxed italic">
                    {activeStep.notes}
                  </p>
                ) : (
                  <div className="space-y-2">
                    <p className="text-xs font-serif leading-relaxed italic">
                      {activeStep.notes}
                    </p>
                    <div className="pt-2 border-t border-emerald-200 flex items-center gap-2 font-mono text-xs">
                      <span className="opacity-60 text-[10px]">O7 Primitives Bound:</span>
                      {activeStep.matchedPrimitives.map((p) => (
                        <span key={p} className="font-bold bg-white px-1.5 py-0.5 border border-emerald-300">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Epistemic Guardrail Notice */}
          <div className="border border-[#1C1C1C] p-4 bg-[#EBE8E0] flex items-start gap-3 text-xs font-serif italic">
            <ShieldAlert className="w-4 h-4 text-[#1C1C1C] shrink-0 mt-0.5" />
            <div>
              <span className="font-mono font-bold uppercase text-[10px] tracking-wider not-italic text-[#1C1C1C] block mb-0.5">
                Epistemic Layer Isolation Principle
              </span>
              Raw Observation and Semantic Aspect MUST be formulated in domain language BEFORE any SOL lookup occurs. Bypassing layer 2 causes <em>Aspect Leakage</em> and invalidates the audit.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
