import React, { useState } from 'react';
import { SolPrimitive, OpenQuestionItem } from '../../types';
import { SOL_PRIMITIVES, OPEN_QUESTIONS } from '../../data';
import { FlaskConical, AlertTriangle, ArrowDownRight, HelpCircle, Check, X, ShieldAlert, Sparkles, Layers } from 'lucide-react';

interface LaboratoryViewProps {
  onSelectPrimitive: (primitive: SolPrimitive) => void;
}

export const LaboratoryView: React.FC<LaboratoryViewProps> = ({ onSelectPrimitive }) => {
  const [selectedOq, setSelectedOq] = useState<OpenQuestionItem>(OPEN_QUESTIONS[0]);

  const domainCandidates = SOL_PRIMITIVES.filter((p) => p.level === 1 || p.level === 2);

  return (
    <div className="space-y-8 p-6 md:p-8 max-w-6xl mx-auto overflow-y-auto">
      {/* Masthead */}
      <div className="border-b-2 border-[#1C1C1C] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase tracking-[0.25em] font-mono font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
              LABORATORY & OPEN HYPOTHESES
            </span>
            <span className="text-xs font-mono font-semibold text-[#1C1C1C]/60">
              Experimental Synthesis & Anti-Fitting Benchmarks
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold italic tracking-tight text-[#1C1C1C]">
            Epistemic Laboratory
          </h2>
          <p className="text-sm font-serif italic text-[#1C1C1C]/75 mt-1 max-w-2xl">
            Active tracking of domain candidates, reduction formulas, open vulnerabilities, and failure mode stress-tests.
          </p>
        </div>

        <div className="text-xs font-mono font-bold bg-[#EBE8E0] px-3 py-1.5 border border-[#D9D1C1]">
          STATUS: PROVISIONAL AUDIT
        </div>
      </div>

      {/* Grid of Domain & Project Candidates */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs uppercase tracking-[0.2em] font-mono font-black text-[#1C1C1C] flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-[#1C1C1C]" />
            Active Domain & Project Candidates (Compositions with Semantic Value)
          </h3>
          <span className="text-[10px] font-mono text-[#1C1C1C]/60 font-bold">
            RULE: Composable ≠ Unnecessary
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {domainCandidates.map((candidate) => (
            <div
              key={candidate.id}
              onClick={() => onSelectPrimitive(candidate)}
              className="border-2 border-[#1C1C1C] bg-white p-4.5 flex flex-col justify-between hover:bg-[#F9F8F3] cursor-pointer transition-all group shadow-xs"
            >
              <div>
                <div className="flex justify-between items-start mb-2 font-mono text-[9px]">
                  <span className="bg-[#1C1C1C] text-white px-1.5 py-0.2 font-bold uppercase">
                    {candidate.levelLabel}
                  </span>
                  <span className="border border-[#1C1C1C] px-1 font-bold">
                    L{candidate.level}
                  </span>
                </div>

                <h4 className="text-xl font-serif font-bold italic text-[#1C1C1C] group-hover:underline">
                  {candidate.name}
                </h4>
                <div className="text-[10px] uppercase font-mono tracking-widest text-[#1C1C1C]/50 font-bold mb-2">
                  {candidate.tag}
                </div>

                <p className="text-xs font-serif text-[#1C1C1C]/80 leading-relaxed italic mb-3">
                  {candidate.summary}
                </p>
              </div>

              <div className="mt-3 pt-3 border-t border-[#D9D1C1] font-mono text-[10px]">
                <div className="opacity-50 uppercase text-[8px] font-bold">Reduction Formula:</div>
                <div className="font-bold text-amber-900 truncate">
                  {candidate.reductionEquation || 'Compositional Graph'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Two Column: Open Questions vs Failure Modes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Open Questions (OQ-01 .. OQ-04) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-[#1C1C1C]" />
            <h3 className="text-xs uppercase tracking-[0.2em] font-mono font-black text-[#1C1C1C]">
              Open Epistemic Questions (Vulnerabilities)
            </h3>
          </div>

          <div className="space-y-3 font-mono">
            {OPEN_QUESTIONS.map((oq) => {
              const isSelected = selectedOq.id === oq.id;
              return (
                <div
                  key={oq.id}
                  onClick={() => setSelectedOq(oq)}
                  className={`p-4 border-2 cursor-pointer transition-all ${
                    isSelected
                      ? 'border-[#1C1C1C] bg-[#F2EFE9] shadow-xs'
                      : 'border-[#D9D1C1] bg-white hover:border-[#1C1C1C]/60'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[10px] bg-[#1C1C1C] text-white px-2 py-0.5 font-bold">
                      {oq.code}
                    </span>
                    <span className="text-[9px] font-bold border border-[#1C1C1C] px-1.5 uppercase">
                      {oq.status}
                    </span>
                  </div>

                  <h4 className="text-base font-serif font-bold italic text-[#1C1C1C] mb-1">
                    {oq.title}
                  </h4>
                  <p className="text-xs font-serif italic text-[#1C1C1C]/80 leading-snug">
                    {oq.description}
                  </p>

                  {isSelected && (
                    <div className="mt-3 pt-3 border-t border-[#D9D1C1] text-xs font-serif space-y-2">
                      <div className="text-[11px] text-[#1C1C1C]/90">
                        <strong className="font-mono text-[10px] uppercase font-bold text-[#1C1C1C] block not-italic">
                          Architectural Implication:
                        </strong>
                        {oq.implication}
                      </div>
                      {oq.counterexample && (
                        <div className="text-[11px] text-red-900 bg-red-50 p-2 border border-red-200">
                          <strong className="font-mono text-[9px] uppercase font-bold text-red-950 block not-italic">
                            Counterexample / Stress:
                          </strong>
                          {oq.counterexample}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Anti-Fitting Failure Modes Archive */}
        <div className="lg:col-span-6 space-y-4">
          <div className="flex items-center gap-2 text-red-900">
            <ShieldAlert className="w-4 h-4" />
            <h3 className="text-xs uppercase tracking-[0.2em] font-mono font-black text-[#1C1C1C]">
              Anti-Fitting & Failure Modes Archive
            </h3>
          </div>

          <div className="space-y-3 font-serif">
            {/* Mode 1 */}
            <div className="p-4 bg-white border-2 border-red-900/40">
              <div className="flex justify-between items-center font-mono text-[10px] font-bold text-red-900 mb-1">
                <span>FAILURE MODE 01</span>
                <span>TELEOLOGY HALLUCINATION</span>
              </div>
              <h5 className="font-bold text-sm text-[#1C1C1C]">
                Биологическая эволюция (Ложная цель)
              </h5>
              <p className="text-xs text-[#1C1C1C]/80 italic mt-1 leading-relaxed">
                Вопрос <code>WHY / FOR WHAT PURPOSE?</code> провоцирует LLM ответить «Чтобы выжить» и приписать эволюции примитив <code>TARGET/PURPOSE</code>. Но у естественного отбора нет цели. Q-Space обязан блокировать телеологию для слепых процессов.
              </p>
            </div>

            {/* Mode 2 */}
            <div className="p-4 bg-white border-2 border-amber-900/40">
              <div className="flex justify-between items-center font-mono text-[10px] font-bold text-amber-900 mb-1">
                <span>FAILURE MODE 02</span>
                <span>FORCED DISCRETIZATION</span>
              </div>
              <h5 className="font-bold text-sm text-[#1C1C1C]">
                Непрерывные градиенты и поля
              </h5>
              <p className="text-xs text-[#1C1C1C]/80 italic mt-1 leading-relaxed">
                В дискретном ядре SOL есть только фиксированные снимки <code>STATE</code>. При анализе непрерывного поля давления воздуха агент принудительно нарезает среду на искусственные дискретные шаги. Требуется расширение <code>COORDINATE_SPACE</code>.
              </p>
            </div>

            {/* Mode 3 */}
            <div className="p-4 bg-white border-2 border-[#1C1C1C]">
              <div className="flex justify-between items-center font-mono text-[10px] font-bold text-[#1C1C1C] mb-1">
                <span>FAILURE MODE 03</span>
                <span>ASPECT LEAKAGE</span>
              </div>
              <h5 className="font-bold text-sm text-[#1C1C1C]">
                Утечка терминов SOL в сырое наблюдение
              </h5>
              <p className="text-xs text-[#1C1C1C]/80 italic mt-1 leading-relaxed">
                Агент пишет: «Наблюдение: В системе происходит FLOW». Это грубейшая ошибка подгонки. Сырое наблюдение обязано быть сформулировано на естественном доменном языке до сопоставления с SOL.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
