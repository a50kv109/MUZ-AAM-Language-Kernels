import React, { useState } from 'react';
import { SolPrimitive } from '../../types';
import { SOL_PRIMITIVES } from '../../data';
import { BookOpen, Layers, ShieldCheck, ArrowRight, CheckCircle, ExternalLink, Sparkles } from 'lucide-react';

interface IndexViewProps {
  onSelectPrimitive: (primitive: SolPrimitive) => void;
  onNavigateToQSpace: () => void;
}

export const IndexView: React.FC<IndexViewProps> = ({ onSelectPrimitive, onNavigateToQSpace }) => {
  const [filterLevel, setFilterLevel] = useState<number | 'all'>('all');

  const filtered = filterLevel === 'all'
    ? SOL_PRIMITIVES
    : SOL_PRIMITIVES.filter((p) => p.level === filterLevel);

  return (
    <div className="space-y-8 p-6 md:p-8 max-w-6xl mx-auto overflow-y-auto">
      {/* Top Banner / Masthead */}
      <div className="border-b-2 border-[#1C1C1C] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase tracking-[0.25em] font-mono font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
              TABLE I & II
            </span>
            <span className="text-xs font-mono font-semibold text-[#1C1C1C]/60">
              Taxonomy of Semantic Primitives
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold italic tracking-tight text-[#1C1C1C]">
            Universal & Domain Canon Index
          </h2>
          <p className="text-sm font-serif italic text-[#1C1C1C]/75 mt-1 max-w-2xl">
            Complete architectural matrix of atomic primitives, structural invariants, and domain candidates.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-[#1C1C1C]/60 uppercase text-[10px] font-bold">Filter Tier:</span>
          {(['all', 0, 1, 2] as const).map((lvl) => (
            <button
              key={String(lvl)}
              onClick={() => setFilterLevel(lvl)}
              className={`px-2.5 py-1 text-[10px] uppercase font-bold border transition-colors ${
                filterLevel === lvl
                  ? 'bg-[#1C1C1C] text-white border-[#1C1C1C]'
                  : 'bg-white text-[#1C1C1C] border-[#1C1C1C]/30 hover:border-[#1C1C1C]'
              }`}
            >
              {lvl === 'all' ? 'All (14)' : lvl === 0 ? 'Universal O7' : lvl === 1 ? 'Domain' : 'Project'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Broadside Table */}
      <div className="border-2 border-[#1C1C1C] bg-white shadow-xs overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b-2 border-[#1C1C1C] bg-[#F2EFE9] text-[10px] uppercase tracking-widest font-mono font-bold text-[#1C1C1C]">
              <th className="p-3.5 border-r border-[#1C1C1C]">Primitive</th>
              <th className="p-3.5 border-r border-[#1C1C1C]">Tier & Tag</th>
              <th className="p-3.5 border-r border-[#1C1C1C]">Conceptual Anchor (Суть)</th>
              <th className="p-3.5 border-r border-[#1C1C1C]">Anti-Fitting Boundary</th>
              <th className="p-3.5 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#D9D1C1] font-serif text-sm">
            {filtered.map((item) => {
              const isO7 = item.level === 0 && item.levelLabel.includes('O7');
              return (
                <tr
                  key={item.id}
                  onClick={() => onSelectPrimitive(item)}
                  className="hover:bg-[#F9F8F3] cursor-pointer transition-colors group"
                >
                  <td className="p-3.5 border-r border-[#D9D1C1] font-bold text-[#1C1C1C] align-top whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span className="text-base group-hover:underline">{item.name}</span>
                      {isO7 && (
                        <span className="text-[8px] bg-black text-white px-1 py-0.2 font-mono font-bold">
                          O7
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="p-3.5 border-r border-[#D9D1C1] align-top whitespace-nowrap font-mono text-xs">
                    <span className="inline-block px-1.5 py-0.5 bg-[#EBE8E0] text-[9px] font-bold uppercase tracking-wider text-[#1C1C1C]/80 border border-[#D9D1C1] mb-1">
                      {item.levelLabel}
                    </span>
                    <div className="text-[10px] text-[#1C1C1C]/60 italic font-serif font-medium">
                      {item.tag}
                    </div>
                  </td>

                  <td className="p-3.5 border-r border-[#D9D1C1] align-top text-xs leading-relaxed text-[#1C1C1C]/90">
                    <div className="font-medium">{item.summary}</div>
                    {item.reductionEquation && (
                      <div className="mt-1.5 font-mono text-[10px] text-amber-900 bg-[#F5F2EA] px-2 py-0.5 border border-[#D9D1C1] inline-block font-semibold">
                        = {item.reductionEquation}
                      </div>
                    )}
                  </td>

                  <td className="p-3.5 border-r border-[#D9D1C1] align-top text-xs leading-relaxed text-red-950/80 italic font-serif">
                    {item.antiDefinition}
                  </td>

                  <td className="p-3.5 text-right align-top whitespace-nowrap">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectPrimitive(item);
                      }}
                      className="px-2.5 py-1 text-[10px] font-mono uppercase font-bold border border-[#1C1C1C] hover:bg-[#1C1C1C] hover:text-white transition-colors"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Two-Column Methodology Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pillar 1: Primitive Descent Ladder */}
        <div className="border-2 border-[#1C1C1C] p-6 bg-white flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-[#1C1C1C]" />
              <h3 className="text-xs uppercase tracking-[0.2em] font-mono font-black text-[#1C1C1C]">
                Primitive Descent (Нисхождение примитивов)
              </h3>
            </div>
            <p className="text-xs font-serif italic text-[#1C1C1C]/80 mb-4 leading-relaxed">
              Every candidate must receive the lowest necessary level in the epistemic hierarchy. Agents are forbidden from elevating project concepts to Universal core.
            </p>

            <div className="space-y-3 font-mono text-xs">
              <div className="border-l-4 border-[#1C1C1C] pl-3 py-1 bg-[#F9F8F3]">
                <div className="flex justify-between items-center font-bold">
                  <span>Level 0: Universal Canon</span>
                  <span className="text-[10px] bg-[#1C1C1C] text-white px-1.5">O7 Core</span>
                </div>
                <div className="text-[11px] font-serif italic text-[#1C1C1C]/70 mt-0.5">
                  Absolute immutable atoms required for any deterministic system.
                </div>
              </div>

              <div className="border-l-4 border-[#8C827A] pl-3 py-1 bg-[#F9F8F3]">
                <div className="flex justify-between items-center font-bold">
                  <span>Level 1: Domain Canon</span>
                  <span className="text-[10px] border border-[#1C1C1C] px-1.5">TRANSFORM, EVIDENCE...</span>
                </div>
                <div className="text-[11px] font-serif italic text-[#1C1C1C]/70 mt-0.5">
                  Industry-specific axioms (law, engineering, compilation, logic).
                </div>
              </div>

              <div className="border-l-4 border-[#C8BEAC] pl-3 py-1 bg-[#F9F8F3]">
                <div className="flex justify-between items-center font-bold">
                  <span>Level 2: Project Canon</span>
                  <span className="text-[10px] border border-[#1C1C1C] px-1.5">MERGE_RESOLUTION...</span>
                </div>
                <div className="text-[11px] font-serif italic text-[#1C1C1C]/70 mt-0.5">
                  Application-specific structures (VCS, document lifecycles).
                </div>
              </div>

              <div className="border-l-4 border-[#E0D8C8] pl-3 py-1 bg-[#F9F8F3]">
                <div className="flex justify-between items-center font-bold">
                  <span>Level 3: Task Canon</span>
                  <span className="text-[10px] text-[#1C1C1C]/60">Transient execution</span>
                </div>
                <div className="text-[11px] font-serif italic text-[#1C1C1C]/70 mt-0.5">
                  Short-lived task boundaries and temporary execution parameters.
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#D9D1C1] flex items-center justify-between text-xs font-mono font-bold">
            <span className="text-[#1C1C1C]/60">Rule:</span>
            <span className="text-red-800">HUMAN ARCHITECTURAL DECISION REQUIRED FOR L0/L1</span>
          </div>
        </div>

        {/* Pillar 2: The Axiomatic Bridge to Q-Space */}
        <div className="border-2 border-[#1C1C1C] p-6 bg-[#1C1C1C] text-[#F9F8F3] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 text-[#D9D1C1]">
              <ShieldCheck className="w-4 h-4" />
              <h3 className="text-xs uppercase tracking-[0.2em] font-mono font-black">
                The Dynamic Research Pipeline
              </h3>
            </div>

            <div className="text-lg font-serif italic text-[#F9F8F3] mb-4 leading-snug">
              SYSTEM &rarr; Q-SPACE &rarr; OBSERVATION &rarr; ASPECT &rarr; LOSS TEST &rarr; RESIDUE / CANON
            </div>

            <p className="text-xs font-serif italic text-[#F9F8F3]/80 leading-relaxed mb-6">
              SOL-2 is not an encyclopedia of all possible primitives. It is the agent's epistemic steering mechanism to explore unseen systems without hallucinations or forced analogies.
            </p>

            <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
              <div className="border border-white/20 p-2.5">
                <span className="text-white/40 block text-[9px] uppercase">Epistemic Residue</span>
                <span className="font-bold text-amber-300">Question Residue</span>
                <span className="text-[10px] text-white/70 font-serif italic block mt-1">
                  Missing question in Q-Space to notice the phenomenon.
                </span>
              </div>

              <div className="border border-white/20 p-2.5">
                <span className="text-white/40 block text-[9px] uppercase">Ontological Residue</span>
                <span className="font-bold text-emerald-300">Semantic Residue</span>
                <span className="text-[10px] text-white/70 font-serif italic block mt-1">
                  Primitive dictionary is too poor to express without loss.
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/20">
            <button
              onClick={onNavigateToQSpace}
              className="w-full bg-[#F9F8F3] text-[#1C1C1C] hover:bg-white py-2.5 px-4 text-xs font-mono font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-colors"
            >
              <span>Launch Q-Space Navigator</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
