import React from 'react';
import { ScrollText, ShieldCheck, AlertOctagon, CheckCircle2, Bookmark, ArrowDownRight } from 'lucide-react';

export const ConstitutionView: React.FC = () => {
  return (
    <div className="space-y-8 p-6 md:p-8 max-w-5xl mx-auto overflow-y-auto font-serif">
      {/* Masthead */}
      <div className="border-b-2 border-[#1C1C1C] pb-6 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2 font-mono">
            <span className="text-[10px] uppercase tracking-[0.25em] font-bold bg-[#1C1C1C] text-white px-2 py-0.5">
              CONSTITUTIONAL BRIEF
            </span>
            <span className="text-xs font-semibold text-[#1C1C1C]/60">
              SOL Research Repository v0.1-Alpha
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold italic tracking-tight text-[#1C1C1C]">
            Purpose, Identity & Working Principles
          </h2>
          <p className="text-sm italic text-[#1C1C1C]/75 mt-1">
            Foundational charter defining the boundaries between canonical semantic memory (SOL-1) and agent cognitive tooling (SOL-2).
          </p>
        </div>
      </div>

      {/* Broadside Articles */}
      <div className="space-y-6 text-sm text-[#1C1C1C]/90 leading-relaxed">
        {/* Article 1 */}
        <section className="p-6 bg-white border-2 border-[#1C1C1C] space-y-3 shadow-xs">
          <div className="flex items-center justify-between font-mono text-[10px] border-b border-[#D9D1C1] pb-2 font-bold">
            <span className="bg-[#1C1C1C] text-white px-2 py-0.5 uppercase tracking-widest">
              ARTICLE I &bull; NATURE OF THE REPOSITORY
            </span>
            <span className="text-[#1C1C1C]/60">[NOT CODE &bull; NOT ENCYCLOPEDIA]</span>
          </div>
          <h3 className="text-xl font-bold italic text-[#1C1C1C]">
            Накопительный методологический репозиторий
          </h3>
          <p>
            Это <strong>НЕ обычный репозиторий программного кода</strong>, не энциклопедия и не готовые решения отдельных проектов. Это накопительная когнитивная среда для AI-агентов, фиксирующая способы исследования сложных систем и принятия обоснованных решений.
          </p>
          <div className="p-3 bg-[#F9F8F3] border-l-4 border-[#1C1C1C] font-mono text-xs italic">
            «Maximum useful navigation with minimum unnecessary complexity.»
          </div>
        </section>

        {/* Article 2 */}
        <section className="p-6 bg-white border-2 border-[#1C1C1C] space-y-3 shadow-xs">
          <div className="flex items-center justify-between font-mono text-[10px] border-b border-[#D9D1C1] pb-2 font-bold">
            <span className="bg-[#1C1C1C] text-white px-2 py-0.5 uppercase tracking-widest">
              ARTICLE II &bull; THE DUAL DIVISION
            </span>
            <span className="text-[#1C1C1C]/60">[SOL-1 ⟷ SOL-2 BOUNDARY]</span>
          </div>
          <h3 className="text-xl font-bold italic text-[#1C1C1C]">
            Разграничение SOL-1 и SOL-2
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-4 bg-[#F2EFE9] border border-[#D9D1C1]">
              <span className="font-mono text-[10px] uppercase font-bold text-[#1C1C1C] block mb-1">
                SOL-1: Канонический слой
              </span>
              <p className="text-xs italic leading-relaxed">
                Каноническая read-only библиотека семантических примитивов (O7 ядро). Отвечает на вопрос: <em>«Какими минимальными проверенными строительными блоками мы располагаем?»</em>
              </p>
            </div>
            <div className="p-4 bg-[#EBE8E0] border border-[#D9D1C1]">
              <span className="font-mono text-[10px] uppercase font-bold text-[#1C1C1C] block mb-1">
                SOL-2: Инструментально-навигационный слой
              </span>
              <p className="text-xs italic leading-relaxed">
                Внешнее когнитивное орудие агента. Отвечает на вопрос: <em>«Как исследовать новую систему и определить, какие семантические средства необходимы?»</em>
              </p>
            </div>
          </div>
        </section>

        {/* Article 3 */}
        <section className="p-6 bg-white border-2 border-[#1C1C1C] space-y-3 shadow-xs">
          <div className="flex items-center justify-between font-mono text-[10px] border-b border-[#D9D1C1] pb-2 font-bold">
            <span className="bg-[#1C1C1C] text-white px-2 py-0.5 uppercase tracking-widest">
              ARTICLE III &bull; ANTI-FITTING & RESIDUE
            </span>
            <span className="text-red-800">[STRICT INVARIANT]</span>
          </div>
          <h3 className="text-xl font-bold italic text-[#1C1C1C]">
            Запрет на подгонку (Anti-Fitting Mandate)
          </h3>
          <p>
            Агенту строжайше запрещено:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-xs italic">
            <li>Подгонять систему под существующие термины из-за поверхностного словесного сходства;</li>
            <li>Создавать новый универсальный примитив без фиксации объективного Semantic Residue;</li>
            <li>Самовольно повышать статус проектного или доменного концепта до уровня Universal (O7);</li>
            <li>Скрывать неполноту канона принудительным мэппингом.</li>
          </ul>
        </section>

        {/* Article 4 */}
        <section className="p-6 bg-[#1C1C1C] text-[#F9F8F3] space-y-3 shadow-xs">
          <div className="flex items-center justify-between font-mono text-[10px] border-b border-white/20 pb-2 font-bold text-[#D9D1C1]">
            <span className="uppercase tracking-widest">
              ARTICLE IV &bull; RESEARCH CORPUS PROTOCOL
            </span>
            <span>[ACCUMULATE ➔ CLASSIFY ➔ SYNTHESIZE]</span>
          </div>
          <h3 className="text-xl font-bold italic text-white">
            Текущий режим работы
          </h3>
          <p className="text-xs text-[#F9F8F3]/80 italic">
            Репозиторий находится в фазе накопления корпуса. Архитектура файлов и папок не замораживается преждевременно до получения команды <em>«КОРПУС ПЕРЕДАН. НАЧИНАЙ СИНТЕЗ.»</em>.
          </p>
        </section>
      </div>
    </div>
  );
};
