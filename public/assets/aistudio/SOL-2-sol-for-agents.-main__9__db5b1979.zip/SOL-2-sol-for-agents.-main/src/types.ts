export type ViewMode = 'index' | 'navigator' | 'laboratory' | 'evidence' | 'gateway' | 'constitution';

export type PrimitiveCategory = 'universal' | 'extension' | 'domain' | 'project';

export interface SolPrimitive {
  id: string;
  name: string;
  level: 0 | 1 | 2;
  levelLabel: 'Universal Canon (O7)' | 'System Extension' | 'Domain Canon' | 'Project Canon';
  tag: string;
  summary: string;
  formalDefinition: string;
  antiDefinition: string;
  reductionEquation?: string;
  status: 'CANONICAL' | 'DOMAIN_CANDIDATE' | 'PROJECT_CANDIDATE' | 'PROVISIONAL';
  domainContext?: string;
  colorTheme?: string;
}

export interface QuestionNode {
  id: string;
  question: string;
  questionRu: string;
  category: 'root' | 'domain' | 'derivative' | 'diagnostic' | 'counterfactual';
  uncertaintyCleared: string;
  exampleObservation: string;
  typicalNextSteps: string[];
  inapplicableCases?: string;
}

export interface CaseStudy {
  id: string;
  code: string;
  title: string;
  domain: string;
  systemDescription: string;
  qSpaceTrajectory: string[];
  findings: string;
  discoveredPrimitiveOrResidue: string;
  epistemicLesson: string;
  methodologyImpact: string;
}

export interface OpenQuestionItem {
  id: string;
  code: string;
  title: string;
  status: 'OPEN' | 'RESEARCH_HYPOTHESIS' | 'PROVISIONAL';
  description: string;
  implication: string;
  counterexample?: string;
}

export interface ObservationReport {
  id: string;
  sourceProject: string;
  observation: string;
  solRelation: string;
  methodologyImpact: string;
  hypothesisConfirmation: 'CONFIRMED' | 'PARTIALLY_CONFIRMED' | 'REFUTED' | 'INCONCLUSIVE';
  hypothesisRefutationNotes: string;
  semanticResidue: string;
  requiredChange: string;
  timestamp: string;
}
