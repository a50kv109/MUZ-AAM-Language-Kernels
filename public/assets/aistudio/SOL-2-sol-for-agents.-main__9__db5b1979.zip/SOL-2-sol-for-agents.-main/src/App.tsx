/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ViewMode, SolPrimitive } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Sidebar } from './components/Sidebar';
import { IndexView } from './components/views/IndexView';
import { NavigatorView } from './components/views/NavigatorView';
import { LaboratoryView } from './components/views/LaboratoryView';
import { EvidenceView } from './components/views/EvidenceView';
import { GatewayView } from './components/views/GatewayView';
import { ConstitutionView } from './components/views/ConstitutionView';
import { PrimitiveDetailModal } from './components/PrimitiveDetailModal';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('index');
  const [selectedPrimitive, setSelectedPrimitive] = useState<SolPrimitive | null>(null);

  return (
    <div className="h-screen w-screen bg-[#F9F8F3] text-[#1C1C1C] flex flex-col overflow-hidden border-4 md:border-8 border-[#1C1C1C] select-text">
      {/* Editorial Header */}
      <Header
        currentView={currentView}
        onSelectView={setCurrentView}
        corpusCount={42}
      />

      {/* Main Multi-Pane Body */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        {/* Left Canonical Sidebar */}
        <Sidebar
          selectedPrimitiveId={selectedPrimitive?.id}
          onSelectPrimitive={(p) => setSelectedPrimitive(p)}
          onOpenGateway={() => setCurrentView('gateway')}
        />

        {/* Central Stage */}
        <main className="flex-1 bg-white overflow-y-auto relative">
          {currentView === 'index' && (
            <IndexView
              onSelectPrimitive={(p) => setSelectedPrimitive(p)}
              onNavigateToQSpace={() => setCurrentView('navigator')}
            />
          )}

          {currentView === 'navigator' && (
            <NavigatorView />
          )}

          {currentView === 'laboratory' && (
            <LaboratoryView
              onSelectPrimitive={(p) => setSelectedPrimitive(p)}
            />
          )}

          {currentView === 'evidence' && (
            <EvidenceView />
          )}

          {currentView === 'gateway' && (
            <GatewayView />
          )}

          {currentView === 'constitution' && (
            <ConstitutionView />
          )}
        </main>
      </div>

      {/* Editorial System Footer */}
      <Footer
        statusMessage="Observation Gateway Active"
        bufferCount={42}
      />

      {/* Detail Form Inspector Modal */}
      <PrimitiveDetailModal
        primitive={selectedPrimitive}
        onClose={() => setSelectedPrimitive(null)}
      />
    </div>
  );
}

