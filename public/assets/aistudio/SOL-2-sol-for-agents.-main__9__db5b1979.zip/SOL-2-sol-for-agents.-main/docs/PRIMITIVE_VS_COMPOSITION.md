# PRIMITIVE VS COMPOSITION

> **Status:** `CURRENT METHODOLOGY / COMPOSITIONAL ALGEBRA`  
> **Core Axiom:** *Composable $\neq$ Unnecessary. Expressiveness grows through composition, never by diluting the canonical core.*

---

## 1. The Ontological Hierarchy (L0 to L3)

To prevent primitive explosion, SOL strictly categorizes concepts into 4 levels:

```
┌─────────────────────────────────────────────────────────────┐
│ LEVEL 0: CANONICAL PRIMITIVES (O7)                          │
│ Irreducible, domain-agnostic physical/logical invariants.   │
│ [SOURCE, STATE, FLOW, CONSTRAINT, COMPARE, DISSIPATE, ...]  │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼ Composed into
┌─────────────────────────────────────────────────────────────┐
│ LEVEL 1: COMPOSITIONS & DOMAIN CANON                        │
│ Universal engineering patterns built purely from L0.        │
│ [TRANSFORM, EVIDENCE, SŪTRA/RULE, INTERACTION_CONTRACT]     │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼ Structured into
┌─────────────────────────────────────────────────────────────┐
│ LEVEL 2: DOMAIN PACKS & SYSTEM PATTERNS                     │
│ Specific industry configurations (Database, Network, DLE). │
│ [CACHE, TRANSACTION, REPLICATION, PIPELINE, IDEMPOTENCY]    │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼ Instantiated in
┌─────────────────────────────────────────────────────────────┐
│ LEVEL 3: PROJECT-SPECIFIC RUNTIME ENTITIES                  │
│ Concrete files, endpoints, and variables in your codebase.  │
│ [AuthService.ts, /api/checkout, users_v2 table]             │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Historical Case Study: `INTERACTION_CONTRACT`

In early versions of the ontology, `INTERACTION_CONTRACT` was proposed as an 8th fundamental primitive to describe APIs and protocols.

### The Reduction Proof:
Why is `INTERACTION_CONTRACT` **not** an irreducible primitive?

$$\text{INTERACTION\_CONTRACT} \equiv \text{INTERFACE} (\text{STATE}) + \text{MESSAGE\_VECTOR} (\text{FLOW}) + \text{INVARIANTS} (\text{CONSTRAINT}) + \text{AUTHORITY} (\text{CAPABILITY})$$

* **Result:** Because `INTERACTION_CONTRACT` can be completely expressed by composing 4 existing Level 0 primitives without losing any operational semantics, it was classified as a **Level 1 Composition**.
* **Epistemic Lesson:** If an entity can be factored into $O7$ primitives, promoting it to Level 0 is a violation of ontological parsimony.

---

## 3. Common Composite Engineering Patterns

| Domain Concept | Level | Structural Reduction Equation in $O7$ |
| :--- | :---: | :--- |
| **`TRANSFORM`** | L1 | $\text{STATE}(A) \xrightarrow{\text{FLOW}} \text{STATE}(B) \quad [\text{with invariant } \text{SOURCE}]$ |
| **`EVIDENCE`** | L1 | $\text{STATE}(\text{Fact}) + \text{COMPARE}(\text{Criteria}, \text{CONSTRAINT}) \implies \text{Valid}$ |
| **`SŪTRA / RULE`** | L1 | $\text{CONSTRAINT} + \text{COMPARE}(\text{Trigger}) \rightarrow \text{FLOW}$ |
| **`CACHE`** | L2 | $\text{STATE}(\text{Ephemeral}) + \text{COMPARE}(\text{TTL}) + \text{DISSIPATE}(\text{Eviction})$ |
| **`IDEMPOTENT_SINK`**| L2 | $\text{FLOW} \rightarrow \text{COMPARE}(\text{PrimaryKey}, \text{STATE}) \xrightarrow{\text{exists}} \text{DISSIPATE}(\text{Duplicate})$ |
| **`DEAD_LETTER_QUEUE`**| L2 | $\text{FLOW} \xrightarrow{\text{violates } \text{CONSTRAINT}} \text{FLOW}_{\text{reroute}} \rightarrow \text{STATE}(\text{DLQ})$ |

---

## 4. The Agent's Decision Rule for New Candidates

When you encounter a new domain term (e.g. *"GraphQL Schema"*, *"Rate Limiter"*, *"Circuit Breaker"*):

1. **Step 1:** Do not add it to the primitive catalog.
2. **Step 2:** Write its reduction equation using $O7$.
3. **Step 3:** If all behaviors and failure modes are accounted for $\rightarrow$ use it as an **Engineering Pattern (L2)**.
4. **Step 4:** Only if an irrecoverable semantic loss occurs that cannot be captured even in `Semantic Residue`, submit an observation report to the Laboratory.
