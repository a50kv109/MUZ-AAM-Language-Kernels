# WHEN TO USE SOL

> **Status:** `CURRENT METHODOLOGY / AGENT HEURISTICS`  
> **Rule:** *Use SOL when structural invariants matter. Do not use SOL for stateless or trivial operations.*

---

## 1. The Decision Flowchart

```
                 DOES THE TASK HAVE STATE, CONSTRAINTS, OR MULTI-AGENT HANDOFF?
                                                │
                                ┌───────────────┴───────────────┐
                                ▼ NO                            ▼ YES
                        [DO NOT USE SOL]              ARE YOU ABOUT TO MUTATE STATE
                       (Answer directly)              OR EXECUTE A DESTRUCTIVE TOOL?
                                                                │
                                                ┌───────────────┴───────────────┐
                                                ▼ NO                            ▼ YES
                                    DOES THE TASK INVOLVE          [MANDATORY SOL CHECK]
                                    CONCURRENCY, MULTI-SOURCE,      • Check STATE status
                                    OR CROSS-LANGUAGE SPECS?        • Audit CONSTRAINTS
                                                │                   • Prevent Blind Mutation
                                ┌───────────────┴───────────────┐
                                ▼ NO                            ▼ YES
                        [OPTIONAL SOL]                  [RECOMMENDED SOL]
                        (Use standard CoT)              (Map O7 topology)
```

---

## 2. Definitive Activation Triggers

### 🔴 MANDATORY (Critical Safety & State Preservation)
1. **Destructive Operations:** Any invocation of `delete_file`, `DROP TABLE`, `rm -rf`, or resource unprovisioning.
2. **Schema & Contract Changes:** Modifying database models, public API interfaces, or cross-service event schemas.
3. **Multi-Agent State Handoff:** Exporting task context from one agent to another where downstream actions depend on exact boundaries.

### 🟡 RECOMMENDED (High Complexity & Ambiguity)
1. **Cross-Language Technical Specifications:** Translating architectural requirements between French, Chinese, English, Russian, etc.
2. **Asynchronous & Race-Prone Pipelines:** Event-driven architectures, WebSocket feeds, webhook handlers, message queues.
3. **Multi-Source Requirement Conflicts:** When user prompt contradicts system governance rules or existing codebase conventions.
4. **Architectural Evaluation:** Deciding whether a new library or component (e.g. Redis, Kafka) is truly needed.

### 🟢 OPTIONAL (Informational Analysis)
1. **Codebase Architecture Audit:** Mapping dependencies across a large unfamiliar repository.
2. **Root Cause Analysis (Post-Mortem):** Tracing silent failures or unexpected system degradation.
