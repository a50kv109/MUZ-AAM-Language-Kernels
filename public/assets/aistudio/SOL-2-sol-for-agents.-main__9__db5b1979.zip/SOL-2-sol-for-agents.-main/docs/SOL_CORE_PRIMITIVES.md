# SOL CORE PRIMITIVES (O7 CANON)

> **Status:** `FROZEN CANON / LEVEL 0 UNIVERSAL FOUNDATION`  
> **Scope:** The 7 irreducible, domain-independent operational primitives of SOL-1.

---

## 1. SOURCE (Genesis Anchor)

* **Plain Meaning:** The absolute origin, creator, or root authority of data, energy, or intent.
* **Structural Role:** Provides the invariant reference anchor that survives all subsequent transformations of form.
* **What it is NOT:** It is NOT merely a "file on disk", a "payload", or an "input argument". It is the *unforgeable root origin*.
* **Engineering Example:** The cryptographic root certificate (CA) or the initial client webhook trigger.
* **Anti-Pattern:** Treating an intermediate database cache as the `SOURCE` of user profile data.
* **Relations:** $\text{SOURCE} \xrightarrow{\text{spawns}} \text{FLOW} \xrightarrow{\text{settles into}} \text{STATE}$.

---

## 2. STATE (Immutable Snapshot)

* **Plain Meaning:** A discrete, observed configuration of parameters or structure at a specific point in time.
* **Structural Role:** A stable node in the topology representing settled reality.
* **What it is NOT:** It is NOT dynamic execution, and NOT a running background process.
* **Engineering Example:** The row `order_status = "PAID"` in PostgreSQL, or a file saved on disk.
* **Anti-Pattern:** Assuming that while an HTTP request is in-flight, the state is already updated.
* **Relations:** $\text{STATE}_1 \xrightarrow{\text{FLOW}} \text{STATE}_2$.

---

## 3. FLOW (Vector of Transfer)

* **Plain Meaning:** The directional transfer of data, energy, or state over a duration $\Delta t > 0$.
* **Structural Role:** Connects states and nodes across physical or logical boundaries without altering root genesis.
* **What it is NOT:** It is NOT instantaneous mutation, and NOT an ungrounded abstraction.
* **Engineering Example:** An HTTP streaming payload, a Kafka topic stream, or a message passing through a network socket.
* **Anti-Pattern:** Assuming a network call takes 0 milliseconds and has no in-flight failure modes.
* **Relations:** $\text{FLOW}$ is bounded by $\text{CONSTRAINT}$ and terminates in $\text{STATE}$ or $\text{DISSIPATE}$.

---

## 4. CONSTRAINT (Absolute Boundary)

* **Plain Meaning:** A non-negotiable limit, law of conservation, or filter that defines the allowed phase space.
* **Structural Role:** Reduces the system's degrees of freedom. Any state violating a constraint is invalid ($\emptyset$).
* **What it is NOT:** It is NOT a soft recommendation, a code style preference, or a standard if-else branch.
* **Engineering Example:** Available RAM ($512\text{MB}$), Database Unique Foreign Key constraint, or Type safety invariants.
* **Anti-Pattern:** Treating a hard memory limit as a suggestion that can be ignored under load.
* **Relations:** $\text{FLOW} \le \text{CONSTRAINT}$.

---

## 5. COMPARE (Delta Processor)

* **Plain Meaning:** The active evaluation of difference or divergence between two states, or between a state and a constraint.
* **Structural Role:** Generates a delta ($\Delta$) that drives decision logic and verification.
* **What it is NOT:** It is NOT the action taken after comparison (e.g. "branching"); it is the *evaluation itself*.
* **Engineering Example:** `git diff`, hash verification `SHA256(file) == expected`, or schema validation.
* **Anti-Pattern:** Assuming two schemas match without explicitly evaluating their structural diff.
* **Relations:** $\text{COMPARE}(\text{STATE}, \text{CONSTRAINT}) \implies \Delta$.

---

## 6. DISSIPATE (Entropy Sink)

* **Plain Meaning:** The unrecoverable loss, discard, noise absorption, or silent destruction of state.
* **Structural Role:** The thermodynamic or logical sink where dead-end paths, dropped packets, and garbage-collected memory exit the system.
* **What it is NOT:** It is NOT the destruction of the original root `SOURCE`; it is the retirement of transient state.
* **Engineering Example:** Dropping late streaming events, `DROP TABLE`, deleting temporary files, or packet loss over UDP.
* **Anti-Pattern:** Ignoring `DISSIPATE` channels, causing silent data disappearance without error logs.
* **Relations:** $\text{FLOW} \xrightarrow{\text{overflow}} \text{DISSIPATE}$.

---

## 7. CAPABILITY (Executive Right)

* **Plain Meaning:** The formal operational contract or authorization granting an agent/component the right to initiate state mutation.
* **Structural Role:** Defines who is allowed to trigger a transition.
* **What it is NOT:** It is NOT the physical action itself, but the *authority to execute it*.
* **Engineering Example:** An IAM Role with `s3:PutObject` permission, or OAuth token with `read:orders` scope.
* **Anti-Pattern:** An agent performing a destructive root-level action without verifying its role capability.
* **Relations:** $\text{CAPABILITY} \times \text{ACTION} \xrightarrow{\text{valid}} \text{MUTATION}$.

---

## 8. System Spatial Extensions (Level 0 Support)

* **`INDEX`:** The topological map or coordinate pointer linking multiple state nodes.
* **`COORDINATE_SPACE`:** The frame of reference (memory address, file path, filesystem URI, coordinate grid) in which states reside.
