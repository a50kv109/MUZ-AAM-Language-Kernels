# EXPERIMENTAL ROADMAP (EXP-01 TO EXP-06)

> **Status:** `EXPERIMENTAL VALIDATION PLAN / SCIENTIFIC PROTOCOLS`  
> **Epistemic Rule:** *No claim of efficiency, error elimination, or invariance is accepted as fact until validated by these falsifiable protocols.*

---

## Roadmap Overview

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│    EXP-01    │ ──► │    EXP-02    │ ──► │    EXP-03    │
│  Extraction  │     │ Action Gate  │     │ Multi-Agent  │
│  Robustness  │     │ Safety Test  │     │ Context Pass │
└──────────────┘     └──────────────┘     └──────────────┘
       │                    │                    │
       ▼                    ▼                    ▼
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│    EXP-04    │ ──► │    EXP-05    │ ──► │    EXP-06    │
│Cross-Language│     │Architectural │     │Semantic Loss │
│ Invariance   │     │  Reduction   │     │ Quantification│
└──────────────┘     └──────────────┘     └──────────────┘
```

---

## Detailed Protocol Specifications

### EXP-01: Primitive Extraction Consistency
* **Hypothesis:** Given an ambiguous technical requirement, independent agents following the SOL Extraction Pipeline produce isomorphic structural graphs with significantly higher topological overlap than free-form natural language summaries.
* **Input Dataset:** 50 ambiguous engineering requirements (distributed systems, database migrations, security policies).
* **Control Group:** Agent A summarizing requirements in standard Markdown / natural language.
* **Experimental Group:** Agent B using the 10-step SOL extraction pipeline to output an $O7$ AST graph.
* **Metrics:** Graph Isomorphism Score (Jaccard distance on extracted nodes/edges), Inter-Agent Agreement ($\kappa$).
* **Falsification Criterion:** If graph isomorphism across models (e.g. Claude, GPT-4, Gemini) is $< 65\%$, the extraction methodology is insufficiently deterministic.

---

### EXP-02: Pre-Action Decision Gate (Action Gate)
* **Hypothesis:** Enforcing a mandatory pre-action state verification gate before invoking mutating tools (`edit_file`, `delete_file`, SQL execution) reduces broken builds and rollbacks by $\ge 40\%$.
* **Input Dataset:** 100 complex refactoring tasks in multi-file repositories with hidden cross-file dependencies.
* **Control Group:** Autonomous agent executing tool calls via standard CoT.
* **Experimental Group:** Autonomous agent running through the `docs/SOL_DECISION_LAYER.md` gate (blocks mutation if $\text{STATE} = \text{UNKNOWN}$).
* **Metrics:** Mutation Error Rate (tool execution rollbacks, broken test suites), Token Overhead Ratio, Execution Latency.
* **Falsification Criterion:** If the mutation error rate decreases by $< 15\%$ or the token overhead exceeds $2.5\times$ without safety gain.

---

### EXP-03: Multi-Agent Handoff Fidelity
* **Hypothesis:** Transferring technical architecture via a serialized SOL AST preserves state invariants and prevents downstream hallucination better than transferring natural language summaries.
* **Input Dataset:** Multi-tier system designs passed across a 4-agent pipeline ($A \rightarrow B \rightarrow C \rightarrow D$).
* **Control Group:** Chain of agents passing standard English technical summaries.
* **Experimental Group:** Chain of agents passing validated SOL AST JSON representations.
* **Metrics:** Constraint Preservation Rate, Hallucinated Entities Count, Downstream Code Compliance.
* **Falsification Criterion:** If downstream Agent D in the SOL group hallucinates constraints at a rate $\ge$ the natural language control group.

---

### EXP-04: Cross-Language Semantic Invariance
* **Hypothesis:** Extracting SOL structures from French, Chinese, and Russian technical documents yields identical topological models, eliminating translational rhetorical drift.
* **Input Dataset:** 30 identical aerospace/software specification documents drafted natively in French, Chinese, Russian, and English.
* **Control Group:** Translation chain (French $\rightarrow$ English $\rightarrow$ Chinese) evaluated for contract consistency.
* **Experimental Group:** Multi-language extraction to SOL AST $\rightarrow$ automated graph comparison ($\text{COMPARE}(\text{SOL}_{\text{FR}}, \text{SOL}_{\text{ZH}})$).
* **Metrics:** Semantic Divergence Score, Discrepancy Detection Accuracy.
* **Falsification Criterion:** If cross-lingual extraction produces structurally incompatible topologies for the same logical spec.

---

### EXP-05: Architectural Reduction & Component Parsimony
* **Hypothesis:** Applying the SOL Reduction Test to proposed architectural additions prevents unnecessary infrastructure sprawl (e.g., adding unneeded distributed caches).
* **Input Dataset:** 40 architectural design prompts with hidden native database capabilities.
* **Control Group:** Standard system design recommendations from LLMs.
* **Experimental Group:** LLM equipped with $O7$ Reduction Engine checking candidate components.
* **Metrics:** Unnecessary Entity Rate, System Complexity Index (cyclomatic / service count).
* **Falsification Criterion:** If the reduction engine rejects necessary domain components or fails to filter redundant ones.

---

### EXP-06: Semantic Loss & Residue Quantification
* **Hypothesis:** The Semantic Loss Test successfully isolates $100\%$ of non-topological domain invariants into the structured `Semantic Residue` field without data loss.
* **Input Dataset:** 50 high-nuance regulatory and cryptographic specifications.
* **Metrics:** Round-Trip Reconstruction Fidelity (Original $\rightarrow$ SOL + Residue $\rightarrow$ Reconstructed).
* **Falsification Criterion:** If round-trip reconstructed specifications miss actionable security/regulatory rules.
