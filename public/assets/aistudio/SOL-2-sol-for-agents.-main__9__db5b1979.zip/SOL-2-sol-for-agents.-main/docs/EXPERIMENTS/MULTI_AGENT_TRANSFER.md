# EXPERIMENT SPECIFICATION: MULTI-AGENT HANDOFF (EXP-03)

> **Status:** `PROPOSED EXPERIMENTAL PROTOCOL`  
> **Target:** Measuring constraint degradation across multi-agent pipelines comparing Natural Language vs. Serialized SOL AST.

---

## 1. Experimental Setup

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ PIPELINE 1 (CONTROL): NATURAL LANGUAGE CHAIN                                │
│ Task Spec ──► [Agent 1] ──(NL Summary)──► [Agent 2] ──(NL Summary)──► [Code]│
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ PIPELINE 2 (EXPERIMENTAL): SOL AST TRANSFER                                 │
│ Task Spec ──► [Agent 1] ──(SOL AST)─────► [Agent 2] ──(SOL AST)─────► [Code]│
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Experimental Parameters

* **Pipeline Depth:** 4 consecutive agent hops ($A \rightarrow B \rightarrow C \rightarrow D$).
* **Task Domain:** Complex distributed microservices with cross-service authorization and idempotency requirements.
* **Evaluation Dimensions:**
  1. **Constraint Retention Rate ($R_c$):** Number of original architectural invariants surviving at Agent $D$.
  2. **Hallucination Density ($H_d$):** Number of ungrounded components, ports, or assumptions invented by intermediate agents.
  3. **Implementation Correctness ($C_{\text{code}}$):** Pass rate of unit and integration tests written by Agent $D$.

---

## 3. Falsification Criterion

If downstream Agent $D$ in the SOL AST group demonstrates zero statistically significant improvement in $R_c$ or test pass rate over the Natural Language group ($p > 0.05$), the multi-agent transfer advantage is **falsified**.
