# EXPERIMENT SPECIFICATION: CROSS-LANGUAGE TRANSFER (EXP-04)

> **Status:** `PROPOSED EXPERIMENTAL PROTOCOL`  
> **Target:** Testing whether SOL invariant extraction eliminates rhetorical drift across natural languages (French, Chinese, Russian, English).

---

## 1. Experimental Setup

```
   ┌───────────────────────┐       ┌───────────────────────┐       ┌───────────────────────┐
   │  FRENCH SPECIFICATION │       │ CHINESE SPECIFICATION │       │ RUSSIAN SPECIFICATION │
   │  "Système de vanne"   │       │      "阀门控制系统"    │       │   "Клапанная система"  │
   └───────────┬───────────┘       └───────────┬───────────┘       └───────────┬───────────┘
               │                               │                               │
               ▼                               ▼                               ▼
   ┌───────────────────────┐       ┌───────────────────────┐       ┌───────────────────────┐
   │  Agent A (FR Prompt)  │       │  Agent B (ZH Prompt)  │       │  Agent C (RU Prompt)  │
   │  Extracts SOL AST     │       │  Extracts SOL AST     │       │  Extracts SOL AST     │
   └───────────┬───────────┘       └───────────┬───────────┘       └───────────┬───────────┘
               │                               │                               │
               └───────────────────────┬───────────────────────────────────────┘
                                       │
                                       ▼
                       ╔═══════════════════════════════╗
                       ║   AUTOMATED GRAPH COMPARE     ║
                       ║ COMPARE(SOL_FR, SOL_ZH, ...)  ║
                       ╚═══════════════════════════════╝
                                       │
                                       ▼
                       ┌───────────────────────────────┐
                       │ TOPOLOGICAL DISCREPANCY AUDIT │
                       │ Are constraints identical?    │
                       └───────────────────────────────┘
```

---

## 2. Hypothesis & Metrics

* **Hypothesis:** Multi-lingual technical specifications translated via natural language accumulate semantic drift, whereas direct extraction to a SOL AST isolates the invariant topology, enabling $100\%$ automated discrepancy detection.
* **Control:** Direct machine translation (FR $\rightarrow$ EN $\rightarrow$ ZH).
* **Metrics:**
  1. **Constraint Invariance ($\mathcal{I}_c$):** Percentage of numerical limits and bounds preserved identically across all 3 language extractions.
  2. **Discrepancy Precision / Recall:** Ability of $\text{COMPARE}(\text{AST}_A, \text{AST}_B)$ to pinpoint deliberately injected contract differences in the source texts.

---

## 3. Falsification Criterion

If independent language extractions yield non-isomorphic topologies for logically identical documents at a rate $> 15\%$, the hypothesis of language-independent invariant extraction is **falsified**.
