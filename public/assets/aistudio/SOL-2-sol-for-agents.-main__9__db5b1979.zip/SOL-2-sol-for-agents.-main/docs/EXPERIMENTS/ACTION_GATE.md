# EXPERIMENT SPECIFICATION: ACTION GATE (EXP-02)

> **Status:** `PROPOSED EXPERIMENTAL PROTOCOL`  
> **Target:** Measuring error reduction and token overhead when enforcing a pre-tool-call structural verification layer.

---

## 1. Experimental Setup

```
                     ┌───────────────────────────┐
                     │    TASK: REFACTOR REPO    │
                     └─────────────┬─────────────┘
                                   │
                 ┌─────────────────┴─────────────────┐
                 ▼ (Control Group)                   ▼ (Experimental Group)
   ┌───────────────────────────┐       ┌───────────────────────────┐
   │    STANDARD CoT AGENT     │       │    SOL ACTION GATE AGENT  │
   │  Direct tool invocation   │       │  Mandatory State Check    │
   └─────────────┬─────────────┘       └─────────────┬─────────────┘
                 │                                   │
                 ▼                                   ▼
   ┌───────────────────────────┐       ┌───────────────────────────┐
   │  1. edit_file("Comp.tsx") │       │  1. STATE = UNKNOWN       │
   │  2. Error: missing types  │       │  2. FORBID MUTATION       │
   │  3. edit_file("types.ts") │       │  3. view_file("types.ts") │
   │  4. Broken build rollback │       │  4. edit_file("Comp.tsx") │
   └───────────────────────────┘       └───────────────────────────┘
```

---

## 2. Experimental Parameters

* **Independent Variable:** Presence of the Pre-Action SOL Verification Gate.
* **Controlled Variables:** Base LLM model (same checkpoint & temperature), repository codebase, test suite, and refactoring prompt.
* **Dependent Variables / Metrics:**
  1. **Mutation Error Rate ($E_m$):** $\frac{\text{Failed tool calls + Build failures}}{\text{Total tool calls}}$
  2. **First-Turn Green Rate ($R_g$):** Percentage of tasks where all unit tests pass on turn 1.
  3. **Token Efficiency Ratio ($T_r$):** $\frac{\text{Total tokens consumed (including retry)}}{\text{Baseline token consumption}}$
  4. **False Positive Block Rate ($F_p$):** Rate at which the Action Gate blocks a valid, safe tool call.

---

## 3. Falsification Criterion

If over 100 trials the Action Gate demonstrates:
$$\Delta E_m < 15\% \quad \text{OR} \quad T_r > 2.5$$
The hypothesis that the SOL Action Gate improves net agent execution efficiency is **falsified**.
