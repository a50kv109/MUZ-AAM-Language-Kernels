# WHEN NOT TO USE SOL

> **Status:** `CURRENT METHODOLOGY / ANTI-BUREAUCRACY MANIFESTO`  
> **Core Directive:** *SOL must reduce cognitive noise, not create it. Unsolicited, ceremonial application of SOL is a critical defect.*

---

## 1. The Anti-Bureaucracy Rule

> If an agent outputs a 50-line SOL breakdown before answering *"How do I center a div in CSS?"* or fixing a 1-character typo, the agent has failed.
>
> **SOL is an operational structural harness, not a religious liturgy.**

---

## 2. Definitive Exclusion List

Do **NOT** use SOL for:

1. **Simple Informational Answers:**  
   * *"What is the difference between `let` and `const` in JavaScript?"*  
   * *"Translate 'Good morning' to Spanish."*
2. **Stateless Transformations:**  
   * Pure mathematical calculations ($2 + 2 = 4$).  
   * Regex matching on a single standalone string.
3. **Obvious & Isolated File Reads:**  
   * Viewing `metadata.json` or `package.json` to check a package version.
4. **Minor UI/CSS Adjustments:**  
   * Changing a button color from blue to red, adjusting padding, or centering text.
5. **Standard Conversational Greetings & Clarifications:**  
   * Acknowledging user input or asking clarifying questions about design preferences.
6. **Self-Contained Single-Function Bug Fixes:**  
   * Fixing a syntax error or a null-check inside an isolated pure helper function.

---

## 3. The 3 Diagnostic Anti-Patterns

| Anti-Pattern | Bad Behavior | Correct Agent Behavior |
| :--- | :--- | :--- |
| **Liturgy over Logic** | Agent generates `SOURCE: User, STATE: Prompt, FLOW: Response` for every single turn. | Think naturally in Chain-of-Thought without mentioning SOL unless safety triggers are met. |
| **Ceremonial Gatekeeping** | Refusing to answer simple questions until the user provides a formal SOL specification. | Directly answer the user's question in plain language. |
| **Premature Rigidity** | Forcing unstructured brainstorms and creative copy drafts into rigid $O7$ nodes. | Allow free-form creative exploration until engineering constraints are defined. |
