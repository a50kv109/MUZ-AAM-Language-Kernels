# SOL AS A DECISION SUBSTRATE

> **Status:** `ARCHITECTURAL HYPOTHESIS / ENGINEERING PATTERN`  
> **Core Proposition:** *Between understanding a task and calling a tool, a structural state-check prevents blind mutations and unconstrained actions.*

---

## 1. The Architectural Architecture: Where SOL Lives

```
                     ┌───────────────────────────┐
                     │     INCOMING TASK / REQ   │
                     └─────────────┬─────────────┘
                                   │
                                   ▼
                     ┌───────────────────────────┐
                     │    LLM REASONING (CoT)    │
                     │  "I should edit the file" │
                     └─────────────┬─────────────┘
                                   │
                                   ▼
 ╔═══════════════════════════════════════════════════════════════╗
 ║                SOL DECISION LAYER (PRE-ACTION)                ║
 ║                                                               ║
 ║  • Target State Verification: Is STATE known or unknown?      ║
 ║  • Invariant Check: Does action violate any CONSTRAINT?       ║
 ║  • Concurrency Check: Are there active in-flight FLOWs?       ║
 ║  • Entropy Audit: Is DISSIPATE authorized and logged?         ║
 ║  • Authority Match: Does CAPABILITY dominate the operation?   ║
 ╚═══════════════════════════════════════════════════════════════╝
                                   │
                                   ▼
                     ┌───────────────────────────┐
                     │   DECISION GATE PASS/FAIL │
                     └─────────────┬─────────────┘
                                   │
                 ┌─────────────────┴─────────────────┐
                 ▼ (Pass)                            ▼ (Fail / Unknown)
   ┌───────────────────────────┐       ┌───────────────────────────┐
   │     MUTATING TOOL CALL    │       │     INSPECTION TOOL CALL  │
   │  edit_file, delete_file   │       │   view_file, list_dir     │
   └───────────────────────────┘       └───────────────────────────┘
```

---

## 2. Why Action Tools Need a Decision Substrate

Modern agents have access to powerful tools:
* `edit_file`, `create_file`, `delete_file`
* `run_command` (shell execution)
* Database mutations (`DROP`, `ALTER`, `UPDATE`)
* API calls (payment gateways, deployments)

**The Vulnerability:**  
LLMs naturally suffer from **Action Bias** — they want to immediately output the final answer or write the file. If an agent calls a mutating tool while its internal model of the target state is speculative, it causes irreversible collateral damage.

---

## 3. The 10 High-Risk Scenarios for Decision Layer Activation

1. **File Modification / Refactoring:** Checking for external references and exports before renaming or rewriting functions.
2. **Deletions (`delete_file`, `DROP TABLE`):** Verifying that incoming flows and foreign keys are zero before dissipating state.
3. **Database Schema Migrations:** Distinguishing between column alterations and table re-creations to prevent silent data drop.
4. **Deployments & Infrastructure:** Checking resource constraints (RAM, CPU, port availability) before executing startup scripts.
5. **API Calls with Financial or Operational Impact:** Validating idempotency keys to prevent duplicate transactions during retries.
6. **Multi-Source Conflicts:** Auditing authority when user requirements conflict with system security protocols.
7. **Asynchronous / Parallel Pipelines:** Checking for in-flight locks before reading or writing shared buffers.
8. **Git Merge Conflicts:** Modeling base state, branch A, branch B, and the resolution invariant before staging files.
9. **Dependency Management:** Auditing package conflicts and peer constraints before running installs.
10. **Multi-Agent Handoff:** Transferring verified state graphs rather than rhetorical summaries.

---

## 4. Epistemic Status

* **Status:** `[ARCHITECTURAL HYPOTHESIS]`
* **Open Empirical Question:** Does introducing an explicit pre-action SOL checkpoint statistically reduce tool-call rollbacks and breaking changes without causing excessive latency overhead? *(See `docs/EXPERIMENTS/ACTION_GATE.md` for the test protocol).*
