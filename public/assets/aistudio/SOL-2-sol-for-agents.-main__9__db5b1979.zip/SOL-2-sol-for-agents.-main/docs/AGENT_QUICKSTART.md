# SOL AGENT QUICKSTART (10-SECOND REASONING PROTOCOL)

> **Status:** `OPERATIONAL SPECIFICATION v1.0`  
> **Audience:** Autonomous AI Agents encountering SOL for the first time.  
> **Mission:** Transform ambiguous user prompts into verifiable structural invariants before tool execution.

---

## 1. THE 7 DIAGNOSTIC QUESTIONS (O7 EXTRACTION)

When reading any engineering task (regardless of whether it is written in English, Russian, Chinese, French, German, Arabic, or Hindi), ask these 7 functional questions:

| # | Diagnostic Topological Question | O7 Primitive | If YES $\rightarrow$ What to Record | False Equivalent / Hazard |
| :-: | :--- | :---: | :--- | :--- |
| **1** | *Where does the causal sequence originate?* | **`SOURCE`** | The root immutable origin entity. | Conflating root genesis with intermediate cache or mere causality. |
| **2** | *What is the discrete settled snapshot at $t_0$?* | **`STATE`** | Exact current system data/node snapshot. | Confusing dynamic in-flight processing with settled data. |
| **3** | *What moves from A to B over duration $\Delta t > 0$?* | **`FLOW`** | Directed transfer vector (payload, direction). | Assuming instantaneous zero-time mutation ($\Delta t = 0$). |
| **4** | *What boundary makes the system invalid if crossed?* | **`CONSTRAINT`** | Hard non-negotiable invariant ($S \notin \text{Allowed} \implies \emptyset$). | Softening a hard limit into an advisory recommendation or `if-else`. |
| **5** | *Is an objective mathematical/logical $\Delta$ evaluated?* | **`COMPARE`** | Difference vector between two or more states. | Subjective human opinion or sentiment rating. |
| **6** | *Does data or energy permanently leave phase space?* | **`DISSIPATE`** | Irreversible sink / unrecoverable discard. | Treating passive permanent loss as a reversible soft delete. |
| **7** | *Does the actor hold the formal legal right to mutate?* | **`CAPABILITY`** | Auth token, IAM role, or execution permit. | Confusing internal CPU capacity with granted permission. |

---

## 2. THE 3-STEP PRE-ACTION GATE

Before issuing any mutating tool call (`edit_file`, `delete_file`, `run_command`, `database_write`):

```
[Raw Tool Intent]
       │
       ▼
[1. Is STATE Known?] ────────── NO ──► Block Mutating Tool ──► Emit Inspection Tool (grep / view_file)
       │ YES
       ▼
[2. Is CONSTRAINT Satisfied?] ── NO ──► Block Tool ──────────► Report Invariant Conflict to Architect
       │ YES
       ▼
[3. Is CAPABILITY Valid?] ───── NO ──► Block Tool ──────────► Request Permission / Token
       │ YES
       ▼
[EXECUTE TOOL CALL]
```

---

## 3. WHEN TO BYPASS SOL IMMEDIATELY (ZERO OVERHEAD)

Do **NOT** construct a SOL AST if the task is:
* A superficial CSS/UI color or padding adjustment.
* An informal conversational question or architectural explanation.
* A deterministic single-line syntax fix (e.g., missing semicolon or import name).
* Text translation or typographical correction.

*(See [`docs/WHEN_NOT_TO_USE_SOL.md`](./WHEN_NOT_TO_USE_SOL.md) for full exclusion rules).*

---

## 4. CONCISE WORKED EXAMPLE

**Task:** *"Delete `config.old.json` because we migrated keys to `.env`."*

```yaml
STATE:
  file: "config.old.json"
  disk_presence: true
  incoming_imports: UNKNOWN # <--- Incomplete state!

CONSTRAINT:
  rule: "Cannot DISSIPATE file if InDegree(References) > 0"

ACTION_GATE:
  check: "STATE(incoming_imports) == UNKNOWN => Lock(delete_file)"
  next_safe_action: "view_file or grep('config.old.json') to verify InDegree == 0"
```
