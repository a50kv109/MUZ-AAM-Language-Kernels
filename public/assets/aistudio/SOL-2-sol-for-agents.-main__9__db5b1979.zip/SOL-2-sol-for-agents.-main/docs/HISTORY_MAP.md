# HISTORICAL CONCEPT LINEAGE & MAP

> **Status:** `ARCHIVAL PROVENANCE & ONTOLOGICAL AUDIT`  
> **Mandate:** Strictly separate frozen canonical $O7$ primitives from historical concepts, domain experiments, and retired legacy terms.

---

## 1. Lineage Map of Historical Concepts

The table below catalogs concepts from the early iterations of SOL, explaining why they were modified, composed, or retired:

| Historical Concept | Original Purpose (Early Era) | Why it was modified / retired | What survived in Modern Canon | Current Epistemic Status |
| :--- | :--- | :--- | :--- | :--- |
| **`MISSION`** | Early intent / top-level human goal. | Teleological / subjective concept. LLMs confused user desire with physical constraints. | Absorbed into $\text{SOURCE}$ (genesis anchor) + $\text{CONSTRAINT}$ (target boundary). | `[ARCHIVAL / SUPERSEDED]` |
| **`INTENT`** | Desired target state or plan. | Mixed the *decision to act* with the *structural state*. Led to ungrounded reasoning. | Decomposed into $\text{STATE}(\text{Target}) + \text{COMPARE}(\Delta)$. | `[ARCHIVAL / SUPERSEDED]` |
| **`SYMPHONY`** | Multi-component orchestration & harmony. | Poetic / non-falsifiable metaphor. Lacked formal operational bounds. | Replaced by deterministic $\text{INDEX}$ topology and explicit $\text{FLOW}$ vectors. | `[ARCHIVAL / RETIRED]` |
| **`INTERACTION_CONTRACT`** | Modeling APIs, protocols, and interfaces. | Found to be completely reducible to $O7$ without semantic loss. | Survives as **Level 1 Canon Composition**: $\text{STATE} + \text{FLOW} + \text{CONSTRAINT} + \text{CAPABILITY}$. | `[ENGINEERING PATTERN (L1)]` |
| **`TRANSFORM`** | Modeling data mutation & compilation. | Found to be a composite of two states connected by a flow with single source. | Survives as **Level 1 Canon Composition**: $\text{STATE}_A \xrightarrow{\text{FLOW}} \text{STATE}_B$. | `[ENGINEERING PATTERN (L1)]` |
| **`EVIDENCE`** | Proof of legitimacy, crypto signatures. | Reducible to state fact + comparison with constraint. | Survives as **Level 1 Canon Composition**: $\text{STATE} + \text{COMPARE}(\text{CONSTRAINT})$. | `[ENGINEERING PATTERN (L1)]` |
| **`VISUAL_PRIMITIVES`** | Direct rendering shapes (BOX, WIRE). | Mixed computational ontology with frontend UI widgets. | Moved to dedicated UI rendering extensions. | `[ARCHIVAL / EXTENSION]` |
| **`DICTIONARY_L1`** | Early monolithic dictionary of 100+ terms. | Caused primitive explosion and lexical matching errors. | Replaced by strictly frozen $O7$ + open Compositional Algebra. | `[SUPERSEDED BY O7]` |

---

## 2. The Modern Ontological Boundary

```
  ┌─────────────────────────────────────────────────────────────┐
  │                    MODERN CANON (FROZEN)                    │
  │   SOURCE • STATE • FLOW • CONSTRAINT • COMPARE • DISSIPATE  │
  │             + CAPABILITY • INDEX • COORDINATE_SPACE         │
  └──────────────────────────────┬──────────────────────────────┘
                                 │
                                 ▼ (Generates via Algebra)
  ┌─────────────────────────────────────────────────────────────┐
  │                 CANONICAL L1 COMPOSITIONS                   │
  │     TRANSFORM • EVIDENCE • SŪTRA/RULE • CONTRACT • CACHE    │
  └──────────────────────────────┬──────────────────────────────┘
                                 │
                                 ▼ (Distinct from)
  ┌─────────────────────────────────────────────────────────────┐
  │                    ARCHIVAL & RETIRED                       │
  │     MISSION • INTENT • SYMPHONY • DICTIONARY_L1 • QUALIFIERS │
  └─────────────────────────────────────────────────────────────┘
```
