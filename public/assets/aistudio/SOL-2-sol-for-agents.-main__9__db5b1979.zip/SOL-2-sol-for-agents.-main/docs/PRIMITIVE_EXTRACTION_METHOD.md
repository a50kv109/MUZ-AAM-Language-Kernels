# PRIMITIVE EXTRACTION METHODOLOGY

> **Status:** `CURRENT METHODOLOGY / EXTRACTION PROTOCOL`  
> **Core Principle:** Functional Topography over Lexical Matching.

---

## 1. The Fundamental Rule of Extraction

> ❌ **NEVER ASK:** *"Which SOL primitive matches this word?"*  
> (This causes forced fitting, where every noun is labeled `STATE` and every verb is labeled `FLOW`).
>
> ✅ **ALWAYS ASK:** *"What structural role does this entity play in the system's operational topology?"*

---

## 2. The Extraction Pipeline

```
┌─────────────────────────────────────────────────────────────┐
│ 1. RAW OBSERVATION                                          │
│ "Under load, the queue drops messages without logging."     │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. ASPECT & FUNCTION IDENTIFICATION                         │
│ • Aspect 1: Arrival of data from network.                   │
│ • Aspect 2: Buffer capacity limit of 1000 items.            │
│ • Aspect 3: Silent disappearance of items exceeding limit.  │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. RELATIONAL TOPOLOGY MAPPING                              │
│ Incoming Transfer ──► [Buffer Node] ──(exceeds Limit)──► [Disappearance]
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. CANONICAL O7 PROJECTION                                  │
│ • Aspect 1 ⟹ FLOW (Vector of transfer)                     │
│ • Aspect 2 ⟹ CONSTRAINT (Absolute capacity boundary)       │
│ • Aspect 3 ⟹ DISSIPATE (Unrecoverable entropy sink)         │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. REDUCTION & COMPOSITION CHECK                            │
│ Is "Queue" a primitive? No: Queue = STATE(Buffer) + FLOW.   │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. SEMANTIC LOSS TEST & RESIDUE                             │
│ Did we lose the FIFO ordering rule? Yes!                     │
│ ⟹ Add Semantic Residue: { ordering: "FIFO", drop: "tail" } │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Diagnostic Question Matrix

Use these 7 diagnostic questions to cleanly distinguish primitives when ambiguous natural language is encountered:

| Entity to Diagnose | Diagnostic Question | True Primitive | Anti-Fit Trap to Avoid |
| :--- | :--- | :---: | :--- |
| **Origin / Invariant Root** | *Does this entity define the genesis or authority of the system that remains unchanged across all mutations?* | **`SOURCE`** | Do not confuse a passive stored record (`STATE`) with its genesis origin (`SOURCE`). |
| **Fixed Observable Node** | *Is this a settled, discrete snapshot of parameters at a specific point in time or memory?* | **`STATE`** | Do not confuse a file's location (`COORDINATE_SPACE`) with the file's snapshot (`STATE`). |
| **Transitional Vector** | *Is this a directional movement or transfer process requiring non-zero duration $\Delta t$?* | **`FLOW`** | Do not confuse the mutation of an object's type with the vector of transfer. |
| **Inviolable Boundary** | *Does this element reduce the allowed degrees of freedom, invalidating any state that crosses it?* | **`CONSTRAINT`** | Do not confuse a soft heuristic or conditional if-branch with an absolute boundary. |
| **Difference Operator** | *Is this an active evaluation of the delta between two states or between a state and a boundary?* | **`COMPARE`** | Do not confuse the resulting decision with the comparison operator itself. |
| **Entropy / Loss Channel** | *Is this an unrecoverable discard, absorption of noise, or silent release of state?* | **`DISSIPATE`** | Do not confuse normal completion of a flow with unrecoverable loss. |
| **Executive Right** | *Is this a formal operational contract permitting an agent or component to initiate state mutation?* | **`CAPABILITY`** | Do not confuse having the authority to act with the physical execution of the action. |

---

## 4. Anti-Fitting Tests (Self-Correction Protocol)

Before committing to a primitive mapping, run these 3 negative tests:

1. **The Inversion Test:** If you remove this primitive from the model, does the system lose a physical constraint, or just a descriptive label? (If only a label, it is not a core primitive).
2. **The Composition Test:** Can this entity be mathematically formed by combining two other primitives? (e.g. `AUTHENTICATION = COMPARE(Credentials, Stored_State)` ⟹ Map to `COMPARE`, not a new primitive `AUTH`).
3. **The State vs Action Test:** Are you modeling *what the object is right now* ($\text{STATE}$) or *what you plan to do to it* ($\text{ACTION}$)? Never map an unexecuted action as a state.
