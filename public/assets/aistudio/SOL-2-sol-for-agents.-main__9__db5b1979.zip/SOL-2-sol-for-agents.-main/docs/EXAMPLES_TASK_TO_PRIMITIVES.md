# ENGINEERING CASE STUDIES: TASK TO PRIMITIVES

> **Status:** `CURRENT METHODOLOGY / WORKED EXAMPLES`  
> **Scope:** 5 complete, real-world engineering tasks analyzed through the 10-step SOL extraction pipeline.

---

## Example 1: Refactoring a Shared File (File Mutation)

### 1. Original Task
> *"Move the `calculateTax` function from `src/utils.ts` to a new `src/tax.ts` file, and update all call sites."*

### 2. Neutral Observation
* File `src/utils.ts` contains `calculateTax` and other helpers.
* Multiple components import `calculateTax` from `src/utils.ts`.
* File `src/tax.ts` does not yet exist.

### 3. Aspect Identification & Topology
* Origin: Developer request ($\text{SOURCE}$).
* Target Location: Path `src/tax.ts` ($\text{COORDINATE\_SPACE}$).
* Call Sites: Inbound references ($\text{INDEX}$).

### 4. Canonical $O7$ Mapping
* $\text{STATE}(\text{utils.ts})$ has export `calculateTax`.
* $\text{FLOW}$: Moving logic to $\text{STATE}(\text{tax.ts})$.
* $\text{CONSTRAINT}$: All importing files must continue to resolve exports without compilation errors.
* $\text{COMPARE}$: Diff between old imports and new imports.

### 5. Primitive Creation Check
* *Did we create a new primitive `REFACTOR`?*  
  **NO.** Refactor is a composite: $\text{STATE}_A \xrightarrow{\text{FLOW}} \text{STATE}_B + \text{COMPARE}(\text{Dependencies})$.

### 6. Semantic Loss Test & Residue
* *Did we lose anything?* Tree-shaking behavior remains identical. No critical loss.
* *Residue:* Retain specific TypeScript export types (`export type TaxResult`).

### 7. Pre-Action Invariant Check & Decision
* Target `src/tax.ts` is $\text{UNKNOWN}$ on disk $\implies$ Check if file already exists before writing.
* Plan: 1. `list_dir` / check `src/tax.ts`. 2. Create `src/tax.ts`. 3. Update call sites. 4. Remove from `src/utils.ts`.

---

## Example 2: Resolving a Git Merge Conflict

### 1. Original Task
> *"Branch `feature-login` and `main` have a conflict in `routes.ts` around route `/auth`."*

### 2. Neutral Observation & Topology
* 3 States: $\text{STATE}_{\text{Base}}$ (common ancestor), $\text{STATE}_{\text{Main}}$ (added rate limit), $\text{STATE}_{\text{Feature}}$ (added OAuth endpoint).

### 3. $O7$ Mapping
* $\text{COMPARE}(\text{STATE}_{\text{Main}}, \text{STATE}_{\text{Base}}) \implies \Delta_1$ (Rate Limiting $\text{CONSTRAINT}$).
* $\text{COMPARE}(\text{STATE}_{\text{Feature}}, \text{STATE}_{\text{Base}}) \implies \Delta_2$ (OAuth $\text{FLOW}$).
* $\text{CONSTRAINT}$: Both the rate limit boundary and the OAuth endpoint must be preserved in the merged state.

### 4. Decision & Action
* Merge state: $\text{STATE}_{\text{Merged}} = \text{STATE}_{\text{Base}} + \Delta_1 + \Delta_2$.
* Edit `routes.ts` preserving both invariants.

---

## Example 3: Dead-Letter Queue / Exception Routing

### 1. Original Task
> *"If an incoming message fails schema validation 3 times, route it to `dead_letters` topic so the consumer doesn't crash."*

### 2. $O7$ Mapping
* Incoming message: $\text{FLOW}_{\text{in}}$.
* Schema validator: $\text{COMPARE}(\text{Payload}, \text{CONSTRAINT}_{\text{Schema}})$.
* Failure Counter: $\text{STATE}(\text{RetryCount})$.
* Invariant: If $\text{STATE}(\text{RetryCount}) \ge 3 \implies \text{FLOW}_{\text{reroute}} \rightarrow \text{STATE}(\text{DLQ})$.
* Main queue: Discards failed item to prevent blockage ($\text{DISSIPATE}$).

### 3. Primitive Creation Check
* *Why NOT create a `DLQ` primitive?*  
  Because $\text{DLQ} \equiv \text{STATE}(\text{Buffer}) + \text{COMPARE}(\text{Threshold}) + \text{FLOW}(\text{Reroute})$.

---

## Example 4: Architectural Reduction (Evaluating Redis)

### 1. Original Task
> *"We need to add Redis to our stack to prevent duplicate webhook processing from Stripe."*

### 2. Aspect Identification & Reduction
* Target Requirement: Ensure webhook event $E$ is processed at most once (Idempotency).
* Proposed Addition: Dedicated Redis cluster.
* Existing Topology: PostgreSQL database with table `webhook_events (event_id PRIMARY KEY, status, created_at)`.

### 3. $O7$ Comparison & Decision
* Proposed: $\text{FLOW} \rightarrow \text{REDIS}(\text{SETNX}) \rightarrow \text{DB}$.
* Existing: $\text{FLOW} \rightarrow \text{INSERT INTO webhook\_events ON CONFLICT (event_id) DO NOTHING}$.
* Reduction Proof: The PostgreSQL `ON CONFLICT` clause already implements the exact same $\text{COMPARE}(\text{PrimaryKey}, \text{STATE}) \implies \text{DISSIPATE}$ invariant.
* **Decision:** Reject adding Redis. Use native PostgreSQL primary key constraints. Avoid architectural sprawl.

---

## Example 5: Cross-Language Specification Discrepancy

### 1. Original Task
* Document A (French): *"La charge utile ne doit en aucun cas excéder 10 Mo lors du transfert."*
* Document B (Chinese): *"传输期间载荷推荐限制在10MB以下，峰值可允许至15MB。"*

### 2. SOL AST Extraction
* **Doc A (FR):** $\text{CONSTRAINT}(\text{PayloadSize} \le 10\text{MB})$ [Hard Absolute Boundary, non-negotiable].
* **Doc B (ZH):** $\text{CONSTRAINT}_{\text{Soft}}(\text{PayloadSize} \le 10\text{MB}) \wedge \text{CONSTRAINT}_{\text{Hard}}(\text{PayloadSize} \le 15\text{MB})$.

### 3. Automated Comparison
* $\text{COMPARE}(\text{AST}_{\text{FR}}, \text{AST}_{\text{ZH}}) \implies \Delta(\text{MaxBurstCapacity}) = 5\text{MB}$ discrepancy detected.
* **Outcome:** The agent identifies the fatal specification mismatch *before* writing any code, preventing downstream production out-of-memory errors.
