# SOL AGENT EXECUTION GUIDE

> **Status:** `CURRENT METHODOLOGY / STEP-BY-STEP HANDBOOK`  
> **Target:** Autonomous AI Agents executing engineering tasks.

---

## 1. The Core 10-Step Workflow

When you receive a new engineering task, follow this exact deterministic sequence:

```
[0. Understand Task] ──► [1. SOL Needed?] ──► [2. Extract Elements] ──► [3. Map Relations]
                               │ No                  │
                               ▼                     ▼
                       [Skip to Direct Action]  [4. O7 Mapping] ──► [5. Check New Primitives]
                                                                            │
                                                                            ▼
[10. Execute Tool] ◄── [9. Form Decision] ◄── [8. Audit Constraints] ◄── [6. Loss Test & Residue]
```

---

### Step 0: Understand the Task in Natural Language
* **What to do:** Read the prompt, requirements, and existing context using your standard language comprehension.
* **Goal:** Form an initial mental model of what the user wants to achieve.

---

### Step 1: Determine If SOL Is Needed (Fast Bypass)
* **What to do:** Ask: *"Does this task involve state mutations, file deletions, concurrency, multiple conflicting sources, or architectural changes?"*
  * **NO:** (e.g. trivial text explanation, typo fix, simple math) $\rightarrow$ **Skip SOL entirely.** Answer directly.
  * **YES:** Proceed to Step 2.
* **Failure Mode:** Forcing SOL analysis onto 1-line syntax fixes, wasting latency and tokens.

---

### Step 2: Extract Observable Elements (Neutral Observation)
* **What to do:** List the concrete facts, files, parameters, and entities without using SOL terminology yet.
* **Example:** *"File `src/utils.ts` exists. The function `formatDate` is requested. User mentioned path `dateUtils.ts`."*
* **Failure Mode:** Aspect Leakage — using terms like "This is a FLOW" before identifying what is actually flowing.

---

### Step 3: Determine Structural Relations
* **What to do:** Identify how elements interact: What produces what? What limits what? What depends on what?
* **Example:** *"Components import helpers from `src/utils.ts`. The new function performs string formatting."*

---

### Step 4: Map to Canonical $O7$ Primitives
* **What to do:** Project the relations onto the 7 core primitives:
  * $\text{SOURCE}$: Where did the data/request originate?
  * $\text{STATE}$: What is the current snapshot?
  * $\text{FLOW}$: What vector/process is moving?
  * $\text{CONSTRAINT}$: What cannot be violated?
  * $\text{COMPARE}$: What is being diffed or verified?
  * $\text{DISSIPATE}$: Is anything being discarded or destroyed?
  * $\text{CAPABILITY}$: Does the component/agent have authority to act?

---

### Step 5: Prohibition on Unnecessary New Primitives
* **What to do:** If a domain concept appears (e.g., `CACHE`, `TRANSACTION`, `AUTH_TOKEN`), **do not create a new primitive**. Express it as a composition of existing $O7$ primitives:
  * $\text{CACHE} = \text{STATE}(\text{Ephemeral}) + \text{COMPARE}(\text{TTL}) + \text{DISSIPATE}(\text{Eviction})$.
* **Rule:** Expand expressiveness through compositions, never by mutating the core $O7$.

---

### Step 6: Execute the Semantic Loss Test
* **What to do:** Ask: *"When I reduced this domain concept to $O7$, did I lose any critical operational rule or edge-case behavior?"*
  * If critical detail was lost $\rightarrow$ Move to Step 7.
  * If no critical detail was lost $\rightarrow$ Proceed to Step 8.

---

### Step 7: Document Semantic Residue
* **What to do:** Capture domain-specific nuances that cannot be reduced to pure topology in an explicit `Semantic Residue` metadata field.
* **Example:** *"Residue: Token format is specifically JWT RS256 with specific claim `exp`."*

---

### Step 8: Audit Invariants and State Status
* **What to do:** Run the pre-action safety check:
  1. Is the target state $\text{STATE} = \text{KNOWN}$ or $\text{UNKNOWN}$?
  2. If $\text{STATE} = \text{UNKNOWN}$ $\rightarrow$ **Block write actions; force read action.**
  3. Does the planned action violate any $\text{CONSTRAINT}$?
  4. Is there an in-flight $\text{FLOW}$ that could cause a race condition?

---

### Step 9: Formulate the Decision
* **What to do:** Construct the single optimal, invariant-preserving plan.
* **Example:** *"Integrate `formatDate` directly into `src/utils.ts` to preserve single-point-of-export constraint."*

---

### Step 10: Execute Action Tool & Verify
* **What to do:** Call the precise action tool (`edit_file`, `view_file`, `run_command`).
* **Post-Action:** Observe the new resulting state and verify against the expected $\text{STATE}$.

---

## 2. Summary Checklist

```yaml
PRE_ACTION_CHECKLIST:
  1_task_understood: true
  2_sol_applicable: true
  3_state_status: "KNOWN" # If UNKNOWN -> Switch tool to INSPECT!
  4_intended_op: "MUTATE_STATE | DISSIPATE | INSPECT"
  5_constraints_held: true
  6_action_tool_selected: "edit_file"
```
