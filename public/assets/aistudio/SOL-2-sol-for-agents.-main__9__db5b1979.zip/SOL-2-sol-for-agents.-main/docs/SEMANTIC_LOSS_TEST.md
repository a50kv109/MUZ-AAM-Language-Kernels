# THE SEMANTIC LOSS TEST & RESIDUE PROTOCOL

> **Status:** `CURRENT METHODOLOGY / VERIFICATION PROTOCOL`  
> **Core Purpose:** Protecting against oversimplification and loss of critical domain rules during abstraction.

---

## 1. Why the Loss Test is Mandatory

When an AI agent projects a rich real-world engineering problem onto a minimal primitive system like $O7$, there is a grave danger of **Oversimplification (Procrustean Fitting)**:
* Dropping business-critical edge-case rules.
* Ignoring non-functional guarantees (e.g. strict ordering, endianness, cryptographic salt).
* Losing domain-specific semantics under the illusion of a clean diagram.

The **Semantic Loss Test** is the mandatory gatekeeper that ensures abstraction does not cause operational blindness.

---

## 2. The 4-Step Loss Test Protocol

```
┌─────────────────────────────────────────────────────────────┐
│ 1. FORMALIZE PROJECTION                                     │
│ Map domain concept D to canonical O7 composition C.         │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. BIDIRECTIONAL RECONSTRUCTION                             │
│ Attempt to reconstruct the original domain requirements     │
│ purely from C. What cannot be reconstructed?                │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. LOSS EVALUATION                                          │
│ Is the missing information:                                 │
│ • [Trivial Rhetoric] ⟹ Acceptable loss.                     │
│ • [Operational Invariant] ⟹ UNACCEPTABLE LOSS.             │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. RESIDUE CAPTURE                                          │
│ If loss contains operational invariants, preserve them in   │
│ explicit structured SEMANTIC RESIDUE metadata.              │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Real Example: Projecting a "JWT Refresh Token"

### Step 1: $O7$ Composition
* $\text{STATE}(\text{TokenString})$ + $\text{COMPARE}(\text{ExpirationTime}, \text{CurrentTime}) \rightarrow \text{CAPABILITY}(\text{Access})$.

### Step 2: Bidirectional Reconstruction
* Can we reconstruct a working JWT system from just the above?
  * *Missing:* Cryptographic signature algorithm (`RS256`), Key ID (`kid`), Token family rotation rule on replay.

### Step 3: Loss Evaluation
* The signature algorithm and token rotation rules are **critical security invariants**, not rhetorical decoration. Dropping them would cause vulnerability.

### Step 4: Semantic Residue Capture
```json
{
  "sol_mapping": "STATE(Token) + COMPARE(Exp) -> CAPABILITY",
  "semantic_loss_detected": true,
  "semantic_residue": {
    "crypto_algorithm": "RS256",
    "rotation_strategy": "single_use_family_invalidation",
    "storage_boundary": "httpOnly_secure_cookie"
  }
}
```

---

## 4. The 3 Loss Categories

1. **Category 0 (Zero Loss):** The $O7$ composition fully and losslessly expresses all behaviors (e.g., a simple memory FIFO buffer).
2. **Category 1 (Bounded Residue):** The $O7$ composition captures all causal/topological vectors, while domain-specific parameters reside cleanly in `Semantic Residue` (e.g., specific regex patterns, HTTP status codes).
3. **Category 2 (Fatal Semantic Rupture):** The $O7$ composition fundamentally misrepresents the physical/logical nature of the system. *Remedy:* Reject the mapping; re-evaluate aspects and relations.
