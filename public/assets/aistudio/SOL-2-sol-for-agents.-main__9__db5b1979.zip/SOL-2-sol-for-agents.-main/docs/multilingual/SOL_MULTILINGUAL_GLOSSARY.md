# MULTILINGUAL SOL GLOSSARY (CANONICAL O7 REFERENCE)

> **Status:** `EXPERIMENTAL REFERENCE / MULTILINGUAL ATLAS v1.0`  
> **Epistemic Class:** `[EMPIRICALLY GROUNDED / CROSS-LANGUAGE MATRIX]`  
> **Core Principle:** A SOL primitive is **never** defined by a natural-language lexical translation. A SOL primitive represents a language-independent structural invariant.

---

## 1. CROSS-LANGUAGE STRUCTURAL EQUIVALENCE TABLE

| Primitive | Structural Function | RU | EN | FR | DE | ZH | AR | HI | Dangerous Ambiguity / Hazard | Typical Mistranslation | What MUST Remain Invariant |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`SOURCE`** | Root genesis anchor & origin of causal flow | Источник / Исток | Source / Genesis origin | Source / Origine racine | Quelle / Ursprungspunkt | 源 (yuán) / 源头 | مصدر (maṣdar) | स्रोत (srot) / उद्गम | Conflating root genesis with intermediate cache or mere causality (Cause vs Origin). | Translating as "причина", "reason", "历史背景", "سبب". | The immutable root reference anchor that survives downstream representations. |
| **`STATE`** | Discrete settled configuration at snapshot $t_0$ | Состояние / Фиксированный срез | Settled state / Discrete snapshot | État / Instantané fixé | Zustand / Fester Zustand | 状态 (zhuàngtài) / 稳态 | حالة (ḥāla) / وضع | स्थिति (sthiti) / अवस्था | Confusing in-flight processing or dynamic processes with a settled snapshot. | Translating as "процесс", "action", "情况" (circumstance), "موقف". | Represents settled reality at $t_0$; transitions require $\text{FLOW}$ or $\text{DISSIPATE}$. |
| **`FLOW`** | Directed transfer of state over duration $\Delta t > 0$ | Направленный поток / Перенос | Directed flow / Vector of transfer | Flux directionnel / Transfert | Fluss / Gerichteter Strom | 流转 (liúzhuǎn) / 定向流 | تدفق موجه (tadafuq) | प्रवाह (pravāha) / संचरण | Omitting duration ($\Delta t=0$), turning flow into instantaneous magic mutation. | Translating as "действие", "movement", "流动" (random motion), "движение". | Must have direction, finite transfer time ($\Delta t > 0$), and clear endpoints. |
| **`CONSTRAINT`** | Non-negotiable boundary defining allowed phase space | Жесткое ограничение / Граница | Invariant boundary / Non-negotiable limit | Contrainte stricte / Limite invariante | Randbedingung / Harte Grenze | 约束 (yuēshù) / 硬边界 | قيد صارم (qayd) / حد حتمي | बंधन (bandhan) / अनिवार्य सीमा | Softening a hard invariant into an advisory guideline, style rule, or if-else hint. | Translating as "рекомендация", "условие" (soft condition), "建议", "شرط". | Total exclusion of invalid states ($\text{State} \notin \text{Allowed} \implies \emptyset$). |
| **`COMPARE`** | Active delta evaluation between 2+ topological entities | Сопоставление / Вычисление $\Delta$ | Delta evaluation / Active comparison | Évaluation d'écart / Comparaison | Abgleich / Differenzprüfung | 比对 (bǐduì) / 差异计算 | مقارنة بنيوية / تقييم الفارق | तुलना (tulanā) / भेद विश्लेषण | Adding subjective appraisal, qualitative rating, or confusing delta with post-action. | Translating as "оценка" (opinion), "judgment", "评价", "تقدير". | Mathematical/logical evaluation generating an objective difference vector ($\Delta$). |
| **`DISSIPATE`** | Irreversible entropy sink or unrecoverable discard | Необратимый сброс / Диссипация | Irreversible sink / Silent discard | Puits d'entropie / Dissipation irréversible | Dissipation / Unwiderruflicher Verlust | 耗散 (hàosàn) / 丢弃汇 | تبدد حتمي (tabaddud) / تسريب | विसर्जन (visarjan) / क्षय | Confusing passive unrecoverable loss with an active reversible file operation (Delete vs Dissipate). | Translating as "удаление" (reversible delete), "trash", "删除", "حذف". | Irreversibility: data/energy permanently exits system phase space. |
| **`CAPABILITY`** | Executive right / authorization to mutate state | Авторизованное право / Полномочие | Executive right / Formal authority | Droit d'exécution / Habilitation | Ausführungsrecht / Befugnis | 执行权 (zhíxíngquán) / 权能 | صلاحية تنفيذية / إذن | सामर्थ्य (sāmarthya) / प्राधिकार | Confusing internal functional capacity with granted operational permission. | Translating as "умение", "skill", "能力" (raw ability), "قدرة". | Formal operational contract/token conferring legal right to trigger a state transition. |

---

## 2. DETAILED LINGUISTIC DRIFT HAZARDS & ANTI-DEFINITIONS

### 2.1 Russian (RU)
* **`DISSIPATE` vs "Удаление":** In software, "удаление" often means moving a file to a trash bin or soft deletion (recoverable). `DISSIPATE` in SOL represents thermodynamic irreversibility or silent packet loss.
* **`CONSTRAINT` vs "Условие":** "Условие" (condition) is frequently interpreted by LLMs as a branch trigger (`if-else`). `CONSTRAINT` is a non-negotiable invariant boundary.
* **`CAPABILITY` vs "Способность":** "Способность" implies personal skill. `CAPABILITY` in SOL is an authorization token or executive right.

### 2.2 Chinese (ZH)
* **`DISSIPATE`:** Using **耗散 (hàosàn)** preserves thermodynamic irreversibility (the character 耗 denotes consumption/loss). Using **删除 (shānchú)** or **丢弃 (diūqì)** improperly reduces it to an everyday file action.
* **`CONSTRAINT`:** Using **约束 (yuēshù)** conveys binding topology. Using **建议 (jiànyì)** or **条件 (tiáojiàn)** weakens the hard structural boundary.
* **`FLOW`:** Using **流转 (liúzhuǎn)** captures transfer + state progression, whereas **流动 (liúdòng)** merely denotes physical movement.

### 2.3 German (DE)
* **`CONSTRAINT`:** **Randbedingung** or **Einschränkung** correctly captures boundary limits, whereas **Bedingung** can be a soft prerequisite.
* **`COMPARE`:** **Abgleich** captures structural schema alignment far better than general **Vergleich**.

### 2.4 Arabic (AR)
* **`CONSTRAINT`:** **قيد (qayd)** (binding/shackle) is structurally accurate. **شرط (sharṭ)** risks being interpreted as an optional conditional prerequisite.
* **`SOURCE`:** **مصدر (maṣdar)** (root exit point) is topologically exact and distinguishes origin from causal intent.

### 2.5 Hindi (HI)
* **`DISSIPATE`:** **विसर्जन (visarjan)** or **क्षय (kṣaya)** accurately conveys dissolution and irreversible release back to the environment.
* **`CONSTRAINT`:** **बंधन (bandhan)** or **प्रतिबंध (pratibandh)** correctly conveys binding constraints.

---

## 3. AGENT OPERATIONAL DIRECTIVE

When ingesting technical requirements in ANY language:
1. **Never match keywords lexically.**
2. **Diagnose topological function:** Does the entity store state, move information over time, limit allowable states, compute differences, discard information irreversibly, or grant mutation authority?
3. **Map directly to $O7$ canonical identifiers** regardless of source natural language.
