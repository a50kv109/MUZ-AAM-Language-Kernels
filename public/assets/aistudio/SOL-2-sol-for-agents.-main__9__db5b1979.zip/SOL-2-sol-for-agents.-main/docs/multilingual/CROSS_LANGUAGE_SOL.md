# CROSS-LANGUAGE SOL (METHODOLOGY FOR AI AGENTS)

> **Status:** `OPERATIONAL SPECIFICATION v1.0`  
> **Epistemic Class:** `[ENGINEERING METHODOLOGY / MULTILINGUAL TRANSFER]`  
> **Audience:** Autonomous AI Agents processing multi-source, multilingual technical documentation.

---

## 1. THE CORE PROBLEM: MULTILINGUAL DRIFT

When an engineering system is specified across multiple languages (e.g., French aerospace contract + Chinese hardware manual + Russian legacy backend documentation), LLMs suffer from three severe cognitive failures:

```
[Natural Language Ingestion] ──────────► [Translation Drift] ──────────► [Blind Hallucinated Patch]
                                                │
                                                ▼
                                    Softened Constraints /
                                    Lost Invariants / Missed Diffs
```

1. **Loss of Invariant Rigor:** In Russian or Chinese, words like *"условие"* or *"条件"* turn hard invariants into soft recommendations.
2. **Action/State Conflation:** Operational verbs in natural language obscure in-flight time ($\Delta t > 0$) and unverified state snapshots.
3. **False Equivalence:** Translating foreign text directly to English introduces synonym bias before structural analysis even begins.

---

## 2. STRUCTURAL INVARIANCE: DEFINITION & FALSIFICATION

### 2.1 Formal Definition
$$\text{STRUCTURAL INVARIANCE} \iff \forall \mathcal{L}_i, \mathcal{L}_j \in \text{NaturalLanguages}, \quad \text{Extract}_{O7}(\mathcal{T}_{\mathcal{L}_i}) \cong \text{Extract}_{O7}(\mathcal{T}_{\mathcal{L}_j})$$

An engineering specification exhibits **Structural Invariance** under SOL if and only if decomposing the specification from any natural language $\mathcal{L}_i$ produces an **isomorphic topological graph** of $O7$ primitives, constraints, and causal vectors.

### 2.2 Falsification Criteria `[HYPOTHESIS]`
The hypothesis that *“SOL preserves cross-language structural invariance”* is falsified if:
* Identical engineering requirements in two languages produce distinct graph topologies (e.g., one requires a `DISSIPATE` sink while another yields a closed conservative loop) when evaluated under the standard extraction pipeline.
* Inter-agent topological graph isomorphism drops below $85\%$ across independent multilingual test suites.

---

## 3. THE 10-STEP MULTILINGUAL EXTRACTION ALGORITHM

When an AI agent receives technical text in French, Chinese, German, Russian, Arabic, or Hindi:

```
[Raw Multilingual Text]
         │
         ▼
[Step 1: Read Native Text Directly (Do NOT auto-translate to English prose)]
         │
         ▼
[Step 2: Isolate Settled Physical/Data Nodes] ────────► Identify STATE (t_0)
         │
         ▼
[Step 3: Isolate Causal Vectors over Time] ──────────► Identify FLOW (Δt > 0)
         │
         ▼
[Step 4: Extract Non-Negotiable Boundaries] ─────────► Identify CONSTRAINT (Hard Bounds)
         │
         ▼
[Step 5: Extract Delta & Validation Operations] ─────► Identify COMPARE (Δ Evaluation)
         │
         ▼
[Step 6: Trace Irreversible Sinks & Packet Loss] ────► Identify DISSIPATE (Entropy Sinks)
         │
         ▼
[Step 7: Trace Mutation Permissions] ───────────────► Identify CAPABILITY (Tokens/Roles)
         │
         ▼
[Step 8: Construct Language-Independent SOL AST Block]
         │
         ▼
[Step 9: Run Cross-Specification COMPARE] ───────────► Detect Incompatibilities
         │
         ▼
[Step 10: Gate Action / Tool Execution]
```

---

## 4. END-TO-END WORKED CASE STUDY: MULTILINGUAL SATELLITE VALVE SPECIFICATION

### 4.1 Input Documents
* **French Contract ($\mathcal{L}_{\text{FR}}$):**  
  *« Le contrôleur de soupape doit rejeter tout paquet de commande dont la somme de contrôle est invalide et purger définitivement la mémoire tampon sans tenter de réémission. La pression nominale ne doit jamais excéder 300 bars. »*
* **Chinese Hardware Manual ($\mathcal{L}_{\text{ZH}}$):**  
  *« 阀门控制器在检测到校验和错误时，必须丢弃该指令数据包并释放对应缓冲区。工作压力绝对不可超过 300 bar。 »*

### 4.2 Step-by-Step SOL Extraction

#### From French ($\mathcal{L}_{\text{FR}}$):
1. `SOURCE`: Command payload stream.
2. `FLOW_in`: Inbound command transmission over network bus.
3. `STATE_buffer`: Allocated memory buffer holding raw packet.
4. `COMPARE_checksum`: $\text{COMPARE}(\text{Checksum}_{\text{calc}}, \text{Checksum}_{\text{packet}})$.
5. `DISSIPATE`: If $\Delta \ne 0 \implies \text{DISSIPATE}(\text{STATE_buffer})$ (unrecoverable purge without retransmission).
6. `CONSTRAINT_pressure`: $\text{Pressure} \le 300\text{ bar}$ (Hard Invariant).

#### From Chinese ($\mathcal{L}_{\text{ZH}}$):
1. `SOURCE`: 指令数据包源 (Command packet origin).
2. `FLOW_in`: 数据总线传输 (Transmission flow).
3. `STATE_buffer`: 对应缓冲区 (Allocated buffer).
4. `COMPARE_checksum`: 校验和检测 (Checksum delta calculation).
5. `DISSIPATE`: 丢弃数据包并释放 (Dissipate packet + free memory).
6. `CONSTRAINT_pressure`: 压力 $\le 300\text{ bar}$ (Hard Invariant).

### 4.3 Topological Verification
$$\text{COMPARE}(\text{AST}_{\text{FR}}, \text{AST}_{\text{ZH}}) \implies \Delta = \emptyset \quad \text{[100\% Structural Invariance Validated]}$$

Both documents map to an identical AST topology. The agent confidently executes the engineering task without translation ambiguity.

---

## 5. EXPERIMENTAL COMPARISON: BASELINE REASONING VS SOL DECISION LAYER

| Dimension | Baseline Reasoning (NL $\rightarrow$ CoT $\rightarrow$ Action) | SOL Decision Layer (NL $\rightarrow$ SOL AST $\rightarrow$ Gated Action) |
| :--- | :--- | :--- |
| **Cross-Language Discrepancy Detection** | Misses subtle difference between hard limits (300 bar) and burst limits. | Explicitly extracts $\text{CONSTRAINT}_{\text{hard}}$ vs $\text{CONSTRAINT}_{\text{soft}}$ and evaluates $\text{COMPARE}(\text{AST}_1, \text{AST}_2)$. |
| **Handling "Delete" vs "Dissipate"** | Often emits silent `delete_file` or ignores memory buffer leaks. | Explicitly models whether data is unrecoverably purged (`DISSIPATE`) or transformed (`FLOW`). |
| **Token Overhead** | Minimal ($1.0\times$). | Moderate ($1.2\times - 1.4\times$). |
| **Safety Under Pressure** | Vulnerable to hallucinated assumptions when language phrasing varies. | Enforces invariant conservation regardless of source language phrasing. |
