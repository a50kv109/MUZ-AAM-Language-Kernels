# SOL (Semantic Operational Layer)

> **A minimal methodological substrate for AI agents to preserve, extract, verify, and transfer engineering reasoning structures across tasks, models, tools, and natural languages.**

```
                 OBSERVATION / TASK
                         │
                         ▼
        ┌───────────────────────────────────┐
        │        COGNITIVE REASONING        │
        │    (LLM understanding & context)   │
        └────────────────┬──────────────────┘
                         │
                         ▼
 ╔═════════════════════════════════════════════════╗
 ║              SOL STRUCTURAL LAYER               ║
 ║                                                 ║
 ║  • SOURCE:      Genesis anchor & authority      ║
 ║  • STATE:       Discrete observable snapshot    ║
 ║  • FLOW:        Vector of transfer & transition ║
 ║  • CONSTRAINT:  Hard boundary & invariant       ║
 ║  • COMPARE:     Delta & discrepancy operator    ║
 ║  • DISSIPATE:   Entropy sink & loss channel     ║
 ║  • CAPABILITY:  Executive right to mutate       ║
 ╚═════════════════════════════════════════════════╝
                         │
                         ▼
        ┌───────────────────────────────────┐
        │        DECISION FORMULATION       │
        │   (Invariant-preserving plan)     │
        └────────────────┬──────────────────┘
                         │
                         ▼
        ┌───────────────────────────────────┐
        │         ACTION TOOL CALL          │
        │   (write_file, CLI, API, etc.)    │
        └───────────────────────────────────┘
```

---

## What is SOL?

SOL (**Semantic Operational Layer**) is **not** a programming language, **not** an artificial language agents are forced to speak, and **not** a replacement for natural language or Chain-of-Thought reasoning.

SOL is an **open methodology and minimal structural coordinate system ($O7$)** that enables an AI agent to:
1. **Extract** structural invariants from ambiguous, natural-language requirements.
2. **Anchor** relationships before executing tool calls (preventing blind state mutations and unauthorized dissipations).
3. **Verify** that no critical constraints, in-flight states, or authority hierarchies were lost in reasoning.
4. **Transfer** precise technical models to other agents, models, or languages without rhetorical drift.

---

## 2-Minute Quick Navigation Map

| Document | Purpose | Target Question |
| :--- | :--- | :--- |
| [`docs/AGENT_QUICKSTART.md`](./docs/AGENT_QUICKSTART.md) | **10-second fast extraction & Action Gate** | *"How do I extract O7 in 10 seconds and guard my tools?"* |
| [`docs/WHY_SOL_FOR_AGENTS.md`](./docs/WHY_SOL_FOR_AGENTS.md) | Practical rationale for agents | *"Why do I need SOL if I can already reason?"* |
| [`docs/PROBLEM_SOL_SOLVES.md`](./docs/PROBLEM_SOL_SOLVES.md) | Concrete failure modes & mitigations | *"What real bugs and drifts does SOL solve?"* |
| [`docs/SOL_AGENT_GUIDE.md`](./docs/SOL_AGENT_GUIDE.md) | 10-step execution handbook | *"I got a new task. What is the exact workflow?"* |
| [`docs/PRIMITIVE_EXTRACTION_METHOD.md`](./docs/PRIMITIVE_EXTRACTION_METHOD.md) | Extraction pipeline & questions | *"How do I extract primitives from raw text?"* |
| [`docs/SOL_CORE_PRIMITIVES.md`](./docs/SOL_CORE_PRIMITIVES.md) | Modern $O7$ canonical definitions | *"What are the 7 core primitives and anti-definitions?"* |
| [`docs/PRIMITIVE_VS_COMPOSITION.md`](./docs/PRIMITIVE_VS_COMPOSITION.md) | Compositional algebra | *"Is my concept a primitive or a composite pattern?"* |
| [`docs/SEMANTIC_LOSS_TEST.md`](./docs/SEMANTIC_LOSS_TEST.md) | Loss test & residue protocol | *"Did I oversimplify or lose vital domain semantics?"* |
| [`docs/SOL_DECISION_LAYER.md`](./docs/SOL_DECISION_LAYER.md) | Architectural substrate before action | *"How does SOL sit between thinking and tools?"* |
| [`docs/WHEN_TO_USE_SOL.md`](./docs/WHEN_TO_USE_SOL.md) | Usage checklist & triggers | *"When should I activate SOL structuring?"* |
| [`docs/WHEN_NOT_TO_USE_SOL.md`](./docs/WHEN_NOT_TO_USE_SOL.md) | Exclusions & anti-bureaucracy | *"When is SOL an unnecessary overhead?"* |
| [`docs/multilingual/CROSS_LANGUAGE_SOL.md`](./docs/multilingual/CROSS_LANGUAGE_SOL.md) | Multilingual extraction methodology | *"How do I extract invariants from French, Chinese, etc.?"* |
| [`docs/multilingual/SOL_MULTILINGUAL_GLOSSARY.md`](./docs/multilingual/SOL_MULTILINGUAL_GLOSSARY.md) | Multilingual equivalence reference | *"What are the lexical hazards across languages?"* |
| [`docs/HISTORY_MAP.md`](./docs/HISTORY_MAP.md) | Lineage of retired concepts | *"Why were MISSION, INTENT, SYMPHONY retired?"* |
| [`docs/EXPERIMENTS/ROADMAP.md`](./docs/EXPERIMENTS/ROADMAP.md) | Empirical testing protocols | *"How do we scientifically verify SOL hypotheses?"* |

---

## Epistemic Integrity: How Content is Classified

Every concept in this repository is labeled with its exact epistemic status:

* `[CANON]` — The frozen 7 operational primitives ($O7$).
* `[CURRENT METHODOLOGY]` — The validated 10-step extraction and loss test workflow.
* `[ENGINEERING PATTERN]` — Valid composite structures (e.g. `INTERACTION_CONTRACT`).
* `[ARCHITECTURAL HYPOTHESIS]` — Models under active evaluation (e.g., SOL as Action Gate).
* `[PROPOSED EXPERIMENT]` — Falsifiable empirical testing protocols (EXP-01 through EXP-06).
* `[ARCHIVAL / SUPERSEDED]` — Historical lineage concepts preserved for provenance (e.g., `MISSION`, `INTENT`).
* `[UNPROVEN]` — Open scientific claims that have not yet achieved statistical significance.

---

## Core Philosophy

> **SOL does not tell an agent WHAT to think.**  
> **SOL helps an agent maintain WHAT IS KNOWN, WHAT IS MUTATING, WHAT IS CONSTRAINED, WHAT IS COMPARED, and WHAT MAY BE DISSIPATED.**
